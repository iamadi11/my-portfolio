#!/usr/bin/env node
/**
 * Step 2 (free, needs HF_TOKEN in .env.local): character design → textured 3D model with
 * Microsoft TRELLIS.2 on its Hugging Face Space. Also saves the background-removed design, which
 * the site prints flat inside the toy box before it turns 3D.
 *
 *   node --env-file=.env.local scripts/figure/model.mjs <design.png> [seed]
 *
 * Writes assets-src/figure/<design>-trellis-<seed>.glb and <design>-cutout.png.
 */
import { mkdirSync } from 'node:fs';
import { basename, extname, join, resolve } from 'node:path';

import { connect } from './gradio.mjs';

const ROOT = resolve(import.meta.dirname, '../..');
const OUT = join(ROOT, 'assets-src/figure');
const [input, seedArg = '0'] = process.argv.slice(2);
if (!input) throw new Error('usage: model.mjs <design.png> [seed]');
if (!process.env.HF_TOKEN) throw new Error('HF_TOKEN is not set (add it to .env.local; it is never printed)');
const seed = Number(seedArg);
const name = basename(input, extname(input));
mkdirSync(OUT, { recursive: true });

const space = await connect('https://microsoft-trellis-2.hf.space');
await space.call('start_session', []);
const [prepared] = await space.call('preprocess_image', [await space.upload(input)]);
console.log(`  cut-out ${await space.download(prepared, join(OUT, `${name}-cutout.png`))}`);

// Space defaults: 1024 cascade; sparse structure, shape and texture samplers as in its UI.
await space.call('image_to_3d', [prepared, seed, '1024', 7.5, 0.7, 12, 5.0, 7.5, 0.5, 12, 3.0, 1.0, 0.0, 12, 3.0]);
const [glb] = await space.call('extract_glb', [null, 150000, 2048]);
console.log(`  model ${await space.download(glb, join(OUT, `${name}-trellis-${seed}.glb`))}`);
