/**
 * Minimal Gradio 5/6 client (queue protocol, sse_v3) for free Hugging Face Spaces.
 * One session per connection, so Spaces that keep per-session state (TRELLIS) work.
 * Optional HF_TOKEN (free account) raises the shared-GPU quota; it is sent as a header, never logged.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { basename } from 'node:path';

/** Parsed `data:` messages of a server-sent event stream. */
async function* events(stream) {
    const decoder = new TextDecoder();
    let buffer = '';
    for await (const chunk of stream.body) {
        buffer += decoder.decode(chunk, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const line of lines) if (line.startsWith('data:')) yield JSON.parse(line.slice(5));
    }
}

export async function connect(base) {
    const headers = process.env.HF_TOKEN ? { Authorization: `Bearer ${process.env.HF_TOKEN}` } : {};
    const config = await (await fetch(`${base}/config`, { headers })).json();
    const api = `${base}${config.api_prefix ?? ''}`;
    const session = Math.random().toString(36).slice(2, 13);
    const fn = (name) => {
        const dep = config.dependencies.find((d) => d.api_name === name);
        if (!dep) throw new Error(`${base}: no endpoint ${name}`);
        return dep.id;
    };

    async function upload(path, mime = 'image/png') {
        const form = new FormData();
        form.append('files', new Blob([readFileSync(path)], { type: mime }), basename(path));
        const res = await fetch(`${api}/upload`, { method: 'POST', body: form, headers });
        if (!res.ok) throw new Error(`upload ${res.status}: ${await res.text()}`);
        const [remote] = await res.json();
        return { path: remote, orig_name: basename(path), meta: { _type: 'gradio.FileData' } };
    }

    /** Runs an endpoint and resolves with its output data. Logs queue progress. */
    async function call(name, data, { timeoutMs = 15 * 60_000 } = {}) {
        const join = await fetch(`${api}/queue/join`, {
            method: 'POST',
            headers: { ...headers, 'Content-Type': 'application/json' },
            body: JSON.stringify({ data, fn_index: fn(name), session_hash: session, event_data: null, trigger_id: null }),
        });
        if (!join.ok) throw new Error(`${name} join ${join.status}: ${await join.text()}`);
        const { event_id: eventId } = await join.json();

        const stream = await fetch(`${api}/queue/data?session_hash=${session}`, {
            headers,
            signal: AbortSignal.timeout(timeoutMs),
        });
        for await (const msg of events(stream)) {
            if (msg.event_id && msg.event_id !== eventId) continue;
            if (msg.msg === 'estimation' && msg.rank != null) console.log(`  ${name}: queue position ${msg.rank}`);
            if (msg.msg === 'process_starts') console.log(`  ${name}: running`);
            if (msg.msg !== 'process_completed') continue;
            if (!msg.success) throw new Error(`${name} failed: ${JSON.stringify(msg.output).slice(0, 400)}`);
            return msg.output.data;
        }
        throw new Error(`${name}: stream closed without a result`);
    }

    function fileUrl(file) {
        if (!file) return null;
        if (typeof file === 'string') {
            if (file.startsWith('http')) return file;
            if (file.startsWith('/')) return `${base}${file}`;
            return `${api}/file=${file}`;
        }
        if (file.url) return file.url;
        if (file.path) return `${api}/file=${file.path}`;
        if (file.value) return fileUrl(file.value);
        return null;
    }

    async function download(file, to) {
        const url = fileUrl(file);
        if (!url) throw new Error(`download: no file url in ${JSON.stringify(file).slice(0, 300)}`);
        const res = await fetch(url, { headers });
        if (!res.ok) throw new Error(`download ${res.status} ${url}`);
        writeFileSync(to, Buffer.from(await res.arrayBuffer()));
        return to;
    }

    return { upload, call, download };
}
