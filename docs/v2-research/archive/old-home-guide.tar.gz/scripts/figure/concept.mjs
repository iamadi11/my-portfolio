#!/usr/bin/env node
/**
 * Step 1 (free): restyle the owner's photo into an animated-film character design with FLUX.1
 * Kontext on its public Hugging Face Space. A clean, front-facing A-pose on a plain background is
 * what image-to-3D needs next. Writes assets-src/figure/concept-<seed>.png.
 *
 *   node scripts/figure/concept.mjs [photo] [seed ...]
 */
import { mkdirSync } from 'node:fs';
import { join, resolve } from 'node:path';

import { connect } from './gradio.mjs';

const ROOT = resolve(import.meta.dirname, '../..');
const OUT = join(ROOT, 'assets-src/figure');
const [photo = join(ROOT, 'public/profile_pic.png'), ...seedArgs] = process.argv.slice(2);
const seeds = seedArgs.length ? seedArgs.map(Number) : [7, 19, 42];

const PROMPT = [
    'Turn this man into a full-body 3D animated movie character in the style of Pixar and Disney feature films.',
    'Appealing stylised proportions: slightly large head, large expressive eyes, slim athletic build.',
    'Keep him clearly recognisable: short black textured hair swept up, grey square glasses, light stubble beard and moustache, warm brown skin, friendly smile.',
    'Gen Z outfit: plain black crew-neck t-shirt, relaxed light-blue jeans, chunky white sneakers, white over-ear headphones on his head.',
    'Standing straight in an A-pose, arms held well away from the body at about 30 degrees with a clear gap between arms and torso, open empty hands not touching the legs, feet shoulder-width apart with a gap between the legs, front view, centered, whole body from head to shoes visible.',
    'Soft studio lighting, high-quality 3D render, plain light grey background, no text, no props.',
].join(' ');

mkdirSync(OUT, { recursive: true });
const flux = await connect('https://black-forest-labs-flux-1-kontext-dev.hf.space');
const image = await flux.upload(photo);
for (const seed of seeds) {
    console.log(`concept seed ${seed}`);
    const [result] = await flux.call('infer', [image, PROMPT, seed, false, 2.5, 28]);
    console.log(`  saved ${await flux.download(result, join(OUT, `concept-${seed}.png`))}`);
}
