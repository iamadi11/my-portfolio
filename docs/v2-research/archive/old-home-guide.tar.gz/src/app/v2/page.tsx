import type { Metadata, Viewport } from 'next';
import { Funnel_Display } from 'next/font/google';

import RoundTrip from '@/components/round-trip/RoundTrip';
import { tripFrom } from '@/components/round-trip/trip';
import { SITE } from '@/content/site';

/** Display face for the name and headings; body and mono come from the root layout (Geist). */
const display = Funnel_Display({
    subsets: ['latin'],
    weight: ['600', '700', '800'],
    variable: '--font-rt-display',
    display: 'swap',
});

export const metadata: Metadata = {
    title: 'Round trip',
    description: `${SITE.profile.role} in ${SITE.profile.location}. Scroll one request through my stack, from the browser to the database and back.`,
    robots: { index: false, follow: false },
};

export const viewport: Viewport = { themeColor: '#05070d' };

const trip = tripFrom(SITE);

export default function V2Page(): React.JSX.Element {
    return (
        <div className={display.variable}>
            <RoundTrip trip={trip} />
        </div>
    );
}
