/** Printed surfaces: text and simple graphics drawn on a canvas and used as a texture. */
import * as THREE from 'three';

import { PAPER } from '@/components/v2/art';

/** Font stacks; Stage swaps in the page's loaded web fonts before the world is built. */
export const FONT = { display: 'sans-serif', body: 'sans-serif', mono: 'monospace' };

/**
 * A canvas texture for a w × h (world units) surface. `draw` gets the context and `u`,
 * pixels per world unit, so it can lay out in world units: `g.fillRect(0, 0, w * u, h * u)`.
 */
export function print(
    w: number,
    h: number,
    draw: (g: CanvasRenderingContext2D, u: number) => void,
    { density = 320, background = PAPER as string | null } = {}
): THREE.CanvasTexture {
    const u = Math.min(density, 2048 / Math.max(w, h));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(w * u);
    canvas.height = Math.round(h * u);
    const g = canvas.getContext('2d') as CanvasRenderingContext2D;
    if (background) {
        g.fillStyle = background;
        g.fillRect(0, 0, canvas.width, canvas.height);
    }
    draw(g, u);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return tex;
}
