/**
 * The places the guide visits. Each station is a small built-in-code set piece with its own
 * update and pointer targets. Content (names, projects, roles, skills) comes in as data.
 */
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';

import {
    BOX,
    type BoxText,
    CUTOUT,
    CUTOUT_Z,
    drawBoxBack,
    drawBoxFront,
    drawCutout,
    FIGURE_SCALE,
    INK,
    PAPER,
    SIGNAL,
} from '@/components/v2/art';
import type { FigureSpec } from '@/components/v2/figure';
import type { Rung } from '@/components/v2/model';
import { FONT, print } from '@/components/v2/print';

export type Frame = {
    dt: number;
    time: number;
    /** 1 when the camera is on this station, falling to 0 a stop away. */
    near: number;
    /** Pointer ray in world space, or null when there is no pointer. */
    ray: THREE.Ray | null;
    reduce: boolean;
};

export type Hit = { object: THREE.Object3D; press(): void };

export type Station = {
    group: THREE.Group;
    hits: Hit[];
    update(f: Frame): void;
    /** Height of walkable ground at world (x, z), or null where the station is not underfoot. */
    ground?: (x: number, z: number) => number | null;
};

type Sfx = (name: 'click' | 'pop' | 'tick', amount?: number) => void;

export const HUES = { blue: '#4b6fd6', red: '#e4503d', green: '#2f9a6f', ink: '#2a2a2a' } as const;

const plastic = (
    color: string,
    extra: THREE.MeshPhysicalMaterialParameters = {}
): THREE.MeshPhysicalMaterial =>
    new THREE.MeshPhysicalMaterial({
        color,
        roughness: 0.36,
        clearcoat: 0.6,
        clearcoatRoughness: 0.22,
        ...extra,
    });
const card = (map: THREE.Texture | null, color = '#ffffff'): THREE.MeshStandardMaterial =>
    new THREE.MeshStandardMaterial({ map, color, roughness: 0.82 });

function part<T extends THREE.Object3D>(obj: T, at?: [number, number, number], shadows = true): T {
    if (at) obj.position.set(...at);
    obj.traverse((o) => {
        if (o instanceof THREE.Mesh) {
            o.castShadow = shadows;
            o.receiveShadow = true;
        }
    });
    return obj;
}
const rbox = (
    w: number,
    h: number,
    d: number,
    r: number,
    mat: THREE.Material,
    at?: [number, number, number]
): THREE.Mesh =>
    part(
        new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 3, Math.min(r, w / 2, h / 2, d / 2) * 0.999), mat),
        at
    );
const damp = THREE.MathUtils.damp;

/* ================================================================== toy box */

export type ToyBox = Station & {
    /** The printed cut-out of the figure, standing on the tray until it inflates. */
    cutout: THREE.Mesh;
    /** World position where the figure stands inside the box. */
    inside: THREE.Vector3;
    /** Centre of the front panel, for lining the camera up with the 2D poster. */
    front: THREE.Vector3;
};

export function toyBox(
    text: BoxText,
    spec: FigureSpec,
    at: THREE.Vector3,
    art: HTMLImageElement | null
): ToyBox {
    const { w, h, d, window: win } = BOX;
    const T = BOX.wall;
    const group = part(new THREE.Group(), [at.x, at.y, at.z]);
    const fonts = { display: FONT.display, mono: FONT.mono };

    // Front: the printed panel with its window cut out.
    const frontTex = print(w, h, (g, u) => drawBoxFront(g, u, text, fonts), { background: null });
    frontTex.repeat.set(1 / w, 1 / h);
    frontTex.offset.set(0.5, 0.5);
    const outline = new THREE.Shape();
    outline.moveTo(-w / 2, -h / 2);
    outline.lineTo(w / 2, -h / 2);
    outline.lineTo(w / 2, h / 2);
    outline.lineTo(-w / 2, h / 2);
    outline.closePath();
    const wx = -w / 2 + win.x;
    const wy = h / 2 - win.y - win.h;
    const r = 0.12;
    const windowPath = new THREE.Path();
    windowPath.moveTo(wx + r, wy);
    windowPath.lineTo(wx + win.w - r, wy);
    windowPath.quadraticCurveTo(wx + win.w, wy, wx + win.w, wy + r);
    windowPath.lineTo(wx + win.w, wy + win.h - r);
    windowPath.quadraticCurveTo(wx + win.w, wy + win.h, wx + win.w - r, wy + win.h);
    windowPath.lineTo(wx + r, wy + win.h);
    windowPath.quadraticCurveTo(wx, wy + win.h, wx, wy + win.h - r);
    windowPath.lineTo(wx, wy + r);
    windowPath.quadraticCurveTo(wx, wy, wx + r, wy);
    outline.holes.push(windowPath);
    const frontGeo = new THREE.ExtrudeGeometry(outline, { depth: T, bevelEnabled: false, curveSegments: 6 });
    const front = part(new THREE.Mesh(frontGeo, [card(frontTex), card(null, PAPER)]), [0, h / 2, d / 2 - T]);
    group.add(front);

    // Inside: sunburst back, sides, floor, tray, lid with a hang tab.
    const backTex = print(w - 2 * T, h, (g, u) => drawBoxBack(g, u, w - 2 * T, h));
    group.add(
        part(new THREE.Mesh(new THREE.PlaneGeometry(w - 2 * T, h), card(backTex)), [0, h / 2, -d / 2 + T])
    );
    const sideMat = card(null, SIGNAL);
    const inkMat = card(null, INK);
    for (const side of [-1, 1]) group.add(rbox(T, h, d, 0.01, sideMat, [side * (w / 2 - T / 2), h / 2, 0]));
    group.add(rbox(w, T, d, 0.01, inkMat, [0, h - T / 2, 0]));
    group.add(rbox(w, T, d, 0.01, sideMat, [0, T / 2, 0]));
    const trayY = h - win.y - win.h;
    group.add(rbox(w - 2 * T, trayY, d - 2 * T, 0.02, card(null, '#f1e7da'), [0, trayY / 2, 0]));
    const tab = new THREE.Shape();
    tab.moveTo(-0.45, 0);
    tab.lineTo(0.45, 0);
    tab.lineTo(0.45, 0.22);
    tab.quadraticCurveTo(0.45, 0.34, 0.33, 0.34);
    tab.lineTo(-0.33, 0.34);
    tab.quadraticCurveTo(-0.45, 0.34, -0.45, 0.22);
    tab.closePath();
    const slot = new THREE.Path();
    slot.absellipse(0, 0.2, 0.16, 0.05, 0, Math.PI * 2, false, 0);
    tab.holes.push(slot);
    group.add(
        part(new THREE.Mesh(new THREE.ExtrudeGeometry(tab, { depth: T, bevelEnabled: false }), inkMat), [
            0,
            h,
            -d / 2 + T / 2,
        ])
    );

    // The cut-out: the figure as a flat print, standing on the tray.
    const cw = CUTOUT.w * FIGURE_SCALE;
    const ch = CUTOUT.h * FIGURE_SCALE;
    const cutTex = print(cw, ch, (g, u) => drawCutout(g, u * FIGURE_SCALE, spec, art), {
        background: null,
        density: 420,
    });
    const cutout = part(
        new THREE.Mesh(
            new THREE.PlaneGeometry(cw, ch),
            new THREE.MeshStandardMaterial({ map: cutTex, transparent: true, alphaTest: 0.4, roughness: 0.7 })
        ),
        [0, trayY + ch / 2, CUTOUT_Z]
    );
    group.add(cutout);

    return {
        group,
        hits: [],
        cutout,
        inside: new THREE.Vector3(at.x, at.y + trayY, at.z + CUTOUT_Z),
        front: new THREE.Vector3(at.x, at.y + h / 2, at.z + d / 2),
        update: () => undefined,
        // The tray inside is a floor until you step out through the window.
        ground: (x, z) =>
            Math.abs(x - at.x) < w / 2 - T && z > at.z - d / 2 + T && z < at.z + d / 2 ? at.y + trayY : null,
    };
}

/* ================================================================== stands + playsets */

/** A glossy round stand with the project's title on a small plaque. Returns the top height. */
function stand(group: THREE.Group, hue: string, title: string): number {
    const profile = [
        [0, 0],
        [1.0, 0],
        [1.05, 0.04],
        [1.06, 0.3],
        [1.0, 0.36],
        [0, 0.36],
    ].map(([x, y]) => new THREE.Vector2(x, y));
    group.add(part(new THREE.Mesh(new THREE.LatheGeometry(profile, 64), plastic(hue))));
    const tex = print(1.3, 0.3, (g, u) => {
        g.fillStyle = INK;
        g.fillRect(0, 0, 1.3 * u, 0.3 * u);
        g.fillStyle = PAPER;
        g.textAlign = 'center';
        g.textBaseline = 'middle';
        let s = 0.17 * u;
        g.font = `800 ${s}px ${FONT.display}`;
        while (g.measureText(title.toUpperCase()).width > 1.15 * u) {
            s *= 0.94;
            g.font = `800 ${s}px ${FONT.display}`;
        }
        g.fillText(title.toUpperCase(), 0.65 * u, 0.16 * u);
    });
    const plaque = rbox(1.3, 0.3, 0.05, 0.02, card(null, INK), [0, 0.2, 1.08]);
    plaque.rotation.x = -0.3;
    const face = new THREE.Mesh(new THREE.PlaneGeometry(1.26, 0.27), card(tex));
    face.position.z = 0.027;
    plaque.add(face);
    group.add(plaque);
    return 0.36;
}

type Playset = (group: THREE.Group, top: number, hue: string, sfx: Sfx) => Omit<Station, 'group'>;

/** 'stack': a device, a cache, a cloud. Every few seconds the network drops; the cache keeps serving. */
const cache: Playset = (group, top, hue, sfx) => {
    const phone = rbox(0.38, 0.72, 0.06, 0.06, plastic(INK), [-0.5, top + 0.46, 0.2]);
    const screenTex = print(0.32, 0.62, (g, u) => {
        g.fillStyle = '#fbf7f0';
        g.fillRect(0, 0, 0.32 * u, 0.62 * u);
        g.fillStyle = hue;
        g.fillRect(0.03 * u, 0.04 * u, 0.26 * u, 0.12 * u);
        g.fillStyle = '#d9d2c6';
        for (let i = 0; i < 5; i++)
            g.fillRect(0.03 * u, (0.2 + i * 0.08) * u, (0.26 - (i % 2) * 0.08) * u, 0.04 * u);
    });
    const screen = new THREE.Mesh(
        new THREE.PlaneGeometry(0.32, 0.62),
        new THREE.MeshBasicMaterial({ map: screenTex, toneMapped: false })
    );
    screen.position.z = 0.032;
    phone.add(screen);
    phone.rotation.y = 0.35;

    const vault = rbox(0.34, 0.34, 0.34, 0.06, plastic(SIGNAL), [0.02, top + 0.32, 0.25]);
    const ring = part(
        new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.025, 12, 32), plastic(PAPER)),
        [0, 0, 0.175]
    );
    vault.add(ring);

    const cloudMat = plastic('#fbf8f2', { roughness: 0.6, clearcoat: 0.2 });
    const cloud = new THREE.Group();
    for (const [x, y, r] of [
        [0, 0, 0.2],
        [0.2, -0.04, 0.15],
        [-0.2, -0.05, 0.14],
        [0.08, 0.12, 0.15],
    ])
        cloud.add(part(new THREE.Mesh(new THREE.SphereGeometry(r, 24, 16), cloudMat), [x, y, 0]));
    part(cloud, [0.5, top + 1.2, -0.25]);

    const path = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0.5, top + 1.0, -0.25),
        new THREE.Vector3(0.45, top + 0.55, 0.0),
        new THREE.Vector3(0.12, top + 0.38, 0.25),
        new THREE.Vector3(-0.2, top + 0.3, 0.3),
        new THREE.Vector3(-0.45, top + 0.12, 0.25),
    ]);
    const wire = part(
        new THREE.Mesh(new THREE.TubeGeometry(path, 64, 0.022, 8), plastic(INK, { roughness: 0.5 }))
    );
    const cutMat = plastic(INK, { transparent: true, opacity: 1 });
    const upstream = new THREE.CatmullRomCurve3(path.points.slice(0, 3));
    const upWire = part(new THREE.Mesh(new THREE.TubeGeometry(upstream, 32, 0.026, 8), cutMat));
    group.add(phone, vault, cloud, wire, upWire);

    const packetMat = new THREE.MeshBasicMaterial({ color: hue, toneMapped: false });
    const packets = Array.from({ length: 6 }, (_, i) => {
        const p = rbox(0.07, 0.07, 0.07, 0.015, packetMat);
        p.userData.phase = i / 6;
        group.add(p);
        return p;
    });
    let offline = 0;
    let timer = 0;
    let state = false;
    const toggle = (): void => {
        state = !state;
        timer = 0;
        sfx('tick', state ? 0.6 : 1);
    };
    return {
        hits: [{ object: group, press: toggle }],
        update(f) {
            if (f.near < 0.05) return;
            // Reduced motion: no auto demo and no travelling packets; a click still toggles.
            const time = f.reduce ? 0 : f.time;
            timer += f.dt;
            if (timer > 3.6 && f.near > 0.6 && !f.reduce) toggle();
            offline = damp(offline, state ? 1 : 0, 6, f.dt);
            cutMat.opacity = 1 - offline * 0.8;
            cloud.scale.setScalar(1 - offline * 0.25);
            cloud.position.y = top + 1.2 - offline * 0.1;
            (cloudMat.color as THREE.Color).setStyle(state ? '#bdb6ab' : '#fbf8f2');
            vault.scale.setScalar(1 + offline * 0.08 + Math.sin(time * 6) * 0.02 * offline);
            for (const p of packets) {
                // Online: cloud → device. Offline: only cache → device, and faster.
                const speed = state ? 0.55 : 0.32;
                const u = (time * speed + p.userData.phase) % 1;
                const from = state ? 0.5 : 0;
                p.position.copy(path.getPointAt(from + u * (1 - from)));
                p.rotation.set(time * 2, time * 3, 0);
            }
        },
    };
};

/** 'lattice': a spec card and a screen whose UI blocks re-flow into a new layout. */
const assembler: Playset = (group, top, hue, sfx) => {
    const spec = rbox(0.5, 0.66, 0.04, 0.04, card(null, PAPER), [-0.55, top + 0.5, 0.25]);
    spec.rotation.set(-0.15, 0.45, 0.06);
    const specTex = print(0.46, 0.62, (g, u) => {
        g.fillStyle = PAPER;
        g.fillRect(0, 0, 0.46 * u, 0.62 * u);
        const colors = [INK, hue, SIGNAL, '#9b948a'];
        for (let i = 0; i < 9; i++) {
            g.fillStyle = colors[i % colors.length];
            g.fillRect(
                (0.04 + (i % 3) * 0.04) * u,
                (0.05 + i * 0.062) * u,
                (0.12 + ((i * 37) % 17) / 70) * u,
                0.03 * u
            );
        }
    });
    const specFace = new THREE.Mesh(new THREE.PlaneGeometry(0.46, 0.62), card(specTex));
    specFace.position.z = 0.022;
    spec.add(specFace);

    const screen = rbox(0.92, 1.0, 0.07, 0.06, plastic(INK), [0.3, top + 0.66, -0.1]);
    const face = new THREE.Mesh(new THREE.PlaneGeometry(0.82, 0.9), card(null, '#fbf7f0'));
    face.position.z = 0.037;
    screen.add(face);
    group.add(spec, screen);

    const colors = [hue, SIGNAL, INK, '#d8cfc2', hue, '#ffb48f'];
    const blocks = colors.map((c) => {
        const b = rbox(1, 1, 1, 0.12, plastic(c));
        b.userData = {
            pos: new THREE.Vector3(),
            vel: new THREE.Vector3(),
            size: new THREE.Vector3(0.1, 0.1, 0.05),
            svel: new THREE.Vector3(),
        };
        screen.add(b);
        return b;
    });
    // Layouts on the screen's face: [x, y, w, h] in 0..1 from the top-left.
    const layouts: number[][][] = [
        [
            [0, 0, 1, 0.18],
            [0, 0.22, 0.48, 0.4],
            [0.52, 0.22, 0.48, 0.4],
            [0, 0.66, 1, 0.12],
            [0, 0.82, 0.48, 0.18],
            [0.52, 0.82, 0.48, 0.18],
        ],
        [
            [0, 0, 0.3, 1],
            [0.34, 0, 0.66, 0.3],
            [0.34, 0.34, 0.66, 0.3],
            [0.34, 0.68, 0.32, 0.32],
            [0.7, 0.68, 0.3, 0.14],
            [0.7, 0.86, 0.3, 0.14],
        ],
        [
            [0, 0, 1, 0.5],
            [0, 0.54, 0.31, 0.22],
            [0.345, 0.54, 0.31, 0.22],
            [0.69, 0.54, 0.31, 0.22],
            [0, 0.8, 0.64, 0.2],
            [0.68, 0.8, 0.32, 0.2],
        ],
    ];
    let layout = 0;
    let timer = 0;
    const target = (i: number): { pos: THREE.Vector3; size: THREE.Vector3 } => {
        const [x, y, w, h] = layouts[layout][i];
        const W = 0.78;
        const H = 0.86;
        const gap = 0.02;
        return {
            pos: new THREE.Vector3(-W / 2 + (x + w / 2) * W, H / 2 - (y + h / 2) * H, 0.08),
            size: new THREE.Vector3(Math.max(0.04, w * W - gap), Math.max(0.04, h * H - gap), 0.06),
        };
    };
    const next = (): void => {
        layout = (layout + 1) % layouts.length;
        timer = 0;
        sfx('click', 0.5);
        blocks.forEach((b) => (b.userData.vel.z += 1.6));
    };
    return {
        hits: [{ object: group, press: next }],
        update(f) {
            if (f.near < 0.05) return;
            timer += f.dt;
            if (timer > 2.8 && f.near > 0.6 && !f.reduce) next();
            const dt = Math.min(f.dt, 1 / 30);
            blocks.forEach((b, i) => {
                const { pos, size } = target(i);
                const s = b.userData;
                // Springy settle: a little overshoot reads as "snapping into place".
                s.vel.addScaledVector(pos.clone().sub(s.pos), 140 * dt).multiplyScalar(1 - 11 * dt);
                s.pos.addScaledVector(s.vel, dt);
                s.svel.addScaledVector(size.clone().sub(s.size), 140 * dt).multiplyScalar(1 - 11 * dt);
                s.size.addScaledVector(s.svel, dt);
                b.position.copy(s.pos);
                b.scale.set(Math.max(0.01, s.size.x), Math.max(0.01, s.size.y), s.size.z);
            });
        },
    };
};

/** 'wave': a frame-time graph; a magnifier sweeps it and flags the slow frames. */
const monitor: Playset = (group, top, hue, sfx) => {
    const screen = rbox(1.2, 0.82, 0.08, 0.06, plastic(INK), [0, top + 0.72, -0.1]);
    const face = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.72), card(null, '#fbf7f0'));
    face.position.z = 0.041;
    screen.add(face);
    const neck = part(new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 0.32, 16), plastic(INK)), [
        0,
        top + 0.16,
        -0.1,
    ]);
    group.add(screen, neck);

    const N = 14;
    const okMat = plastic(hue);
    const slowMat = plastic('#e4503d');
    const values = Array.from({ length: N }, (_, i) => 0.3 + 0.12 * Math.sin(i));
    const bars = values.map((_, i) => {
        const b = rbox(1, 1, 1, 0.1, okMat);
        b.position.set(-0.5 + (i + 0.5) * (1 / N), 0, 0.06);
        b.scale.set(0.05, 0.1, 0.03);
        screen.add(b);
        return b;
    });
    const LIMIT = 0.55;
    const line = new THREE.Mesh(
        new THREE.PlaneGeometry(1.04, 0.012),
        new THREE.MeshBasicMaterial({ color: '#e4503d' })
    );
    line.position.set(0, -0.32 + LIMIT * 0.62, 0.05);
    screen.add(line);

    const lens = new THREE.Group();
    lens.add(
        part(
            new THREE.Mesh(
                new THREE.TorusGeometry(0.11, 0.026, 12, 32),
                plastic('#d9d5ce', { metalness: 0.6, roughness: 0.25 })
            )
        )
    );
    const glass = new THREE.Mesh(
        new THREE.CircleGeometry(0.11, 32),
        new THREE.MeshPhysicalMaterial({
            color: '#dfeaf0',
            transparent: true,
            opacity: 0.25,
            roughness: 0.05,
            clearcoat: 1,
        })
    );
    lens.add(glass);
    const handle = part(
        new THREE.Mesh(new THREE.CapsuleGeometry(0.025, 0.18, 4, 10), plastic(INK)),
        [0.12, -0.15, 0]
    );
    handle.rotation.z = 0.7;
    lens.add(handle);
    lens.position.set(0, top + 0.72, 0.14);
    group.add(lens);

    let shift = 0;
    let spike = false;
    let seen = -1;
    return {
        hits: [
            {
                object: group,
                press: () => {
                    spike = true;
                    sfx('click', 0.8);
                },
            },
        ],
        update(f) {
            if (f.near < 0.05) return;
            shift += f.reduce ? 0 : f.dt * 2.2;
            while (shift > 1) {
                shift -= 1;
                values.shift();
                values.push(
                    spike || Math.random() < 0.12 ? 0.62 + Math.random() * 0.3 : 0.18 + Math.random() * 0.22
                );
                spike = false;
            }
            const time = f.reduce ? 1.2 : f.time;
            const sweep = (Math.sin(time * 0.9) + 1) / 2;
            lens.position.x = -0.45 + sweep * 0.9;
            lens.position.y = top + 0.72 + Math.sin(time * 2.1) * 0.04;
            const under = Math.round(sweep * (N - 1));
            bars.forEach((b, i) => {
                const v = values[i];
                const slow = v > LIMIT;
                b.material = slow ? slowMat : okMat;
                const hgt = v * 0.62;
                b.scale.y = damp(b.scale.y, hgt + (slow && i === under ? 0.04 : 0), 10, f.dt);
                b.position.y = -0.32 + b.scale.y / 2;
                b.position.z = 0.06 + (slow && Math.abs(i - under) < 1 ? 0.04 : 0);
            });
            if (values[under] > LIMIT && under !== seen && f.near > 0.6) {
                seen = under;
                sfx('tick', 0.4);
            }
        },
    };
};

/** 'orbit': a cursor on a pad, and a chain of beads that follows it. */
const followers: Playset = (group, top, hue) => {
    const pad = rbox(1.36, 0.05, 1.36, 0.025, card(null, '#fbf7f0'), [0, top + 0.025, 0]);
    group.add(pad);
    const arrow = new THREE.Shape();
    arrow.moveTo(0, 0);
    arrow.lineTo(0, -0.26);
    arrow.lineTo(0.065, -0.2);
    arrow.lineTo(0.11, -0.3);
    arrow.lineTo(0.15, -0.28);
    arrow.lineTo(0.105, -0.19);
    arrow.lineTo(0.18, -0.19);
    arrow.closePath();
    const cursor = part(
        new THREE.Mesh(
            new THREE.ExtrudeGeometry(arrow, {
                depth: 0.04,
                bevelEnabled: true,
                bevelSize: 0.01,
                bevelThickness: 0.01,
                bevelSegments: 2,
            }),
            plastic(INK)
        )
    );
    cursor.rotation.x = -Math.PI / 2 + 0.25;
    group.add(cursor);
    const beads = Array.from({ length: 8 }, (_, i) => {
        const bead = part(
            new THREE.Mesh(new THREE.SphereGeometry(0.1 - i * 0.008, 24, 16), plastic(i % 2 ? SIGNAL : hue))
        );
        bead.position.set(0, top + 0.15, 0);
        group.add(bead);
        return bead;
    });
    const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    const hit = new THREE.Vector3();
    const goal = new THREE.Vector3();
    let held = 0;
    return {
        hits: [],
        update(f) {
            if (f.near < 0.05) return;
            group.updateWorldMatrix(true, false);
            plane.constant = -(group.position.y + top + 0.05);
            const local = f.ray && f.ray.intersectPlane(plane, hit) ? group.worldToLocal(hit.clone()) : null;
            if (local && Math.abs(local.x) < 0.68 && Math.abs(local.z) < 0.68) {
                goal.set(local.x, 0, local.z);
                held = 1.5;
            } else if ((held -= f.dt) <= 0 && !f.reduce) {
                goal.set(Math.sin(f.time * 1.3) * 0.45, 0, Math.sin(f.time * 2.1) * 0.35);
            }
            cursor.position.x = damp(cursor.position.x, goal.x, 12, f.dt);
            cursor.position.z = damp(cursor.position.z, goal.z, 12, f.dt);
            cursor.position.y = top + 0.12;
            let lead = cursor.position;
            beads.forEach((bead, i) => {
                bead.position.x = damp(bead.position.x, lead.x, 9 - i * 0.6, f.dt);
                bead.position.z = damp(bead.position.z, lead.z, 9 - i * 0.6, f.dt);
                bead.position.y =
                    top + 0.14 + (f.reduce ? 0 : Math.abs(Math.sin(f.time * 4 - i * 0.6)) * 0.08);
                lead = bead.position;
            });
        },
    };
};

const PLAYSETS: Record<string, Playset> = {
    stack: cache,
    lattice: assembler,
    wave: monitor,
    orbit: followers,
};

export function playset(mark: string, hue: string, title: string, at: THREE.Vector3, sfx: Sfx): Station {
    const group = part(new THREE.Group(), [at.x, at.y, at.z]);
    const top = stand(group, hue, title);
    const play = (PLAYSETS[mark] ?? followers)(group, top, hue, sfx);
    return { group, ...play };
}

/* ================================================================== career stairs */

export const STEP = { w: 1.8, d: 1.7, rise: 0.5 };
/** Length of the ramp down from the top step. */
export const RAMP = 6;

/** Cloth colours for the books, oldest role first. */
const BINDINGS = ['#e7dccb', '#2f4a6d', '#c9a227', '#5f7f63', '#9c3d2e', SIGNAL, '#3d6f8c'];

/** Fine page lines for the edges of a book block. */
let pageLines: THREE.CanvasTexture | null = null;
function pages(): THREE.CanvasTexture {
    pageLines ??= print(
        1,
        1,
        (g, u) => {
            for (let y = 0; y < u; y += 3) {
                g.fillStyle = y % 6 ? 'rgba(150,130,100,0.18)' : 'rgba(150,130,100,0.32)';
                g.fillRect(0, y, u, 1);
            }
        },
        { background: '#f5eddc', density: 256 }
    );
    return pageLines;
}

/** The label on a spine: the org large, then the role and dates when there is room. */
function spine(rung: Rung, full: boolean, dark: boolean): THREE.Mesh {
    const tex = print(
        1.6,
        0.46,
        (g, u) => {
            g.fillStyle = dark ? PAPER : INK;
            g.textAlign = 'left';
            g.textBaseline = 'alphabetic';
            const line = (text: string, y: number, size: number, font: string): void => {
                let s = size * u;
                g.font = font.replace('{s}', `${s}px`);
                while (g.measureText(text).width > 1.5 * u && s > 6) {
                    s *= 0.94;
                    g.font = font.replace('{s}', `${s}px`);
                }
                g.fillText(text, 0.05 * u, y * u);
            };
            if (!full) {
                g.globalAlpha = 0.7;
                line(rung.org.toUpperCase(), 0.29, 0.12, `800 {s} ${FONT.display}`);
                return;
            }
            line(rung.org.toUpperCase(), 0.19, 0.17, `800 {s} ${FONT.display}`);
            line(rung.role, 0.31, 0.075, `600 {s} ${FONT.body}`);
            line(rung.period, 0.42, 0.065, `500 {s} ${FONT.mono}`);
        },
        { background: null }
    );
    return new THREE.Mesh(
        new THREE.PlaneGeometry(1.6, 0.46),
        new THREE.MeshStandardMaterial({ map: tex, transparent: true, roughness: 0.6, depthWrite: false })
    );
}

/** A hardback lying flat: two boards, the spine facing front, cream pages showing at three edges. */
function book(w: number, t: number, d: number, binding: string): THREE.Group {
    const g = new THREE.Group();
    const cloth = new THREE.MeshStandardMaterial({ color: binding, roughness: 0.78 });
    const b = 0.04;
    g.add(
        rbox(w, b, d, 0.018, cloth, [0, -t / 2 + b / 2, 0]),
        rbox(w, b, d, 0.018, cloth, [0, t / 2 - b / 2, 0]),
        rbox(w, t, 0.09, 0.04, cloth, [0, 0, d / 2 - 0.045]),
        part(
            new THREE.Mesh(
                new THREE.BoxGeometry(w - 0.06, t - 2 * b + 0.004, d - 0.08),
                new THREE.MeshStandardMaterial({ map: pages(), roughness: 0.9 })
            ),
            [0, 0, -0.03]
        )
    );
    return g;
}

const isDark = (hex: string): boolean => new THREE.Color(hex).getHSL({ h: 0, s: 0, l: 0 }).l < 0.5;

/** A wooden ruler, for the ramp back down to the desk. */
function ruler(length: number, width: number): THREE.Mesh {
    const tex = print(
        length,
        width,
        (g, u) => {
            g.fillStyle = 'rgba(60,44,28,0.85)';
            g.font = `600 ${0.13 * u}px ${FONT.mono}`;
            for (let i = 0, x = 0.1; x < length - 0.1; i++, x += 0.1) {
                const major = i % 10 === 0;
                g.fillRect(x * u, 0, Math.max(1, 0.012 * u), (major ? 0.26 : i % 5 === 0 ? 0.18 : 0.11) * u);
                if (major) g.fillText(String(i / 10), x * u + 0.03 * u, 0.42 * u);
            }
        },
        { background: '#e3c79c', density: 160 }
    );
    const wood = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.6 });
    return part(
        new THREE.Mesh(new RoundedBoxGeometry(length, 0.07, width, 2, 0.02), [
            wood,
            wood,
            wood,
            wood,
            wood,
            wood,
        ])
    );
}

/** One stack of books per role, oldest first: each stack holds every role so far, the newest on top. */
export function stairs(rungs: Rung[], at: THREE.Vector3): Station & { tops: THREE.Vector3[] } {
    const group = part(new THREE.Group(), [at.x, at.y, at.z]);
    const random = (() => {
        let s = 3;
        return (): number => (s = (s * 16807) % 2147483647) / 2147483647 - 0.5;
    })();
    const tops = rungs.map((rung, j) => {
        for (let i = 0; i <= j; i++) {
            const top = i === j;
            const binding = BINDINGS[i % BINDINGS.length];
            const w = STEP.w - 0.06 - (top ? 0 : Math.abs(random()) * 0.12);
            const d = STEP.d - (top ? 0.02 : Math.abs(random()) * 0.14);
            const b = book(w, STEP.rise, d, binding);
            b.position.set(
                j * STEP.w + random() * (top ? 0.02 : 0.08),
                STEP.rise * (i + 0.5),
                random() * 0.06
            );
            b.rotation.y = random() * (top ? 0.02 : 0.07);
            const label = spine(rungs[i], top, isDark(binding));
            label.position.set(0, top ? -0.02 : 0, d / 2 + 0.004);
            b.add(label);
            group.add(b);
        }
        return new THREE.Vector3(at.x + j * STEP.w, at.y + STEP.rise * (j + 1), at.z);
    });

    // From the top stack a ruler leans back down to the desk, so the walk can go on.
    const H = STEP.rise * rungs.length;
    const r0 = (rungs.length - 1) * STEP.w + STEP.w / 2 - 0.02;
    const slope = Math.atan2(H, RAMP);
    const board = ruler(Math.hypot(RAMP, H) + 0.3, 1.1);
    board.rotation.z = -slope;
    board.position.set(r0 + RAMP / 2 - Math.sin(slope) * 0.035, H / 2 - Math.cos(slope) * 0.035, 0);
    group.add(board);

    return {
        group,
        hits: [],
        tops,
        update: () => undefined,
        ground: (x, z) => {
            if (Math.abs(z - at.z) > STEP.d / 2) return null;
            const lx = x - at.x;
            const j = Math.round(lx / STEP.w);
            if (j >= 0 && j < rungs.length && Math.abs(lx - j * STEP.w) <= STEP.w / 2)
                return at.y + STEP.rise * (j + 1);
            if (lx > r0 && lx < r0 + RAMP) return at.y + H * (1 - (lx - r0) / RAMP);
            return null;
        },
    };
}

/* ================================================================== keyboard */

type Key = { cap: THREE.Group; w: number; press: number; target: number; wave: number };

/** Every skill is a keycap. Rows are skill groups; narrow screens get shorter rows. */
export function keyboard(
    groups: { group: string; items: string[] }[],
    at: THREE.Vector3,
    narrow: boolean,
    sfx: Sfx
): Station & { size: THREE.Vector2; tread(x: number, z: number): void } {
    const group = part(new THREE.Group(), [at.x, at.y, at.z]);
    const CAP_H = 0.22;
    const ROW = 0.66;
    const GAP = 0.07;
    const maxRow = narrow ? 4.4 : 6.6;
    const tints = ['#f1ebe1', SIGNAL, '#3a3a3a', HUES.blue, HUES.green, '#d9cfc1'];
    const width = (text: string): number => Math.min(2.2, Math.max(0.62, 0.3 + text.length * 0.085));

    // Lay out rows: a group can wrap onto several rows.
    const rows: { text: string; tint: string; w: number }[][] = [];
    groups.forEach((g, gi) => {
        let row: { text: string; tint: string; w: number }[] = [];
        let used = 0;
        for (const item of g.items) {
            const w = width(item);
            if (row.length && used + w > maxRow) {
                rows.push(row);
                row = [];
                used = 0;
            }
            row.push({ text: item, tint: tints[gi % tints.length], w });
            used += w + GAP;
        }
        if (row.length) rows.push(row);
    });
    const widest = Math.max(...rows.map((r) => r.reduce((s, k) => s + k.w + GAP, -GAP)));
    const depth = rows.length * ROW + 0.4;
    const W = widest + 0.5;
    group.add(rbox(W, 0.28, depth, 0.12, plastic('#202020', { clearcoat: 0.4 }), [0, 0.14, 0]));

    const keys: Key[] = [];
    const hits: Hit[] = [];
    rows.forEach((row, ri) => {
        const rowW = row.reduce((s, k) => s + k.w + GAP, -GAP);
        let x = -rowW / 2;
        const z = -depth / 2 + 0.2 + ri * ROW + (ROW - GAP) / 2;
        for (const k of row) {
            const cap = new THREE.Group();
            cap.position.set(x + k.w / 2, 0.28 + CAP_H / 2, z);
            const dark = k.tint === '#3a3a3a' || k.tint === HUES.blue || k.tint === HUES.green;
            cap.add(rbox(k.w, CAP_H, ROW - GAP, 0.07, plastic(k.tint, { clearcoat: 0.5, roughness: 0.45 })));
            const tex = print(
                k.w - 0.08,
                0.4,
                (g, u) => {
                    g.fillStyle = dark ? PAPER : INK;
                    g.textAlign = 'center';
                    g.textBaseline = 'middle';
                    let s = 0.15 * u;
                    g.font = `700 ${s}px ${FONT.body}`;
                    while (g.measureText(k.text).width > (k.w - 0.14) * u && s > 6) {
                        s *= 0.94;
                        g.font = `700 ${s}px ${FONT.body}`;
                    }
                    g.fillText(k.text, ((k.w - 0.08) / 2) * u, 0.2 * u);
                },
                { background: null }
            );
            const legend = new THREE.Mesh(
                new THREE.PlaneGeometry(k.w - 0.08, 0.4),
                new THREE.MeshStandardMaterial({
                    map: tex,
                    transparent: true,
                    roughness: 0.5,
                    depthWrite: false,
                })
            );
            legend.rotation.x = -Math.PI / 2;
            legend.position.y = CAP_H / 2 + 0.002;
            cap.add(legend);
            group.add(cap);
            const key: Key = { cap, w: k.w, press: 0, target: 0, wave: 0 };
            keys.push(key);
            hits.push({
                object: cap,
                press: () => {
                    key.target = 1;
                    sfx('click', 1);
                    window.setTimeout(() => (key.target = 0), 140);
                },
            });
            x += k.w + GAP;
        }
    });

    let was = 0;
    let waveAt = -1;
    /** Where someone is standing on the keys, in keyboard space (or null). */
    let foot: THREE.Vector2 | null = null;
    return {
        group,
        hits,
        size: new THREE.Vector2(W, depth),
        tread(x, z) {
            const lx = x - group.position.x;
            const lz = z - group.position.z;
            foot = Math.abs(lx) < W / 2 && Math.abs(lz) < depth / 2 ? new THREE.Vector2(lx, lz) : null;
        },
        ground: (x, z) =>
            Math.abs(x - group.position.x) < W / 2 && Math.abs(z - group.position.z) < depth / 2
                ? 0.28 + CAP_H
                : null,
        update(f) {
            if (f.near < 0.05 && was < 0.05 && !foot) return;
            // Arriving runs a ripple across the keys, left to right.
            if (f.near > 0.7 && was <= 0.7 && !f.reduce) waveAt = f.time;
            was = f.near;
            for (const key of keys) {
                let wave = 0;
                if (waveAt >= 0) {
                    const delay = (key.cap.position.x + W / 2) * 0.09 + key.cap.position.z * 0.05;
                    const p = (f.time - waveAt - delay) / 0.18;
                    wave = p > 0 && p < 1 ? Math.sin(p * Math.PI) : 0;
                }
                const under =
                    foot &&
                    Math.abs(key.cap.position.x - foot.x) < key.w / 2 + 0.12 &&
                    Math.abs(key.cap.position.z - foot.y) < 0.42
                        ? 1
                        : 0;
                key.press = damp(key.press, Math.max(key.target, wave, under), 26, f.dt);
                key.cap.position.y = 0.28 + CAP_H / 2 - key.press * 0.1;
            }
        },
    };
}

/* ================================================================== hello button */

export function helloButton(
    at: THREE.Vector3,
    sfx: Sfx,
    onPress: () => void
): Station & { pressed: () => number } {
    const group = part(new THREE.Group(), [at.x, at.y, at.z]);
    const housing = [
        [0, 0],
        [0.95, 0],
        [1.0, 0.05],
        [1.0, 0.3],
        [0.9, 0.36],
        [0.74, 0.36],
        [0.74, 0.3],
        [0, 0.3],
    ].map(([x, y]) => new THREE.Vector2(x, y));
    group.add(part(new THREE.Mesh(new THREE.LatheGeometry(housing, 64), plastic(INK))));
    const capProfile = [
        [0, 0],
        [0.66, 0],
        [0.68, 0.18],
        [0.6, 0.27],
        [0.4, 0.31],
        [0, 0.32],
    ].map(([x, y]) => new THREE.Vector2(x, y));
    const cap = part(
        new THREE.Mesh(
            new THREE.LatheGeometry(capProfile, 64),
            plastic(SIGNAL, { clearcoat: 1, clearcoatRoughness: 0.08, roughness: 0.3 })
        ),
        [0, 0.26, 0]
    );
    group.add(cap);
    const tex = print(1.6, 0.34, (g, u) => {
        g.fillStyle = INK;
        g.fillRect(0, 0, 1.6 * u, 0.34 * u);
        g.fillStyle = PAPER;
        g.textAlign = 'center';
        g.textBaseline = 'middle';
        g.font = `800 ${0.2 * u}px ${FONT.display}`;
        g.fillText('SAY HELLO', 0.8 * u, 0.18 * u);
    });
    const plaque = rbox(1.6, 0.34, 0.05, 0.02, card(null, INK), [0, 0.2, 1.2]);
    plaque.rotation.x = -0.3;
    const face = new THREE.Mesh(new THREE.PlaneGeometry(1.56, 0.31), card(tex));
    face.position.z = 0.027;
    plaque.add(face);
    group.add(plaque);

    let press = 0;
    let target = 0;
    return {
        group,
        pressed: () => press,
        hits: [
            {
                object: group,
                press: () => {
                    target = 1;
                    sfx('pop', 1);
                    window.setTimeout(() => (target = 0), 180);
                    onPress();
                },
            },
        ],
        update(f) {
            press = damp(press, target, 30, f.dt);
            cap.position.y =
                0.26 - press * 0.16 + (f.reduce ? 0 : Math.max(0, Math.sin(f.time * 2.4)) * 0.02 * f.near);
        },
    };
}

/* ================================================================== confetti */

export function confetti(count = 140): {
    mesh: THREE.InstancedMesh;
    burst(at: THREE.Vector3, power?: number): void;
    update(dt: number): void;
} {
    const mesh = new THREE.InstancedMesh(
        new THREE.BoxGeometry(0.07, 0.012, 0.11),
        new THREE.MeshStandardMaterial({ roughness: 0.6 }),
        count
    );
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    mesh.frustumCulled = false;
    const colors = [SIGNAL, '#4b6fd6', '#f7f3ec', '#151515', '#2f9a6f', '#ffc247'];
    const bits = Array.from({ length: count }, (_, i) => {
        mesh.setColorAt(i, new THREE.Color(colors[i % colors.length]));
        return {
            p: new THREE.Vector3(0, -10, 0),
            v: new THREE.Vector3(),
            r: new THREE.Euler(),
            w: new THREE.Vector3(),
            life: 0,
        };
    });
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const one = new THREE.Vector3(1, 1, 1);
    mesh.count = 0;
    return {
        mesh,
        burst(at, power = 1) {
            mesh.count = count;
            for (const b of bits) {
                b.p.copy(at);
                const a = Math.random() * Math.PI * 2;
                const up = 3 + Math.random() * 3;
                b.v
                    .set(Math.cos(a) * (0.6 + Math.random() * 2), up, Math.sin(a) * (0.6 + Math.random() * 2))
                    .multiplyScalar(power);
                b.w.set(Math.random() * 12, Math.random() * 12, Math.random() * 12);
                b.life = 2.6 + Math.random();
            }
        },
        update(dt) {
            if (!mesh.count) return;
            let alive = 0;
            bits.forEach((b, i) => {
                if (b.life > 0) {
                    b.life -= dt;
                    b.v.y -= 9 * dt;
                    b.v.multiplyScalar(1 - 1.6 * dt);
                    b.p.addScaledVector(b.v, dt);
                    if (b.p.y < 0.01) {
                        b.p.y = 0.01;
                        b.v.set(0, 0, 0);
                        b.w.multiplyScalar(0.8);
                    }
                    b.r.x += b.w.x * dt;
                    b.r.y += b.w.y * dt;
                    b.r.z += b.w.z * dt;
                    alive++;
                }
                const s = b.life > 0 ? Math.min(1, b.life * 2) : 0;
                m.compose(b.p, q.setFromEuler(b.r), one.set(s, s, s));
                mesh.setMatrixAt(i, m);
            });
            mesh.instanceMatrix.needsUpdate = true;
            if (!alive) mesh.count = 0;
        },
    };
}
