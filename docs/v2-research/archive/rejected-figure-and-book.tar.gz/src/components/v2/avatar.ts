/**
 * A generated character model (image-to-3D: one textured mesh, no skeleton) made to walk.
 * Normalise it, find its joints by slicing the mesh, give it a skeleton, skin it, and drive it with
 * the same motion system as the hand-built figure. Expects a front-facing A-pose.
 */
import * as THREE from 'three';
import { MeshoptDecoder } from 'three/examples/jsm/libs/meshopt_decoder.module.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

import { animate, type Figure, laptop, type Rig, smooth } from '@/components/v2/figure';
import { subsurface } from '@/components/v2/look';

export type AvatarSpec = {
    url: string;
    /** Turn about the vertical axis so the model faces +z. */
    yaw?: number;
    laptop?: string;
    headphones?: boolean;
};

/** Height the model is scaled to, in metres; the world and the motion are tuned for it. */
const HEIGHT = 1.78;
const V = THREE.Vector3;
const clamp = THREE.MathUtils.clamp;

/* ---------------------------------------------------------------- load and normalise */

/**
 * Compressed models store attributes as normalised integers; moving or scaling them past ±1 would
 * clamp. Unpack every attribute to 32-bit floats first.
 */
function floats(g: THREE.BufferGeometry): THREE.BufferGeometry {
    for (const [name, attr] of Object.entries(g.attributes)) {
        const a = attr as THREE.BufferAttribute;
        if (a.array instanceof Float32Array && !a.normalized) continue;
        const out = new Float32Array(a.count * a.itemSize);
        for (let i = 0; i < a.count; i++)
            for (let c = 0; c < a.itemSize; c++) out[i * a.itemSize + c] = a.getComponent(i, c);
        g.setAttribute(name, new THREE.BufferAttribute(out, a.itemSize));
    }
    return g;
}

async function loadMesh(
    spec: AvatarSpec
): Promise<{ geometry: THREE.BufferGeometry; material: THREE.Material | THREE.Material[] }> {
    const loader = new GLTFLoader();
    loader.setMeshoptDecoder(MeshoptDecoder);
    const gltf = await loader.loadAsync(spec.url);
    gltf.scene.updateMatrixWorld(true);
    const geometries: THREE.BufferGeometry[] = [];
    const materials: THREE.Material[] = [];
    gltf.scene.traverse((o) => {
        if (!(o instanceof THREE.Mesh)) return;
        const g = floats((o.geometry as THREE.BufferGeometry).clone()).applyMatrix4(o.matrixWorld);
        for (const name of Object.keys(g.attributes))
            if (!['position', 'normal', 'uv'].includes(name)) g.deleteAttribute(name);
        geometries.push(g);
        materials.push(...(Array.isArray(o.material) ? o.material : [o.material]));
    });
    const geometry =
        geometries.length === 1 ? geometries[0] : (mergeGeometries(geometries, true) as THREE.BufferGeometry);
    if (spec.yaw) geometry.rotateY(spec.yaw);
    geometry.computeBoundingBox();
    const box = geometry.boundingBox as THREE.Box3;
    const scale = HEIGHT / (box.max.y - box.min.y);
    geometry.translate(-(box.min.x + box.max.x) / 2, -box.min.y, -(box.min.z + box.max.z) / 2);
    geometry.scale(scale, scale, scale);
    if (!geometry.attributes.normal) geometry.computeVertexNormals();
    // The face carries the design's soft painted light; keep everything matte with wrapped
    // light so the scene shapes the character without glossy hair or a hard terminator.
    for (const m of materials) {
        if (m instanceof THREE.MeshStandardMaterial) {
            m.metalness = 0;
            m.roughness = 0.72;
            m.metalnessMap = null;
            m.roughnessMap = null;
            // Where the hands were cut free of the thighs, show the inside rather than a hole.
            m.side = THREE.DoubleSide;
            // Milder than the hand-built figure's skin: the texture also holds white plastic and cloth.
            subsurface(m, 0.45);
        }
    }
    return { geometry, material: materials.length === 1 ? materials[0] : materials };
}

/* ---------------------------------------------------------------- find the joints */

type Cluster = [number, number, number];
/** Texture colour at a vertex (linear 0..1 RGB as a Vector3, so it has distanceTo). */
type Colour = (vertex: number) => THREE.Vector3;
type Pair = [THREE.Vector3, THREE.Vector3];
const SLICES = 180;
const DY = HEIGHT / SLICES;

type Landmarks = {
    crotch: number;
    armpit: number;
    neck: number;
    /** Per side (0 right / -x, 1 left / +x): shoulder, hand tip, hip, ankle. */
    shoulder: Pair;
    tip: Pair;
    hip: Pair;
    ankle: Pair;
    /** Which arm each vertex belongs to: -1 none, 0 right, 1 left. */
    armOf: Int8Array;
    torsoZ: number;
};

/** Groups of nearby x values in one horizontal slice, as [min, max, count]. */
function clusters(xs: number[], gap: number): Cluster[] {
    if (!xs.length) return [];
    xs.sort((a, b) => a - b);
    const out: Cluster[] = [[xs[0], xs[0], 1]];
    for (let i = 1; i < xs.length; i++) {
        const last = out[out.length - 1];
        if (xs[i] - last[1] > gap) out.push([xs[i], xs[i], 1]);
        else {
            last[1] = xs[i];
            last[2]++;
        }
    }
    return out.filter((c) => c[2] > 4);
}

/** The model cut into horizontal slices, each as its clusters of x. */
function slicer(pos: THREE.BufferAttribute): {
    at: (y: number) => Cluster[];
    central: (y: number) => Cluster | undefined;
} {
    const xs: number[][] = Array.from({ length: SLICES + 1 }, () => []);
    for (let i = 0; i < pos.count; i++) xs[clamp(Math.round(pos.getY(i) / DY), 0, SLICES)].push(pos.getX(i));
    const slices = xs.map((x) => clusters(x, 0.022));
    const at = (y: number): Cluster[] => slices[clamp(Math.round(y / DY), 0, SLICES)];
    return { at, central: (y) => at(y).find((c) => c[0] < 0.02 && c[1] > -0.02) };
}

/** Heights of the crotch, armpit and neck. */
function levels({ at, central }: ReturnType<typeof slicer>): {
    crotch: number;
    armpit: number;
    neck: number;
} {
    // Crotch: going up from the shins, the first slice where the legs join into one shape.
    let crotch = 0.45 * HEIGHT;
    for (let y = 0.2 * HEIGHT; y < 0.62 * HEIGHT; y += DY) {
        if (central(y)) {
            crotch = y;
            break;
        }
    }
    // Armpit: coming down from the shoulders, the first slice where both arms stand apart from the torso.
    const apart = (y: number): boolean => {
        const c = central(y);
        return !!c && at(y).some((k) => k[1] < c[0]) && at(y).some((k) => k[0] > c[1]);
    };
    let armpit = 0.72 * HEIGHT;
    for (let y = 0.86 * HEIGHT; y > crotch; y -= DY) {
        if (apart(y)) {
            armpit = y;
            break;
        }
    }
    // Neck: the narrowest slice of the central shape above the shoulders.
    let neck = 0.84 * HEIGHT;
    let narrow = Infinity;
    for (let y = armpit + 0.06 * HEIGHT; y < 0.93 * HEIGHT; y += DY) {
        const c = central(y);
        if (c && c[1] - c[0] < narrow) {
            narrow = c[1] - c[0];
            neck = y;
        }
    }
    return { crotch, armpit, neck };
}

type Span = [number, number];
type Track = { ranges: Map<number, Span>; merged: Set<number>; bodies: Map<number, number>; tipY: number };

/** The arm's span in one slice: the outermost shape, plus any finger shapes overlapping the span above. */
function armSpan(order: Cluster[], prev: Span | null, side: number): { span: Span; inner?: Cluster } {
    let span: Span = [order[0][0], order[0][1]];
    const overlaps = (c: Cluster | undefined): boolean =>
        Boolean(c && prev && (side ? c[1] >= prev[0] - 0.005 : c[0] <= prev[1] + 0.005));
    let k = 1;
    for (; overlaps(order[k]); k++) span = [Math.min(span[0], order[k][0]), Math.max(span[1], order[k][1])];
    return { span, inner: order[k] };
}

/**
 * Follows one arm down from the armpit: slice by slice, the outermost shape on that side whose
 * outer edge carries on from the slice above. Where the hand touches the thigh the shapes merge;
 * the arm then reaches to just inside the body's edge as last seen apart, and colour settles it
 * (see settleByColour). Where the outer edge jumps inward, the hand has ended.
 */
function trackArm(at: (y: number) => Cluster[], armpit: number, floor: number, side: number): Track {
    const track: Track = { ranges: new Map(), merged: new Set(), bodies: new Map(), tipY: armpit };
    const outerEdge = (c: Cluster | Span): number => (side ? c[1] : -c[0]);
    let prev: Span | null = null;
    let body = 0;
    for (let y = armpit - DY; y > floor; y -= DY) {
        // Shapes reaching out past the hips on this side, outermost first.
        const shapes = at(y).filter((c) => outerEdge(c) > 0.1);
        const order = side ? shapes.reverse() : shapes;
        if (!order.length || (prev && outerEdge(order[0]) < outerEdge(prev) - 0.02)) break;
        const fit = armSpan(order, prev, side);
        const inner = fit.inner;
        let span = fit.span;
        const key = Math.round(y / DY);
        if (inner) body = outerEdge(inner);
        else if (prev && span[1] - span[0] > 1.6 * (prev[1] - prev[0])) {
            span = side ? [body - 0.03, span[1]] : [span[0], 0.03 - body];
            track.merged.add(key);
        }
        track.ranges.set(key, span);
        track.bodies.set(key, body);
        prev = span;
        track.tipY = y;
    }
    return track;
}

/** First pass: above the armpit anything wider than the torso; below it, each arm's tracked span. */
function spanLabels(
    pos: THREE.BufferAttribute,
    tracks: Track[],
    half: number,
    armpit: number,
    top: number
): Int8Array {
    const armOf = new Int8Array(pos.count).fill(-1);
    for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i);
        const y = pos.getY(i);
        const side = x > 0 ? 1 : 0;
        const key = Math.round(y / DY);
        const span = tracks[side].ranges.get(key);
        const arm =
            y >= armpit
                ? Math.abs(x) > half + 0.004
                : Boolean(span && x >= span[0] - 0.004 && x <= span[1] + 0.004);
        if (!arm || y > top) continue;
        // Inside a hand-on-thigh slice the label waits for colour (-2 right, -3 left).
        armOf[i] = tracks[side].merged.has(key) && y < armpit ? -2 - side : side;
    }
    return armOf;
}

/**
 * Where a hand touches the thigh the mesh is one surface: whichever reference colour a vertex is
 * nearer, the forearm's or the thigh's just below the hand, decides (skin against denim, say).
 */
function settleByColour(
    pos: THREE.BufferAttribute,
    armOf: Int8Array,
    tracks: Track[],
    armpit: number,
    colour: Colour | null
): void {
    const mean = (pick: (i: number) => boolean): THREE.Vector3[] =>
        [0, 1].map((side) => {
            const c = new V();
            let n = 0;
            for (let i = 0; i < pos.count; i++)
                if (colour && (pos.getX(i) > 0 ? 1 : 0) === side && pick(i)) {
                    c.add(colour(i));
                    n++;
                }
            return n ? c.multiplyScalar(1 / n) : c;
        });
    const below = (i: number): number => tracks[pos.getX(i) > 0 ? 1 : 0].tipY - pos.getY(i);
    const skin = mean((i) => armOf[i] >= 0 && pos.getY(i) < armpit);
    const cloth = mean(
        (i) => armOf[i] === -1 && Math.abs(pos.getX(i)) > 0.05 && below(i) > 0.01 && below(i) < 0.06
    );
    for (let i = 0; i < pos.count; i++) {
        if (armOf[i] > -2) continue;
        const side = -2 - armOf[i];
        const c = colour?.(i);
        armOf[i] = !c || c.distanceTo(skin[side]) < c.distanceTo(cloth[side]) ? side : -1;
    }
}

/**
 * Finger tips and outer edges can fall between slices: spread each arm across mesh edges to
 * anything joined to it that lies outside the body's edge, down to just below the hand.
 */
function spreadArms(
    pos: THREE.BufferAttribute,
    armOf: Int8Array,
    near: number[][],
    tracks: Track[],
    armpit: number,
    half: number
): void {
    const outside = (n: number, side: number): boolean => {
        const y = pos.getY(n);
        const { bodies, tipY } = tracks[side];
        const body = bodies.get(Math.round(y / DY)) ?? bodies.get(Math.round(tipY / DY)) ?? half;
        return y < armpit && y > tipY - 0.09 && (side ? pos.getX(n) : -pos.getX(n)) > body + 0.003;
    };
    const queue: number[] = [];
    for (let i = 0; i < pos.count; i++) if (armOf[i] >= 0 && pos.getY(i) < armpit) queue.push(i);
    for (let v = queue.pop(); v !== undefined; v = queue.pop())
        for (const n of near[v])
            if (armOf[n] === -1 && outside(n, armOf[v])) {
                armOf[n] = armOf[v];
                queue.push(n);
            }
}

/** Each hand's tip: the centre of the arm's last few slices. */
function handTips(pos: THREE.BufferAttribute, armOf: Int8Array, tracks: Track[], fallback: Pair): Pair {
    const sum = [new V(), new V()];
    const n = [0, 0];
    const p = new V();
    for (let i = 0; i < pos.count; i++) {
        const side = armOf[i];
        if (side < 0 || pos.getY(i) >= tracks[side].tipY + 3 * DY) continue;
        sum[side].add(p.fromBufferAttribute(pos, i));
        n[side]++;
    }
    return [0, 1].map((side) => (n[side] ? sum[side].divideScalar(n[side]) : fallback[side])) as Pair;
}

/** Shoulder joints, hand tips and which vertices are arm. */
function armMarks(
    pos: THREE.BufferAttribute,
    near: number[][],
    { at, central }: ReturnType<typeof slicer>,
    { crotch, armpit, neck }: ReturnType<typeof levels>,
    colour: Colour | null
): { shoulder: Pair; tip: Pair; armOf: Int8Array } {
    // Arms often touch the torso up near the armpit, so "apart" is where they first stand clear.
    // The torso's own width is measured just below it; anything wider, up to the shoulder, is arm.
    const torso = central(armpit - 2 * DY);
    const half = torso ? Math.max(-torso[0], torso[1]) : 0.18;
    const shoulderY = armpit + 0.62 * (neck - armpit);
    const shoulder: Pair = [new V(-(half - 0.035), shoulderY, 0), new V(half - 0.035, shoulderY, 0)];
    const tracks = [0, 1].map((side) => trackArm(at, armpit, crotch - 0.25 * HEIGHT, side));
    const armOf = spanLabels(pos, tracks, half, armpit, shoulderY + 0.03 * HEIGHT);
    settleByColour(pos, armOf, tracks, armpit, colour);
    spreadArms(pos, armOf, near, tracks, armpit, half);
    const fallback: Pair = [shoulder[0].clone().setY(crotch), shoulder[1].clone().setY(crotch)];
    return { shoulder, tip: handTips(pos, armOf, tracks, fallback), armOf };
}

/** Hip and ankle joints, from the leg cluster centres below the crotch. */
function legMarks({ at }: ReturnType<typeof slicer>, crotch: number): { hip: Pair; ankle: Pair } {
    const legX = (y: number, side: number): number => {
        const cs = at(y).filter(
            (c) => (side ? c[0] > -0.01 : c[1] < 0.01) && Math.abs((c[0] + c[1]) / 2) < 0.3
        );
        // The innermost shape on each side is the leg (a hanging hand can share the slice).
        const c = side ? cs[0] : cs[cs.length - 1];
        return c ? (c[0] + c[1]) / 2 : (side ? 1 : -1) * 0.1;
    };
    const joint = (sliceY: number, y: number): Pair => [
        new V(legX(sliceY, 0), y, 0),
        new V(legX(sliceY, 1), y, 0),
    ];
    const ankleY = 0.055 * HEIGHT;
    return { hip: joint(crotch - 3 * DY, crotch + 0.04 * HEIGHT), ankle: joint(ankleY + 0.04, ankleY) };
}

function landmarks(geometry: THREE.BufferGeometry, near: number[][], colour: Colour | null): Landmarks {
    const pos = geometry.attributes.position as THREE.BufferAttribute;
    const sl = slicer(pos);
    const lv = levels(sl);
    let zSum = 0;
    for (let i = 0; i < pos.count; i++) zSum += pos.getZ(i);
    return {
        ...lv,
        ...armMarks(pos, near, sl, lv, colour),
        ...legMarks(sl, lv.crotch),
        torsoZ: zSum / pos.count,
    };
}

/** Base-colour texture at each vertex's UV, downsampled (null when the model has no texture). */
function colourSampler(
    geometry: THREE.BufferGeometry,
    material: THREE.Material | THREE.Material[]
): Colour | null {
    const map = ((Array.isArray(material) ? material[0] : material) as THREE.MeshStandardMaterial).map;
    const uv = geometry.attributes.uv as THREE.BufferAttribute | undefined;
    const image = map?.image as CanvasImageSource | undefined;
    const size = 256;
    const g = document.createElement('canvas').getContext('2d', { willReadFrequently: true });
    if (!map || !uv || !image || !g) return null;
    g.canvas.width = g.canvas.height = size;
    g.drawImage(image, 0, 0, size, size);
    const data = g.getImageData(0, 0, size, size).data;
    return (i) => {
        const x = clamp(Math.floor(uv.getX(i) * size), 0, size - 1);
        const y = clamp(Math.floor((map.flipY ? 1 - uv.getY(i) : uv.getY(i)) * size), 0, size - 1);
        const k = (y * size + x) * 4;
        return new V(data[k] / 255, data[k + 1] / 255, data[k + 2] / 255);
    };
}

/** Groups of vertices at the same position: the copies a mesh keeps along its UV seams. */
function twins(pos: THREE.BufferAttribute): number[][] {
    const groups = new Map<string, number[]>();
    for (let v = 0; v < pos.count; v++) {
        const key = `${Math.round(pos.getX(v) * 1e4)},${Math.round(pos.getY(v) * 1e4)},${Math.round(pos.getZ(v) * 1e4)}`;
        const list = groups.get(key) ?? [];
        list.push(v);
        groups.set(key, list);
    }
    return [...groups.values()].filter((g) => g.length > 1);
}

/**
 * Generated meshes carry a few loose crumbs around the hands. They never move with anything, so
 * once the arms straighten they float beside the hips: drop small islands below `belowY`.
 */
function dropCrumbs(geometry: THREE.BufferGeometry, belowY: number): void {
    const index = geometry.index;
    if (!index) return;
    const pos = geometry.attributes.position as THREE.BufferAttribute;
    const idx = index.array;
    const parent = Int32Array.from({ length: pos.count }, (_, i) => i);
    const find = (a: number): number => {
        while (parent[a] !== a) a = parent[a] = parent[parent[a]];
        return a;
    };
    for (let t = 0; t < idx.length; t += 3) {
        parent[find(idx[t])] = find(idx[t + 1]);
        parent[find(idx[t + 1])] = find(idx[t + 2]);
    }
    for (const group of twins(pos)) for (const v of group) parent[find(v)] = find(group[0]);
    const size = new Map<number, number>();
    const top = new Map<number, number>();
    for (let v = 0; v < pos.count; v++) {
        const r = find(v);
        size.set(r, (size.get(r) ?? 0) + 1);
        top.set(r, Math.max(top.get(r) ?? -Infinity, pos.getY(v)));
    }
    const crumb = (v: number): boolean =>
        (size.get(find(v)) as number) < 300 && (top.get(find(v)) as number) < belowY;
    const kept: number[] = [];
    for (let t = 0; t < idx.length; t += 3) if (!crumb(idx[t])) kept.push(idx[t], idx[t + 1], idx[t + 2]);
    geometry.setIndex(kept);
}

/** Each vertex's neighbours across triangle edges. */
function neighbours(geometry: THREE.BufferGeometry): number[][] {
    const pos = geometry.attributes.position as THREE.BufferAttribute;
    const near = Array.from({ length: pos.count }, () => [] as number[]);
    const idx = geometry.index?.array ?? [];
    for (let t = 0; t < idx.length; t += 3)
        for (let c = 0; c < 3; c++) near[idx[t + c]].push(idx[t + ((c + 1) % 3)], idx[t + ((c + 2) % 3)]);
    // Across UV seams too, so labels spread over the whole surface.
    for (const group of twins(pos)) for (const v of group) near[v].push(...group.filter((w) => w !== v));
    return near;
}

/** The label most of `around` carry (`own` keeps a tie). */
function majority(around: number[], armOf: Int8Array, own: number): number {
    const votes = new Map<number, number>();
    for (const n of around) votes.set(armOf[n], (votes.get(armOf[n]) ?? 0) + 1);
    let best = own;
    for (const [label, n] of votes) if (n > (votes.get(best) ?? 0)) best = label;
    return best;
}

/** A few rounds of majority vote among neighbours below the elbows, so stray specks join their side. */
function vote(pos: THREE.BufferAttribute, armOf: Int8Array, near: number[][], belowY: number): void {
    for (let round = 0; round < 4; round++) {
        const next = armOf.slice();
        for (let v = 0; v < pos.count; v++)
            if (pos.getY(v) <= belowY) next[v] = majority(near[v], armOf, armOf[v]);
        armOf.set(next);
    }
}

/**
 * Re-points every triangle that straddles an arm's edge below `belowY` at copies of its minority
 * vertices, so it belongs wholly to its majority side. Returns each copy's source and label.
 */
function splitStraddling(
    idx: Uint32Array,
    pos: THREE.BufferAttribute,
    armOf: Int8Array,
    belowY: number
): { source: number[]; labels: number[] } {
    const source: number[] = [];
    const labels: number[] = [];
    const copies = new Map<number, number>();
    const copyOf = (v: number, label: number): number => {
        const key = v * 4 + label + 1;
        if (!copies.has(key)) {
            copies.set(key, pos.count + source.length);
            source.push(v);
            labels.push(label);
        }
        return copies.get(key) as number;
    };
    for (let t = 0; t < idx.length; t += 3) {
        const ls = [armOf[idx[t]], armOf[idx[t + 1]], armOf[idx[t + 2]]];
        const low =
            pos.getY(idx[t]) < belowY && pos.getY(idx[t + 1]) < belowY && pos.getY(idx[t + 2]) < belowY;
        if (!low || (ls[0] === ls[1] && ls[1] === ls[2])) continue;
        const arms = ls.filter((l) => l >= 0);
        const label = arms.length >= 2 ? arms[0] : -1;
        for (let c = 0; c < 3; c++) if (ls[c] !== label) idx[t + c] = copyOf(idx[t + c], label);
    }
    return { source, labels };
}

/** Appends copies of the `source` vertices to every attribute the avatar uses. */
function appendCopies(geometry: THREE.BufferGeometry, source: number[]): void {
    for (const name of ['position', 'normal', 'uv']) {
        const a = geometry.attributes[name] as THREE.BufferAttribute | undefined;
        if (!a) continue;
        const out = new Float32Array((a.count + source.length) * a.itemSize);
        out.set(a.array as Float32Array);
        source.forEach((from, j) => {
            for (let c = 0; c < a.itemSize; c++)
                out[(a.count + j) * a.itemSize + c] = a.getComponent(from, c);
        });
        geometry.setAttribute(name, new THREE.BufferAttribute(out, a.itemSize));
    }
}

/**
 * Below the elbows a generated hand is often fused to the thigh. Split the surface along the
 * arm's edge there, so the hand pulls away cleanly instead of stretching a sheet of triangles.
 */
function cutArms(
    geometry: THREE.BufferGeometry,
    armOf: Int8Array,
    near: number[][],
    belowY: number
): Int8Array {
    if (!geometry.index) return armOf;
    const pos = geometry.attributes.position as THREE.BufferAttribute;
    vote(pos, armOf, near, belowY);
    const idx = Uint32Array.from(geometry.index.array as ArrayLike<number>);
    const { source, labels } = splitStraddling(idx, pos, armOf, belowY);
    appendCopies(geometry, source);
    geometry.setIndex(new THREE.BufferAttribute(idx, 1));
    const grown = new Int8Array(armOf.length + source.length);
    grown.set(armOf);
    grown.set(labels, armOf.length);
    return grown;
}

/* ---------------------------------------------------------------- skeleton and skin */

/** Bone order in the skeleton; skin indices refer to it. */
const B = {
    hips: 0,
    spine: 1,
    chest: 2,
    neck: 3,
    head: 4,
    jaw: 5,
    arm: [6, 9],
    fore: [7, 10],
    hand: [8, 11],
    thigh: [12, 15],
    shin: [13, 16],
    foot: [14, 17],
} as const;

/** A limb as a chain under a base bone that holds its bind direction; zeroing the base straightens it. */
function limb(
    root: THREE.Group,
    parent: THREE.Bone,
    from: THREE.Vector3,
    to: THREE.Vector3,
    cuts: number[]
): THREE.Bone[] {
    const dir = to.clone().sub(from).normalize();
    const length = from.distanceTo(to);
    const base = new THREE.Bone();
    base.position.copy(from);
    base.quaternion.setFromUnitVectors(new V(0, -1, 0), dir);
    root.add(base);
    root.updateMatrixWorld(true);
    parent.attach(base);
    const chain = [base];
    let prev = 0;
    let at: THREE.Object3D = base;
    for (const cut of cuts) {
        const b = new THREE.Bone();
        b.position.set(0, -(cut - prev) * length, 0);
        at.add(b);
        chain.push(b);
        at = b;
        prev = cut;
    }
    return chain;
}

function skinWeights(
    geometry: THREE.BufferGeometry,
    L: Landmarks,
    y: { pelvisY: number; chestY: number }
): void {
    const pos = geometry.attributes.position as THREE.BufferAttribute;
    const index = new Uint16Array(pos.count * 4);
    const weight = new Float32Array(pos.count * 4);
    const p = new V();
    const along = (a: THREE.Vector3, b: THREE.Vector3): number => {
        const ab = b.clone().sub(a);
        return p.clone().sub(a).dot(ab) / ab.lengthSq();
    };
    const headBottom = L.neck + 0.01 * HEIGHT;
    const headHeight = HEIGHT - headBottom;
    const mouthY = headBottom + 0.26 * headHeight;
    for (let i = 0; i < pos.count; i++) {
        p.fromBufferAttribute(pos, i);
        const w = new Map<number, number>();
        const add = (bone: number, v: number): void => {
            if (v > 1e-4) w.set(bone, (w.get(bone) ?? 0) + v);
        };
        const arm = L.armOf[i];
        if (arm >= 0) {
            const t = along(L.shoulder[arm], L.tip[arm]);
            const toChest = smooth(0.1, 0.0, t);
            const fore = smooth(0.42, 0.52, t);
            const hand = smooth(0.74, 0.84, t);
            add(B.chest, toChest);
            add(B.arm[arm], (1 - toChest) * (1 - fore));
            add(B.fore[arm], (1 - toChest) * fore * (1 - hand));
            add(B.hand[arm], (1 - toChest) * hand);
        } else if (p.y < L.crotch + 0.03 * HEIGHT) {
            const side = p.x > 0 ? 1 : 0;
            const t = along(L.hip[side], L.ankle[side]);
            const toHips = smooth(L.crotch - 0.01 * HEIGHT, L.crotch + 0.04 * HEIGHT, p.y);
            const shin = smooth(0.43, 0.57, t);
            const foot = smooth(L.ankle[side].y + 0.03, L.ankle[side].y - 0.01, p.y);
            add(B.hips, toHips);
            add(B.thigh[side], (1 - toHips) * (1 - shin));
            add(B.shin[side], (1 - toHips) * shin * (1 - foot));
            add(B.foot[side], (1 - toHips) * shin * foot);
        } else {
            // Trunk and head by height, blended across each joint.
            const spine = smooth(y.pelvisY - 0.03, y.pelvisY + 0.05, p.y);
            const chest = smooth(y.chestY - 0.08, y.chestY + 0.02, p.y);
            const neck = smooth(L.neck - 0.07, L.neck - 0.01, p.y);
            const head = smooth(L.neck - 0.01, L.neck + 0.04, p.y);
            const front = smooth(L.torsoZ + 0.02, L.torsoZ + 0.07, p.z);
            const jaw =
                head *
                front *
                smooth(mouthY + 0.008, mouthY - 0.03, p.y) *
                smooth(headBottom - 0.02, headBottom + 0.02, p.y);
            add(B.hips, 1 - spine);
            add(B.spine, spine * (1 - chest));
            add(B.chest, chest * (1 - neck));
            add(B.neck, neck * (1 - head));
            add(B.head, head * (1 - jaw));
            add(B.jaw, jaw);
        }
        const top = [...w.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4);
        const sum = top.reduce((s, [, v]) => s + v, 0) || 1;
        top.forEach(([bone, v], k) => {
            index[i * 4 + k] = bone;
            weight[i * 4 + k] = v / sum;
        });
        if (!top.length) {
            index[i * 4] = B.hips;
            weight[i * 4] = 1;
        }
    }
    geometry.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(index, 4));
    geometry.setAttribute('skinWeight', new THREE.Float32BufferAttribute(weight, 4));
}

function rigAvatar(
    root: THREE.Group,
    geometry: THREE.BufferGeometry,
    L: Landmarks
): { rig: Rig; bones: THREE.Bone[]; bases: THREE.Bone[] } {
    const z = L.torsoZ;
    const pelvisY = L.crotch + 0.07 * HEIGHT;
    const chestY = L.armpit - 0.04 * HEIGHT;
    const mk = (parent: THREE.Object3D, x: number, y: number, zz: number): THREE.Bone => {
        const b = new THREE.Bone();
        b.position.set(x, y, zz);
        parent.add(b);
        return b;
    };
    const hips = mk(root, 0, pelvisY, z);
    const spine = mk(hips, 0, (chestY - pelvisY) * 0.45, 0);
    const chest = mk(spine, 0, (chestY - pelvisY) * 0.55, 0);
    const neck = mk(chest, 0, L.neck - 0.015 * HEIGHT - chestY, 0);
    const head = mk(neck, 0, 0.035 * HEIGHT, 0);
    const jaw = mk(head, 0, -0.005 * HEIGHT, -0.02);

    // Arms: shoulder → elbow (47%) → wrist (79%) → tip. Legs: hip → knee (50%) → ankle.
    const arms = [0, 1].map((s) => {
        const from = L.shoulder[s].clone().setZ(z);
        const to = L.tip[s].clone();
        return limb(root, chest, from, to, [0, 0.47, 0.79]);
    });
    const legs = [0, 1].map((s) =>
        limb(root, hips, L.hip[s].clone().setZ(z), L.ankle[s].clone().setZ(z), [0, 0.5, 1])
    );

    const bones = [
        hips,
        spine,
        chest,
        neck,
        head,
        jaw,
        arms[0][1],
        arms[0][2],
        arms[0][3],
        arms[1][1],
        arms[1][2],
        arms[1][3],
        legs[0][1],
        legs[0][2],
        legs[0][3],
        legs[1][1],
        legs[1][2],
        legs[1][3],
    ];
    const bases = [arms[0][0], arms[1][0], legs[0][0], legs[1][0]];

    skinWeights(geometry, L, { pelvisY, chestY });
    const rig: Rig = {
        pelvisY,
        legs: (L.hip[0].y - L.ankle[0].y) / 0.845,
        // Where the arms only stand clear of the torso low down, the upper arm has no inner
        // surface: keep it close and move the forearm instead.
        shoulders: clamp(1.5 - (L.neck - L.armpit) / (0.2 * HEIGHT), 0.2, 1),
        hips,
        spine,
        chest,
        neck,
        head,
        arm: [arms[0][1], arms[1][1]],
        fore: [arms[0][2], arms[1][2]],
        hand: [arms[0][3], arms[1][3]],
        thigh: [legs[0][1], legs[1][1]],
        shin: [legs[0][2], legs[1][2]],
        foot: [legs[0][3], legs[1][3]],
    };
    return { rig, bones: [...bones, ...bases], bases };
}

/* ---------------------------------------------------------------- the figure */

export async function loadAvatar(spec: AvatarSpec): Promise<Figure> {
    const { geometry, material } = await loadMesh(spec);
    const root = new THREE.Group();
    dropCrumbs(geometry, HEIGHT * 0.6);
    const near = neighbours(geometry);
    const L = landmarks(geometry, near, colourSampler(geometry, material));
    L.armOf = cutArms(geometry, L.armOf, near, L.armpit);
    const { rig, bones, bases } = rigAvatar(root, geometry, L);
    root.updateMatrixWorld(true);
    const mesh = new THREE.SkinnedMesh(geometry, material);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.frustumCulled = false;
    root.add(mesh);
    mesh.bind(new THREE.Skeleton(bones));
    // Straighten the limbs out of the A-pose: from here the motion system poses them from vertical.
    for (const base of bases) base.quaternion.identity();

    if (spec.laptop) {
        const lap = laptop(spec.laptop);
        lap.position.set(-0.03, -0.12, 0.02);
        rig.hand[1].add(lap);
    }
    const jaw = bones[B.jaw];
    return animate(root, rig, {
        carry: Boolean(spec.laptop),
        music: Boolean(spec.headphones),
        face(_gx, _gy, _blink, mouth) {
            jaw.rotation.x = (mouth?.open ?? 0) * 0.16;
        },
    });
}
