'use client';

import React, { useEffect, useRef, useState } from 'react';

import clsx from 'clsx';

import { Icon, ICON } from '@/components/host/icons';
import type { Listen } from '@/components/host/useGuideInput';

type Props = {
    firstName: string;
    caption: { who: 'host' | 'you'; text: string } | null;
    touring: boolean;
    muted: boolean;
    question: string;
    prompts: string[];
    listen: Listen;
    onToggleTour: () => void;
    onNext: () => void;
    onMute: () => void;
    onQuestion: (text: string) => void;
    onAsk: (text: string) => void;
};

/** Captions (always on), tour controls, and the ask box. */
export default function Guide(p: Props): React.JSX.Element {
    // Phones show the ask box on demand; wide screens always show it.
    const [asking, setAsking] = useState(false);
    const field = useRef<HTMLInputElement>(null);
    useEffect(() => {
        if (asking) field.current?.focus();
    }, [asking]);
    return (
        <aside className={clsx('v2-guide', asking && 'is-asking')} aria-label={`${p.firstName}, your guide`}>
            <p className="v2-caption" aria-live="polite">
                <span className="v2-who">{p.caption?.who === 'you' ? 'You' : p.firstName}</span>
                {p.caption?.text ?? 'Click anything on the desk, or ask me.'}
            </p>
            <div className="v2-controls">
                <button
                    type="button"
                    className="v2-icon"
                    onClick={p.onToggleTour}
                    aria-label={p.touring ? 'Pause the tour' : 'Play the tour'}
                >
                    <Icon d={p.touring ? ICON.pause : ICON.play} />
                </button>
                <button type="button" className="v2-icon" onClick={p.onNext} aria-label="Next stop">
                    <Icon d={ICON.next} />
                </button>
                <button
                    type="button"
                    className="v2-icon"
                    onClick={p.onMute}
                    aria-pressed={p.muted}
                    aria-label={p.muted ? 'Sound on' : 'Mute'}
                >
                    <Icon d={p.muted ? ICON.muted : ICON.sound} />
                </button>
                <button
                    type="button"
                    className="v2-icon v2-ask-toggle"
                    onClick={() => setAsking((a) => !a)}
                    aria-expanded={asking}
                    aria-controls="v2-ask"
                    aria-label={asking ? 'Close the question box' : 'Ask a question'}
                >
                    <Icon d={asking ? ICON.close : ICON.ask} />
                </button>
                <form
                    id="v2-ask"
                    className="v2-ask"
                    onSubmit={(event) => {
                        event.preventDefault();
                        p.onAsk(p.question);
                        setAsking(false);
                    }}
                >
                    <label className="v2-sr" htmlFor="v2-q">
                        Ask {p.firstName} about work, experience, skills or contact
                    </label>
                    <input
                        ref={field}
                        id="v2-q"
                        list="v2-prompts"
                        value={p.question}
                        onChange={(event) => p.onQuestion(event.target.value)}
                        placeholder={p.listen.listening ? 'Listening…' : 'Ask me…'}
                        autoComplete="off"
                    />
                    <datalist id="v2-prompts">
                        {p.prompts.map((prompt) => (
                            <option key={prompt} value={prompt} />
                        ))}
                    </datalist>
                    {p.listen.canListen && (
                        <button
                            type="button"
                            className={clsx('v2-icon', p.listen.listening && 'is-on')}
                            onClick={p.listen.toggle}
                            aria-pressed={p.listen.listening}
                            aria-label="Ask with your voice"
                        >
                            <Icon d={ICON.mic} />
                        </button>
                    )}
                    <button type="submit" className="v2-icon" aria-label="Ask">
                        <Icon d={ICON.send} />
                    </button>
                </form>
            </div>
        </aside>
    );
}
