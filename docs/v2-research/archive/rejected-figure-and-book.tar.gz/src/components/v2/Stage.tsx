'use client';

import React, { useEffect, useRef } from 'react';

import { loadImage } from '@/components/v2/art';
import { loadAvatar } from '@/components/v2/avatar';
import { buildFigure, type FigureSpec, type Mouth } from '@/components/v2/figure';
import type { Model } from '@/components/v2/model';
import type { Fonts } from '@/components/v2/Poster';
import { FONT } from '@/components/v2/print';
import { createWorld, type Sound, type World } from '@/components/v2/world';

export type StageProps = {
    figure: FigureSpec;
    model: Model;
    narrow: boolean;
    reduce: boolean;
    fonts: () => Fonts;
    input: { t: number };
    mouth: () => Mouth | null;
    sfx: (name: Sound, amount?: number) => void;
    onHello: () => void;
    onWorld: (world: World | null) => void;
    onReady: () => void;
};

/** Mounts the 3D world on a fixed full-screen canvas. Lazy: three.js lives in this chunk. */
// Loaded with React.lazy(() => import(...)) from V2.tsx, which fallow does not trace.
// fallow-ignore-next-line unused-export
export default function Stage(props: StageProps): React.JSX.Element {
    const canvas = useRef<HTMLCanvasElement>(null);
    const latest = useRef(props);
    latest.current = props;
    const { figure, model, narrow, reduce } = props;

    useEffect(() => {
        let world: World | null = null;
        let dead = false;
        const fonts = latest.current.fonts();
        Object.assign(FONT, fonts);
        // The generated model (if any) and the box print load with the fonts; a model that fails falls back to the hand-built figure.
        const character = figure.model
            ? loadAvatar({
                  url: figure.model,
                  yaw: figure.modelYaw,
                  laptop: figure.laptop,
                  headphones: Boolean(figure.headphones),
              }).catch((error: unknown) => {
                  // eslint-disable-next-line no-console -- a broken model should be visible in the console, not silent
                  console.error('[v2] model failed to load; using the built figure', error);
                  return null;
              })
            : Promise.resolve(null);
        void Promise.all([
            character,
            loadImage(figure.cutout),
            document.fonts.load(`800 40px ${fonts.display}`).catch(() => undefined),
            document.fonts.load(`700 20px ${fonts.body}`).catch(() => undefined),
            document.fonts.load(`600 20px ${fonts.mono}`).catch(() => undefined),
        ]).then(([avatar, cutout]) => {
            if (dead || !canvas.current) return;
            world = createWorld({
                canvas: canvas.current,
                figure,
                character: avatar ?? buildFigure(figure),
                cutout,
                model,
                narrow,
                reduce,
                input: latest.current.input,
                mouth: () => latest.current.mouth(),
                sfx: (name, amount) => latest.current.sfx(name, amount),
                onHello: () => latest.current.onHello(),
                onReady: () => latest.current.onReady(),
            });
            latest.current.onWorld(world);
        });
        const onResize = (): void => world?.resize();
        window.addEventListener('resize', onResize);
        return () => {
            dead = true;
            window.removeEventListener('resize', onResize);
            world?.dispose();
            latest.current.onWorld(null);
        };
    }, [figure, model, narrow, reduce]);

    return <canvas ref={canvas} className="v2-canvas" aria-hidden="true" />;
}
