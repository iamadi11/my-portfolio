/**
 * The guide, built in code: a slim figure of the owner with human proportions (Gen Z styling:
 * over-ear headphones, a laptop in one hand), on a procedural skeleton that walks, runs, climbs,
 * idles, gestures, waves and lip-syncs. No model file: every part comes from FigureSpec colours.
 * Units: metres. Feet on y = 0, facing +z; the figure's left is +x.
 */
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';

import { subsurface } from '@/components/v2/look';

export type FigureSpec = {
    skin: string;
    hair: string;
    eyes: string;
    shirt: string;
    pants: string;
    shoes: string;
    /** Leave out for none. */
    beard?: string;
    glasses?: string;
    headphones?: string;
    laptop?: string;
    /** A generated character model (GLB, front-facing A-pose) to use instead of the hand-built figure. */
    model?: string;
    /** Turn the model about the vertical axis so it faces the camera. */
    modelYaw?: number;
    /** The same character as a flat image with transparency, printed in the box before it turns 3D. */
    cutout?: string;
};

export type Mouth = { open: number; wide: number; round: number };

export type FigureInput = {
    /** Where to look, -1..1 in each axis, relative to the head on screen. */
    look: { x: number; y: number };
    mouth: Mouth | null;
    /** 0..1: right arm up, waving. */
    wave: number;
    /** Ground speed in m/s, and -1..1 while stepping down or up. */
    speed: number;
    climb: number;
};

export type Figure = {
    root: THREE.Group;
    /** Invisible capsule for pointer hits. */
    hit: THREE.Mesh;
    update(dt: number, input: FigureInput): void;
    /** A little wave and a look at the visitor. */
    react(): void;
    /** Called on each footfall while walking. */
    onStep: (strength: number) => void;
};

const V = THREE.Vector3;
type V3 = THREE.Vector3;
const clamp = THREE.MathUtils.clamp;
const lerp = THREE.MathUtils.lerp;
const damp = THREE.MathUtils.damp;
/** Smoothstep of x from a to b (a may exceed b for a falling edge). */
export const smooth = (a: number, b: number, x: number): number => {
    const t = clamp((x - a) / (b - a), 0, 1);
    return t * t * (3 - 2 * t);
};
const bell = (x: number, c: number, s: number): number => Math.exp(-((x - c) ** 2) / (2 * s * s));
const blob = (x: number, y: number, cx: number, cy: number, sx: number, sy: number): number =>
    Math.exp(-((x - cx) ** 2) / (2 * sx * sx) - (y - cy) ** 2 / (2 * sy * sy));
/** Stable noise in -0.5..0.5. */
const hash = (a: number, b: number): number => {
    const s = Math.sin(a * 127.1 + b * 311.7) * 43758.5453;
    return s - Math.floor(s) - 0.5;
};

/** Catmull-Rom through sorted [x, y] keys, clamped at the ends. */
function spline(keys: [number, number][]): (x: number) => number {
    const n = keys.length;
    return (x) => {
        if (x <= keys[0][0]) return keys[0][1];
        if (x >= keys[n - 1][0]) return keys[n - 1][1];
        let i = 0;
        while (x > keys[i + 1][0]) i++;
        const [x1, y1] = keys[i];
        const [x2, y2] = keys[i + 1];
        const y0 = keys[Math.max(0, i - 1)][1];
        const y3 = keys[Math.min(n - 1, i + 2)][1];
        const t = (x - x1) / (x2 - x1);
        return (
            0.5 *
            (2 * y1 +
                (y2 - y0) * t +
                (2 * y0 - 5 * y1 + 4 * y2 - y3) * t * t +
                (3 * y1 - y0 - 3 * y2 + y3) * t * t * t)
        );
    };
}

/* ================================================================== head
 * Head units: half the head's height is 1 (chin y = -1, crown y = 1, eye line y = 0), face toward +z.
 * The head is a grid of (angle round the head, height); profiles give the front view width, the
 * face depth and the skull depth at each height, and a height field sculpts the face on top.
 */

/** Head half-height in metres: a 27 cm head, a touch big for appeal (animated-film proportions). */
const HEAD = 0.148;
const MOUTH_Y = -0.53;
const EYE = { x: 0.27, y: 0.0 };

const W = spline([
    [-1, 0],
    [-0.97, 0.14],
    [-0.9, 0.27],
    [-0.8, 0.39],
    [-0.68, 0.47],
    [-0.55, 0.535],
    [-0.35, 0.6],
    [-0.1, 0.655],
    [0.2, 0.675],
    [0.45, 0.655],
    [0.65, 0.6],
    [0.8, 0.5],
    [0.92, 0.33],
    [0.98, 0.17],
    [1, 0],
]);
const D = spline([
    [-1, 0],
    [-0.97, 0.22],
    [-0.9, 0.45],
    [-0.8, 0.6],
    [-0.65, 0.7],
    [-0.5, 0.75],
    [-0.3, 0.78],
    [0, 0.78],
    [0.3, 0.83],
    [0.5, 0.8],
    [0.7, 0.68],
    [0.85, 0.5],
    [0.95, 0.28],
    [1, 0],
]);
const B = spline([
    [-1, 0],
    [-0.95, 0.2],
    [-0.85, 0.36],
    [-0.7, 0.52],
    [-0.5, 0.68],
    [-0.2, 0.84],
    [0.1, 0.94],
    [0.4, 0.96],
    [0.65, 0.85],
    [0.85, 0.6],
    [0.95, 0.35],
    [1, 0],
]);
/** The jaw and chin sit forward of the skull. */
const CZ = spline([
    [-1, 0.32],
    [-0.85, 0.22],
    [-0.65, 0.08],
    [-0.3, 0],
    [1, 0],
]);
const noseH = spline([
    [-0.42, 0],
    [-0.36, 0.17],
    [-0.3, 0.24],
    [-0.2, 0.17],
    [-0.05, 0.11],
    [0.1, 0.06],
    [0.2, 0],
]);
const noseW = spline([
    [-0.42, 0.14],
    [-0.32, 0.13],
    [-0.15, 0.07],
    [0.15, 0.055],
]);

/** Face relief on the front of the head, as extra depth at (x, y). */
function relief(x: number, y: number): number {
    const ax = Math.abs(x);
    let h = noseH(y) * Math.exp(-(x * x) / (2 * noseW(y) ** 2));
    h += 0.05 * blob(ax, y, 0.11, -0.33, 0.05, 0.045);
    h += 0.045 * bell(y, 0.3, 0.05) * smooth(0.55, 0.25, ax);
    h -= 0.13 * blob(ax, y, EYE.x, EYE.y, 0.1, 0.075);
    h += 0.06 * blob(ax, y, 0.42, -0.2, 0.14, 0.12);
    h += 0.035 * blob(x, y, 0, -0.47, 0.14, 0.035);
    h += 0.04 * blob(x, y, 0, -0.59, 0.12, 0.035);
    h -= 0.02 * blob(ax, y, 0.18, -0.53, 0.04, 0.04);
    h += 0.05 * blob(x, y, 0, -0.83, 0.16, 0.08);
    return h;
}

/** The skin at angle phi round the head (pi/2 = front) and height y. */
function headAt(phi: number, y: number, out: V3 = new V()): V3 {
    const c = Math.cos(phi);
    const s = Math.sin(phi);
    const x = W(y) * c;
    let z = CZ(y) + (s >= 0 ? D(y) : B(y)) * s;
    if (s > 0) z += relief(x, y) * smooth(0.12, 0.5, s);
    return out.set(x, y, z);
}

/** The front of the face at (x, y), and its normal. */
function face(x: number, y: number, lift = 0): { pos: V3; normal: V3 } {
    const at = (u: number, v: number): V3 => {
        const r = u / Math.max(1e-3, W(v));
        return headAt(Math.atan2(Math.sqrt(Math.max(0, 1 - r * r)), r), v);
    };
    const pos = at(x, y);
    const e = 0.01;
    const normal = at(x + e, y)
        .sub(pos)
        .cross(at(x, y + e).sub(pos))
        .normalize();
    return { pos: pos.addScaledVector(normal, lift), normal };
}

type Grid = {
    geometry: THREE.BufferGeometry;
    /** Per vertex: angle from the front (0..pi), side (-1 | 1), height, x. */
    a: Float32Array;
    side: Float32Array;
    y: Float32Array;
    x: Float32Array;
};

const COLS = 200;
const ROWS = 150;

/** The head as a closed grid (wrapping round, poles collapsed), with smooth normals. */
function headGrid(): Grid {
    const n = COLS * (ROWS + 1);
    const pos = new Float32Array(n * 3);
    const a = new Float32Array(n);
    const side = new Float32Array(n);
    const ys = new Float32Array(n);
    const xs = new Float32Array(n);
    const p = new V();
    for (let j = 0; j <= ROWS; j++) {
        const y = -Math.cos((Math.PI * j) / ROWS);
        for (let i = 0; i < COLS; i++) {
            const phi = (i / COLS) * Math.PI * 2;
            const k = j * COLS + i;
            headAt(phi, y, p);
            pos.set([p.x, p.y, p.z], k * 3);
            a[k] = Math.acos(clamp(Math.sin(phi), -1, 1));
            side[k] = Math.cos(phi) >= 0 ? 1 : -1;
            ys[k] = y;
            xs[k] = p.x;
        }
    }
    const index: number[] = [];
    for (let j = 0; j < ROWS; j++) {
        for (let i = 0; i < COLS; i++) {
            const i2 = (i + 1) % COLS;
            const q = j * COLS;
            const r = (j + 1) * COLS;
            index.push(q + i, r + i, q + i2, q + i2, r + i, r + i2);
        }
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geometry.setIndex(index);
    geometry.computeVertexNormals();
    return { geometry, a, side, y: ys, x: xs };
}

/**
 * A shell over the head: each vertex pushed out along its normal by offset(k) head units. Where
 * the offset is ≤ 0 it sits under the skin; triangles wholly under it are dropped.
 */
function shell(
    grid: Grid,
    offset: (k: number) => number,
    color?: (k: number) => THREE.Color
): THREE.BufferGeometry {
    const base = grid.geometry.attributes.position as THREE.BufferAttribute;
    const normal = grid.geometry.attributes.normal as THREE.BufferAttribute;
    const n = base.count;
    const pos = new Float32Array(n * 3);
    const lift = new Float32Array(n);
    const colors = color ? new Float32Array(n * 3) : null;
    for (let k = 0; k < n; k++) {
        lift[k] = offset(k);
        const o = lift[k];
        pos[k * 3] = base.getX(k) + normal.getX(k) * o;
        pos[k * 3 + 1] = base.getY(k) + normal.getY(k) * o;
        pos[k * 3 + 2] = base.getZ(k) + normal.getZ(k) * o;
        if (colors && color) {
            const c = color(k);
            colors.set([c.r, c.g, c.b], k * 3);
        }
    }
    const src = grid.geometry.index as THREE.BufferAttribute;
    const kept: number[] = [];
    for (let i = 0; i < src.count; i += 3) {
        const [p, q, r] = [src.getX(i), src.getX(i + 1), src.getX(i + 2)];
        if (Math.max(lift[p], lift[q], lift[r]) > 0) kept.push(p, q, r);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    if (colors) g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    g.setIndex(kept);
    g.computeVertexNormals();
    return g;
}

/** Textured crop: short faded sides, longer top pushed up and slightly to one side. */
const hairLine = spline([
    [0, 0.62],
    [0.35, 0.6],
    [0.6, 0.5],
    [0.9, 0.37],
    [1.15, 0.3],
    [1.45, 0.27],
    [1.7, 0.18],
    [2.1, -0.08],
    [2.6, -0.42],
    [3.15, -0.56],
]);

function hairShell(grid: Grid, spec: FigureSpec): THREE.BufferGeometry {
    const lineAt = hairLine;
    const hair = new THREE.Color(spec.hair);
    const scalp = new THREE.Color(spec.skin).lerp(hair, 0.8);
    const thick = new Float32Array(grid.y.length);
    const off = (k: number): number => {
        const a = grid.a[k];
        const y = grid.y[k];
        const line = lineAt(a) - 0.36 * bell(a, 1.2, 0.09);
        const m = smooth(line - 0.02, line + 0.09, y);
        if (m <= 0) return -0.02;
        // Sides: a fade, a few millimetres. Top: up to ~2.5 cm of texture.
        const top = smooth(0.38, 0.85, y) * (1 - 0.35 * smooth(1.6, 2.8, a));
        let t = 0.035 + 0.16 * top;
        t += 0.07 * Math.exp(-(a * a) / (2 * 0.45 ** 2)) * smooth(0.5, 0.78, y);
        const sweep = grid.side[k] * a;
        // Big sculpted locks, like an animated film, rather than fine texture.
        const clump =
            Math.sin(sweep * 5 + y * 4) * 0.6 +
            Math.sin(sweep * 11 - y * 9 + 1.7) * 0.35 +
            hash(Math.round(sweep * 8), Math.round(y * 10)) * 0.3;
        t += top * 0.055 * clump;
        thick[k] = t;
        return m * t;
    };
    return shell(grid, off, (k) => scalp.clone().lerp(hair, smooth(0.03, 0.09, thick[k])));
}

const beardLine = spline([
    [0, -0.64],
    [0.3, -0.62],
    [0.55, -0.52],
    [0.8, -0.38],
    [1.0, -0.24],
    [1.15, -0.1],
    [1.27, 0.02],
]);

/**
 * Stubble density 0..1 at a head vertex: jaw, chin and a moustache that follows the upper lip,
 * with a clean gap round the lips. Painted into the skin colour (no geometry, so no hard edge).
 */
function stubble(a: number, x: number, y: number): number {
    let m = smooth(beardLine(a) + 0.04, beardLine(a) - 0.06, y) * smooth(1.38, 1.18, a);
    if (a < 1.2) {
        const v = y - MOUTH_Y;
        const ax = Math.abs(x);
        const droop = 0.03 * (ax / 0.24) ** 2;
        const tache =
            smooth(0.27, 0.16, ax) *
            smooth(0.045 - droop, 0.075 - droop, v) *
            smooth(0.17 - droop, 0.12 - droop, v);
        const patch = blob(x, v, 0, -0.17, 0.045, 0.05);
        m = Math.max(m, tache * 1.15, patch);
        m *= smooth(0.8, 1.6, (x / 0.23) ** 2 + (v / 0.1) ** 2);
    }
    return m;
}

/** An eyebrow: a flat, tapered ribbon laid on the brow ridge, thick at the inner end. */
function brow(side: number): THREE.BufferGeometry {
    const N = 14;
    const R = 8;
    const pos: number[] = [];
    const index: number[] = [];
    const along = new V();
    const across = new V();
    for (let i = 0; i <= N; i++) {
        const t = i / N;
        const x = side * (0.09 + 0.42 * t);
        const y = 0.27 + 0.06 * Math.sin(Math.PI * Math.min(1, t * 1.25)) - 0.03 * t;
        const { pos: p, normal } = face(x, y, 0.012);
        const next = face(side * (0.09 + 0.42 * Math.min(1, t + 0.02)), y, 0.012).pos;
        along.copy(next).sub(p).normalize();
        across.copy(normal).cross(along).normalize();
        const h = lerp(0.045, 0.015, t ** 0.8);
        for (let k = 0; k < R; k++) {
            const a = (k / R) * Math.PI * 2;
            const q = p
                .clone()
                .addScaledVector(across, Math.cos(a) * h)
                .addScaledVector(normal, Math.sin(a) * 0.011);
            pos.push(q.x, q.y, q.z);
        }
    }
    for (let i = 0; i < N; i++) {
        for (let k = 0; k < R; k++) {
            const a = i * R + k;
            const b = i * R + ((k + 1) % R);
            index.push(a, a + R, b, b, a + R, b + R);
        }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setIndex(
        side > 0 ? index : index.map((v, n) => (n % 3 === 1 ? index[n + 1] : n % 3 === 2 ? index[n - 1] : v))
    );
    g.computeVertexNormals();
    return g;
}

/** Painted depth on the skin: warmth on cheeks and nose, shade under the nose and brow. */
function skinColors(grid: Grid, spec: FigureSpec): THREE.BufferAttribute {
    const skin = new THREE.Color(spec.skin);
    const beard = spec.beard ? new THREE.Color(spec.beard) : null;
    // Multiplier that turns the skin colour into the beard colour.
    const toBeard = beard
        ? [beard.r / skin.r, beard.g / skin.g, beard.b / skin.b].map((v) => Math.min(1, v))
        : [1, 1, 1];
    const n = grid.y.length;
    const colors = new Float32Array(n * 3);
    for (let k = 0; k < n; k++) {
        const x = grid.x[k];
        const y = grid.y[k];
        const front = grid.a[k] < 1.3 ? 1 : 0;
        const ax = Math.abs(x);
        const warm = front * Math.max(blob(ax, y, 0.38, -0.2, 0.14, 0.12), blob(x, y, 0, -0.26, 0.08, 0.08));
        const shade =
            front *
            (0.16 * blob(x, y, 0, -0.39, 0.13, 0.025) +
                0.25 * blob(ax, y, 0.07, -0.36, 0.025, 0.018) +
                0.08 * blob(ax, y, EYE.x, EYE.y + 0.06, 0.12, 0.05));
        // Short hairs at the hairline: a soft darkening under the hair's edge hides its geometry.
        const line = hairLine(grid.a[k]) - 0.36 * bell(grid.a[k], 1.2, 0.09);
        const fuzz = 0.45 * smooth(line - 0.07, line + 0.03, y);
        const l = (1 - shade) * (1 - fuzz);
        // Stubble: dense on the chin, speckled toward its edges.
        const speckle = hash(x * 97, y * 89) + 0.5;
        const d = beard ? clamp(stubble(grid.a[k], x, y) * (0.8 + 0.5 * (speckle - 0.5)), 0, 0.92) : 0;
        colors.set(
            [
                l * lerp(1, toBeard[0], d),
                l * (1 - 0.13 * warm) * lerp(1, toBeard[1], d),
                l * (1 - 0.16 * warm) * lerp(1, toBeard[2], d),
            ],
            k * 3
        );
    }
    return new THREE.BufferAttribute(colors, 3);
}

/* ================================================================== materials */

const fabric = (
    color: string,
    extra: THREE.MeshPhysicalMaterialParameters = {}
): THREE.MeshPhysicalMaterial =>
    new THREE.MeshPhysicalMaterial({
        color,
        roughness: 0.88,
        sheen: 0.5,
        sheenRoughness: 0.6,
        sheenColor: new THREE.Color(color).offsetHSL(0, 0, 0.25),
        ...extra,
    });
const plastic = (
    color: string,
    extra: THREE.MeshPhysicalMaterialParameters = {}
): THREE.MeshPhysicalMaterial =>
    new THREE.MeshPhysicalMaterial({
        color,
        roughness: 0.4,
        clearcoat: 0.3,
        clearcoatRoughness: 0.4,
        ...extra,
    });
const skinMaterial = (spec: FigureSpec, vertexColors = false): THREE.MeshPhysicalMaterial =>
    subsurface(
        new THREE.MeshPhysicalMaterial({
            color: spec.skin,
            roughness: 0.6,
            vertexColors,
        })
    );

/** Twill lines for denim, used as a bump map. */
function twill(): THREE.CanvasTexture {
    const c = document.createElement('canvas');
    c.width = 128;
    c.height = 128;
    const g = c.getContext('2d') as CanvasRenderingContext2D;
    g.fillStyle = '#808080';
    g.fillRect(0, 0, 128, 128);
    for (let i = -128; i < 256; i += 4) {
        g.strokeStyle = i % 8 ? '#9a9a9a' : '#5e5e5e';
        g.lineWidth = 1.6;
        g.beginPath();
        g.moveTo(i, 0);
        g.lineTo(i + 128, 128);
        g.stroke();
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(10, 22);
    return tex;
}

function eyeTexture(iris: string): THREE.CanvasTexture {
    // The pole faces forward, so the iris is a band at the top of the texture; streaks run down it.
    const c = document.createElement('canvas');
    c.width = 256;
    c.height = 256;
    const g = c.getContext('2d') as CanvasRenderingContext2D;
    const grad = g.createLinearGradient(0, 0, 0, 256);
    grad.addColorStop(0, '#050403');
    grad.addColorStop(0.1, '#050403');
    grad.addColorStop(0.115, new THREE.Color(iris).multiplyScalar(0.75).getStyle());
    grad.addColorStop(0.19, new THREE.Color(iris).offsetHSL(0, 0, 0.08).getStyle());
    grad.addColorStop(0.24, new THREE.Color(iris).multiplyScalar(0.4).getStyle());
    grad.addColorStop(0.255, '#f6f2ec');
    grad.addColorStop(0.6, '#f7f3ee');
    grad.addColorStop(1, '#e2c9bd');
    g.fillStyle = grad;
    g.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 90; i++) {
        g.strokeStyle = `rgba(${i % 3 ? '255,220,170' : '30,15,5'},${0.12 + (i % 5) * 0.03})`;
        g.lineWidth = 1;
        const x = (i / 90) * 256 + hash(i, 1) * 3;
        g.beginPath();
        g.moveTo(x, 0.11 * 256);
        g.lineTo(x + hash(i, 2) * 4, 0.235 * 256);
        g.stroke();
    }
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
}

/* ================================================================== geometry helpers */

function mesh(
    geometry: THREE.BufferGeometry,
    material: THREE.Material,
    at?: [number, number, number]
): THREE.Mesh {
    const m = new THREE.Mesh(geometry, material);
    if (at) m.position.set(...at);
    m.castShadow = true;
    m.receiveShadow = true;
    return m;
}

const rbox = (
    w: number,
    h: number,
    d: number,
    r: number,
    mat: THREE.Material,
    at?: [number, number, number]
): THREE.Mesh => mesh(new RoundedBoxGeometry(w, h, d, 3, Math.min(r, w / 2, h / 2, d / 2) * 0.999), mat, at);

/** A rounded bar from a to b. */
function bar(a: V3, b: V3, w: number, h: number, material: THREE.Material): THREE.Mesh {
    const m = rbox(w, h, a.distanceTo(b), Math.min(w, h) * 0.45, material);
    m.position.copy(a).add(b).multiplyScalar(0.5);
    m.lookAt(b);
    return m;
}

/**
 * A tube through rings [y, rx, rz, cz] (rx, rz: half width and depth, cz: centre z), with
 * superellipse sections (p = 2 is an ellipse, higher is boxier) and Catmull-Rom between rings.
 * The seam's normals are averaged so it does not show. UVs run round (u) and along (v).
 */
function loft(rings: number[][], { seg = 40, p = 2, steps = 3 } = {}): THREE.BufferGeometry {
    const col = (c: number): ((t: number) => number) =>
        spline(rings.map((r, i): [number, number] => [i, r[c]]));
    const [fy, fx, fz, fc] = [col(0), col(1), col(2), col(3)];
    const count = (rings.length - 1) * steps + 1;
    const down = rings[0][0] > rings[rings.length - 1][0];
    const pos: number[] = [];
    const uv: number[] = [];
    for (let j = 0; j < count; j++) {
        const t = j / steps;
        const [y, rx, rz, cz] = [fy(t), fx(t), fz(t), fc(t)];
        for (let i = 0; i <= seg; i++) {
            // Wind the ring the other way for downward tubes, so faces point out either way.
            const th = (i / seg) * Math.PI * 2 * (down ? -1 : 1);
            const c = Math.cos(th);
            const s = Math.sin(th);
            pos.push(
                rx * Math.sign(c) * Math.abs(c) ** (2 / p),
                y,
                cz + rz * Math.sign(s) * Math.abs(s) ** (2 / p)
            );
            uv.push(i / seg, j / (count - 1));
        }
    }
    const index: number[] = [];
    for (let j = 0; j < count - 1; j++) {
        for (let i = 0; i < seg; i++) {
            const a = j * (seg + 1) + i;
            const b = a + seg + 1;
            index.push(a, b, a + 1, a + 1, b, b + 1);
        }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(index);
    g.computeVertexNormals();
    const n = g.attributes.normal as THREE.BufferAttribute;
    const v = new V();
    for (let j = 0; j < count; j++) {
        const a = j * (seg + 1);
        const b = a + seg;
        v.set(n.getX(a) + n.getX(b), n.getY(a) + n.getY(b), n.getZ(a) + n.getZ(b)).normalize();
        n.setXYZ(a, v.x, v.y, v.z);
        n.setXYZ(b, v.x, v.y, v.z);
    }
    return g;
}

/** Skin a limb tube to two bones, blending across the joint at height jy (± blend). */
function skinLimb(g: THREE.BufferGeometry, jy: number, blend: number): void {
    const pos = g.attributes.position as THREE.BufferAttribute;
    const index = new Uint16Array(pos.count * 4);
    const weight = new Float32Array(pos.count * 4);
    for (let i = 0; i < pos.count; i++) {
        const w = smooth(jy + blend, jy - blend, pos.getY(i));
        index.set([0, 1, 0, 0], i * 4);
        weight.set([1 - w, w, 0, 0], i * 4);
    }
    g.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(index, 4));
    g.setAttribute('skinWeight', new THREE.Float32BufferAttribute(weight, 4));
}

/* ================================================================== the head, assembled */

type HeadRig = { group: THREE.Group; setMouth: (m: Mouth) => void; lids: THREE.Mesh[]; balls: THREE.Mesh[] };

function mouthRig(head: THREE.Group, lipColor: string): (m: Mouth) => void {
    const N = 25;
    const R = 6;
    type Strip = { pos: THREE.BufferAttribute; geometry: THREE.BufferGeometry };
    const make = (color: string, offset: number, lit: boolean): Strip => {
        const geometry = new THREE.BufferGeometry();
        const pos = new THREE.BufferAttribute(new Float32Array(N * R * 3), 3);
        pos.setUsage(THREE.DynamicDrawUsage);
        geometry.setAttribute('position', pos);
        const index: number[] = [];
        for (let r = 0; r < R - 1; r++) {
            for (let i = 0; i < N - 1; i++) {
                const a = r * N + i;
                index.push(a, a + N, a + 1, a + 1, a + N, a + N + 1);
            }
        }
        geometry.setIndex(index);
        const options = {
            color,
            side: THREE.DoubleSide,
            polygonOffset: true,
            polygonOffsetFactor: -1 - offset,
            polygonOffsetUnits: -4 - offset * 4,
        };
        const m = new THREE.Mesh(
            geometry,
            lit
                ? new THREE.MeshStandardMaterial({ ...options, roughness: 0.45 })
                : new THREE.MeshBasicMaterial(options)
        );
        m.renderOrder = offset;
        m.frustumCulled = false;
        head.add(m);
        return { pos, geometry };
    };
    const lips = make(lipColor, 0, true);
    const hole = make('#26100d', 1, false);
    const teeth = make('#e9e4dc', 2, true);
    /** Fill rows between two curves (as offsets from the mouth line), each point on the face. */
    const fill = (
        strip: Strip,
        u: (t: number) => number,
        top: (t: number) => number,
        bottom: (t: number) => number,
        lift: number
    ): void => {
        for (let r = 0; r < R; r++) {
            const f = r / (R - 1);
            for (let i = 0; i < N; i++) {
                const t = (i / (N - 1)) * 2 - 1;
                const v = lerp(top(t), bottom(t), f);
                const p = face(u(t), MOUTH_Y + v, lift).pos;
                strip.pos.setXYZ(r * N + i, p.x, p.y, p.z);
            }
        }
        strip.pos.needsUpdate = true;
        strip.geometry.computeVertexNormals();
    };
    let last = '';
    return (m) => {
        const key = `${m.open.toFixed(3)}|${m.wide.toFixed(3)}|${m.round.toFixed(3)}`;
        if (key === last) return;
        last = key;
        const w = 0.21 * (1 + 0.15 * m.wide - 0.32 * m.round);
        const smile = 0.04 * (1 - 0.5 * m.open) * (1 - m.round);
        const middle = (t: number): number => Math.pow(Math.max(0, 1 - t * t), 0.75);
        const top = (t: number): number => smile * t * t + 0.006 * middle(t);
        const bottom = (t: number): number =>
            smile * t * t - (0.004 + (0.13 * m.open + 0.025 * m.round) * middle(t));
        const edge = (t: number): number => 1 - t ** 4;
        // Lips: a band above and below the opening; then the dark inside; then the upper teeth.
        fill(
            lips,
            (t) => w * 1.04 * t,
            (t) => top(t) + 0.026 * edge(t),
            (t) => bottom(t) - 0.05 * edge(t),
            0.004
        );
        fill(hole, (t) => w * t, top, bottom, 0.008);
        const depth = (t: number): number =>
            Math.min(0.03, m.open * 0.08) * Math.sqrt(Math.max(0, 1 - (t / 0.95) ** 2));
        fill(
            teeth,
            (t) => w * 0.68 * t,
            (t) => top(t * 0.68) - 0.003,
            (t) => top(t * 0.68) - 0.003 - depth(t),
            0.011
        );
    };
}

/** A rounded-rectangle outline. */
function roundRect(w: number, h: number, r: number): THREE.Shape {
    const s = new THREE.Shape();
    s.moveTo(-w / 2 + r, -h / 2);
    s.lineTo(w / 2 - r, -h / 2);
    s.quadraticCurveTo(w / 2, -h / 2, w / 2, -h / 2 + r);
    s.lineTo(w / 2, h / 2 - r);
    s.quadraticCurveTo(w / 2, h / 2, w / 2 - r, h / 2);
    s.lineTo(-w / 2 + r, h / 2);
    s.quadraticCurveTo(-w / 2, h / 2, -w / 2, h / 2 - r);
    s.lineTo(-w / 2, -h / 2 + r);
    s.quadraticCurveTo(-w / 2, -h / 2, -w / 2 + r, -h / 2);
    return s;
}

function glasses(color: string): THREE.Group {
    const group = new THREE.Group();
    const frame = new THREE.MeshPhysicalMaterial({
        color,
        roughness: 0.3,
        transmission: 0.35,
        thickness: 0.02,
        clearcoat: 0.8,
        clearcoatRoughness: 0.2,
    });
    const lensMat = new THREE.MeshPhysicalMaterial({
        color: '#e6eef2',
        transparent: true,
        opacity: 0.12,
        roughness: 0.04,
        clearcoat: 1,
        depthWrite: false,
    });
    const LW = 0.52;
    const LH = 0.4;
    const rim = roundRect(LW, LH, 0.07);
    rim.holes.push(roundRect(LW - 0.05, LH - 0.05, 0.06));
    const rimGeo = new THREE.ExtrudeGeometry(rim, {
        depth: 0.03,
        bevelEnabled: true,
        bevelThickness: 0.008,
        bevelSize: 0.008,
        bevelSegments: 2,
        curveSegments: 8,
    });
    rimGeo.translate(0, 0, -0.015);
    const lensGeo = new THREE.ShapeGeometry(roundRect(LW - 0.05, LH - 0.05, 0.06), 8);
    for (const side of [-1, 1]) {
        const { pos } = face(side * EYE.x, EYE.y);
        const lens = new THREE.Group();
        lens.position.set(side * 0.285, EYE.y + 0.02, pos.z + 0.19);
        lens.rotation.y = side * 0.14;
        lens.add(mesh(rimGeo, frame), new THREE.Mesh(lensGeo, lensMat));
        group.add(lens);
        const hinge = new V(side * 0.54, EYE.y + 0.1, lens.position.z - 0.07);
        const turn = new V(side * 0.66, EYE.y + 0.08, 0.35);
        const ear = new V(side * 0.7, EYE.y + 0.05, -0.2);
        group.add(bar(hinge, turn, 0.03, 0.045, frame), bar(turn, ear, 0.025, 0.035, frame));
    }
    const bridge = face(0, 0.09).pos;
    group.add(bar(new V(-0.1, 0.11, bridge.z + 0.13), new V(0.1, 0.11, bridge.z + 0.13), 0.035, 0.04, frame));
    return group;
}

function headphones(color: string): THREE.Group {
    const group = new THREE.Group();
    const shellMat = plastic(color, { roughness: 0.35, clearcoat: 0.5 });
    const cushion = fabric(new THREE.Color(color).multiplyScalar(0.82).getStyle(), { roughness: 0.75 });
    const metal = new THREE.MeshPhysicalMaterial({ color: '#b9bdc4', metalness: 0.85, roughness: 0.3 });
    const cupProfile = [
        [0, 0],
        [0.3, 0],
        [0.355, 0.03],
        [0.37, 0.1],
        [0.35, 0.18],
        [0.28, 0.22],
        [0, 0.225],
    ].map(([x, y]) => new THREE.Vector2(x, y));
    for (const side of [-1, 1]) {
        const cup = mesh(new THREE.LatheGeometry(cupProfile, 48), shellMat);
        cup.rotation.z = -side * (Math.PI / 2);
        cup.position.set(side * 0.78, -0.06, -0.07);
        cup.scale.set(1, 1, 1.18);
        const pad = mesh(new THREE.TorusGeometry(0.27, 0.075, 16, 40), cushion, [side * 0.76, -0.06, -0.07]);
        pad.rotation.y = Math.PI / 2;
        pad.scale.set(1, 1.18, 1);
        group.add(cup, pad);
        // Yoke: from the band's end down to the top of the cup.
        group.add(bar(new V(side * 0.88, 0.48, -0.06), new V(side * 0.88, 0.28, -0.07), 0.04, 0.05, metal));
    }
    const arc = new THREE.CatmullRomCurve3([
        new V(-0.88, 0.48, -0.06),
        new V(-0.84, 0.86, -0.05),
        new V(-0.52, 1.2, -0.04),
        new V(0, 1.34, -0.03),
        new V(0.52, 1.2, -0.04),
        new V(0.84, 0.86, -0.05),
        new V(0.88, 0.48, -0.06),
    ]);
    const band = mesh(new THREE.TubeGeometry(arc, 64, 0.05, 12), shellMat);
    band.scale.z = 1.6;
    group.add(band);
    return group;
}

function buildHead(spec: FigureSpec): HeadRig {
    const group = new THREE.Group();
    const grid = headGrid();
    grid.geometry.setAttribute('color', skinColors(grid, spec));
    group.add(mesh(grid.geometry, skinMaterial(spec, true)));
    group.add(
        mesh(
            hairShell(grid, spec),
            new THREE.MeshPhysicalMaterial({
                vertexColors: true,
                roughness: 0.6,
                sheen: 0.25,
                sheenRoughness: 0.5,
                sheenColor: new THREE.Color('#3d3129'),
            })
        )
    );
    const browMat = new THREE.MeshStandardMaterial({
        color: spec.hair,
        roughness: 0.85,
        side: THREE.DoubleSide,
    });
    group.add(mesh(brow(-1), browMat), mesh(brow(1), browMat));

    const plainSkin = skinMaterial(spec);
    for (const side of [-1, 1]) {
        const ear = mesh(new THREE.SphereGeometry(1, 20, 14), plainSkin, [side * 0.66, -0.06, -0.06]);
        ear.scale.set(0.07, 0.2, 0.13);
        ear.rotation.y = side * 0.25;
        group.add(ear);
    }

    // Eyes: balls that turn to look, an upper lid that blinks, a lower lid, a lash line.
    const eyeMap = eyeTexture(spec.eyes);
    const ballMat = new THREE.MeshPhysicalMaterial({
        map: eyeMap,
        emissive: new THREE.Color('#ffffff'),
        emissiveMap: eyeMap,
        emissiveIntensity: 0.22,
        roughness: 0.1,
        clearcoat: 1,
        clearcoatRoughness: 0.03,
    });
    const ballGeo = new THREE.SphereGeometry(0.142, 48, 28).rotateX(Math.PI / 2);
    const upperGeo = new THREE.SphereGeometry(0.158, 32, 12, 0, Math.PI * 2, 0, Math.PI / 2);
    const lowerGeo = new THREE.SphereGeometry(
        0.156,
        32,
        10,
        0,
        Math.PI * 2,
        Math.PI / 2 + 0.25,
        Math.PI / 2 - 0.25
    );
    const lash = new THREE.MeshStandardMaterial({ color: '#120d0a', roughness: 0.9 });
    const lids: THREE.Mesh[] = [];
    const balls: THREE.Mesh[] = [];
    for (const side of [-1, 1]) {
        const { pos, normal } = face(side * EYE.x, EYE.y, -0.08);
        const socket = new THREE.Group();
        socket.position.copy(pos);
        socket.quaternion.setFromUnitVectors(new V(0, 0, 1), normal.lerp(new V(0, 0, 1), 0.5).normalize());
        socket.scale.set(1.12, 0.92, 0.9);
        const ball = mesh(ballGeo, ballMat);
        const lid = mesh(upperGeo, plainSkin);
        const rim = new THREE.Mesh(new THREE.TorusGeometry(0.158, 0.009, 6, 40, Math.PI), lash);
        rim.rotation.set(Math.PI / 2, 0, 0);
        lid.add(rim);
        const lower = mesh(lowerGeo, plainSkin);
        lower.rotation.x = 0.4;
        // The catchlight that makes animated eyes look alive; it does not turn with the eye.
        const glint = new THREE.Mesh(
            new THREE.SphereGeometry(0.022, 12, 8),
            new THREE.MeshBasicMaterial({ color: '#ffffff' })
        );
        glint.position.set(0.05, 0.05, 0.142);
        socket.add(ball, lid, lower, glint);
        group.add(socket);
        lids.push(lid);
        balls.push(ball);
    }

    if (spec.glasses) group.add(glasses(spec.glasses));
    if (spec.headphones) group.add(headphones(spec.headphones));
    const setMouth = mouthRig(
        group,
        new THREE.Color(spec.skin).lerp(new THREE.Color('#6e2a26'), 0.4).getStyle()
    );
    setMouth({ open: 0, wide: 0, round: 0 });
    group.scale.setScalar(HEAD);
    return { group, setMouth, lids, balls };
}

/* ================================================================== body */

type Pair = [THREE.Bone, THREE.Bone];
export type Rig = {
    /** Rest height of the hips bone; the gait bobs it from here. */
    pelvisY: number;
    /** Leg length relative to the hand-built figure (1); scales stride and joint swing. */
    legs: number;
    /** How far the upper arms may swing (1 free; less where a model's upper arms are fused to its torso). */
    shoulders: number;
    hips: THREE.Bone;
    spine: THREE.Bone;
    chest: THREE.Bone;
    neck: THREE.Bone;
    head: THREE.Bone;
    /** Index 0 is the right side (-x), 1 the left (+x). */
    arm: Pair;
    fore: Pair;
    hand: Pair;
    thigh: Pair;
    shin: Pair;
    foot: Pair;
};

/** Joint heights (metres) in the rest pose. */
const J = {
    pelvis: 0.96,
    hip: 0.93,
    knee: 0.5,
    ankle: 0.085,
    chest: 1.27,
    shoulder: 1.425,
    elbow: 1.135,
    wrist: 0.875,
};
const HIP_X = 0.095;
const SHOULDER_X = 0.205;

function bone(parent: THREE.Object3D, x: number, y: number, z: number): THREE.Bone {
    const b = new THREE.Bone();
    b.position.set(x, y, z);
    parent.add(b);
    return b;
}

function skeleton(root: THREE.Group): Rig {
    const hips = bone(root, 0, J.pelvis, 0);
    const spine = bone(hips, 0, 0.11, 0);
    const chest = bone(spine, 0, J.chest - J.pelvis - 0.11, 0);
    const neck = bone(chest, 0, 0.2, -0.008);
    const head = bone(neck, 0, 0.085, 0.004);
    const limbs = (s: number): THREE.Bone[] => {
        const arm = bone(chest, s * SHOULDER_X, J.shoulder - J.chest, -0.012);
        const fore = bone(arm, 0, J.elbow - J.shoulder, 0);
        const wrist = bone(fore, 0, J.wrist - J.elbow, 0);
        const thigh = bone(hips, s * HIP_X, J.hip - J.pelvis, 0);
        const shin = bone(thigh, 0, J.knee - J.hip, 0);
        const foot = bone(shin, 0, J.ankle - J.knee, 0);
        return [arm, fore, wrist, thigh, shin, foot];
    };
    const r = limbs(-1);
    const l = limbs(1);
    const pair = (i: number): Pair => [r[i], l[i]];
    return {
        pelvisY: J.pelvis,
        legs: 1,
        shoulders: 1,
        hips,
        spine,
        chest,
        neck,
        head,
        arm: pair(0),
        fore: pair(1),
        hand: pair(2),
        thigh: pair(3),
        shin: pair(4),
        foot: pair(5),
    };
}

function skinned(
    geometry: THREE.BufferGeometry,
    material: THREE.Material,
    root: THREE.Group,
    bones: THREE.Bone[]
): void {
    const m = new THREE.SkinnedMesh(geometry, material);
    m.castShadow = true;
    m.receiveShadow = true;
    root.add(m);
    m.bind(new THREE.Skeleton(bones));
}

/**
 * A hand with four jointed fingers and a thumb, relaxed or gripping. Palms face the thighs;
 * curling moves the fingertips toward the palm.
 */
function hand(s: number, skin: THREE.Material, grip: boolean): THREE.Group {
    const group = new THREE.Group();
    group.position.set(s * SHOULDER_X, J.wrist, -0.012);
    group.add(rbox(0.03, 0.09, 0.084, 0.014, skin, [0, -0.046, 0.003]));
    const curl = grip ? [0.75, 1.0] : [0.22, 0.42];
    const fingers: [number, number][] = [
        [0.03, 0.074],
        [0.0105, 0.082],
        [-0.0095, 0.078],
        [-0.029, 0.063],
    ];
    for (const [z, len] of fingers) {
        const knuckle = new THREE.Group();
        knuckle.position.set(-s * 0.002, -0.088, z);
        knuckle.rotation.z = -s * curl[0];
        const l1 = len * 0.55;
        const l2 = len * 0.45;
        knuckle.add(mesh(new THREE.CapsuleGeometry(0.0105, l1 - 0.012, 4, 10), skin, [0, -l1 / 2, 0]));
        const joint = new THREE.Group();
        joint.position.y = -l1;
        joint.rotation.z = -s * curl[1];
        joint.add(mesh(new THREE.CapsuleGeometry(0.0095, l2 - 0.01, 4, 10), skin, [0, -l2 / 2, 0]));
        knuckle.add(joint);
        group.add(knuckle);
    }
    const thumb = mesh(new THREE.CapsuleGeometry(0.0125, 0.04, 4, 10), skin, [-s * 0.014, -0.06, 0.043]);
    thumb.rotation.set(0.55, 0, -s * (grip ? 0.7 : 0.35));
    group.add(thumb);
    return group;
}

/** A chunky sneaker: a rounded upper lofted heel to toe on a thick sole, collar, heel tab, laces. */
function sneaker(s: number, shoe: THREE.Material, sole: THREE.Material, accent: THREE.Material): THREE.Group {
    const group = new THREE.Group();
    group.position.set(s * HIP_X, J.ankle, 0);
    // Rings run toe (-z after the turn) to heel: [along, half width, half height, height offset].
    const upper = loft(
        [
            [-0.205, 0.01, 0.008, -0.03],
            [-0.19, 0.032, 0.02, -0.03],
            [-0.15, 0.049, 0.031, -0.024],
            [-0.08, 0.055, 0.041, -0.014],
            [0.0, 0.053, 0.05, -0.004],
            [0.06, 0.05, 0.052, 0.0],
            [0.09, 0.042, 0.046, 0.0],
            [0.102, 0.012, 0.012, 0.0],
        ],
        { seg: 28, steps: 4 }
    );
    upper.rotateX(-Math.PI / 2);
    group.add(mesh(upper, shoe, [0, -0.012, 0.045]));
    group.add(rbox(0.118, 0.042, 0.315, 0.019, sole, [0, -0.064, 0.048]));
    const collar = mesh(new THREE.TorusGeometry(0.04, 0.012, 8, 24), shoe, [0, 0.036, -0.012]);
    collar.rotation.x = Math.PI / 2 + 0.25;
    group.add(collar);
    group.add(rbox(0.05, 0.05, 0.022, 0.01, accent, [0, 0.012, -0.058]));
    for (let k = 0; k < 4; k++)
        group.add(rbox(0.05, 0.006, 0.011, 0.003, accent, [0, 0.04 - k * 0.006, 0.04 + k * 0.024]));
    return group;
}

function buildBody(root: THREE.Group, rig: Rig, spec: FigureSpec): void {
    root.updateMatrixWorld(true);
    const skin = skinMaterial(spec);
    const shirt = fabric(spec.shirt);
    const denim = fabric(spec.pants, { roughness: 0.92, bumpMap: twill(), bumpScale: 0.6, sheen: 0.3 });
    const shoe = plastic(spec.shoes, { roughness: 0.55, clearcoat: 0.15 });
    const sole = plastic(new THREE.Color(spec.shoes).multiplyScalar(0.9).getStyle(), { roughness: 0.7 });
    const accent = plastic('#9c9a96', { roughness: 0.6 });
    /** Attach a mesh built in root space to a bone, keeping where it is. */
    const on = (b: THREE.Object3D, m: THREE.Object3D): void => {
        root.add(m);
        m.updateMatrixWorld(true);
        b.attach(m);
    };

    // T-shirt: a V-shaped torso, a little boxy, hem over the jeans.
    const torso = loft(
        [
            [0.835, 0.15, 0.104, 0],
            [0.86, 0.168, 0.12, 0],
            [0.95, 0.163, 0.115, 0],
            [1.04, 0.152, 0.106, 0],
            [1.13, 0.16, 0.11, 0.004],
            [1.22, 0.174, 0.116, 0.01],
            [1.3, 0.186, 0.121, 0.013],
            [1.37, 0.19, 0.117, 0.008],
            [1.42, 0.188, 0.104, 0],
            [1.46, 0.165, 0.085, -0.006],
            [1.49, 0.12, 0.07, -0.006],
            [1.505, 0.068, 0.058, -0.004],
        ],
        { seg: 48, p: 2.15 }
    );
    on(rig.chest, mesh(torso, shirt));
    const collar = mesh(new THREE.TorusGeometry(0.058, 0.009, 8, 32), shirt, [0, 1.5, -0.004]);
    collar.rotation.x = Math.PI / 2 - 0.25;
    collar.scale.set(1.08, 0.95, 1);
    on(rig.chest, collar);
    on(rig.neck, mesh(new THREE.CylinderGeometry(0.06, 0.066, 0.17, 24), skin, [0, 1.535, 0]));

    // Jeans: a relaxed waist under the hem, then straight, slightly baggy legs skinned at the knee.
    const waist = loft(
        [
            [0.8, 0.165, 0.118, 0],
            [0.88, 0.167, 0.12, 0],
            [0.97, 0.158, 0.112, 0],
            [1.0, 0.152, 0.108, 0],
        ],
        { seg: 40, p: 2.3 }
    );
    on(rig.hips, mesh(waist, denim));

    for (const i of [0, 1] as const) {
        const s = i === 0 ? -1 : 1;
        const leg = loft(
            [
                [J.hip - 0.02, 0.068, 0.08, 0],
                [J.hip - 0.12, 0.084, 0.09, 0.006],
                [J.knee + 0.06, 0.07, 0.074, 0.01],
                [J.knee - 0.12, 0.064, 0.068, 0.006],
                [J.ankle + 0.07, 0.062, 0.066, 0.004],
                [J.ankle + 0.02, 0.066, 0.07, 0.002],
            ],
            { seg: 32, steps: 6 }
        );
        leg.translate(s * HIP_X, 0, 0);
        skinLimb(leg, J.knee, 0.07);
        skinned(leg, denim, root, [rig.thigh[i], rig.shin[i]]);

        // Arm: skin from inside the sleeve to the wrist, bending at the elbow.
        const arm = loft(
            [
                [J.shoulder - 0.02, 0.052, 0.052, 0],
                [J.shoulder - 0.13, 0.051, 0.049, 0.004],
                [J.elbow + 0.03, 0.042, 0.041, 0],
                [J.elbow - 0.06, 0.046, 0.042, 0.004],
                [J.wrist + 0.05, 0.034, 0.029, 0.002],
                [J.wrist, 0.03, 0.025, 0],
            ],
            { seg: 24, steps: 5 }
        );
        arm.translate(s * SHOULDER_X, 0, -0.012);
        skinLimb(arm, J.elbow, 0.05);
        skinned(arm, skin, root, [rig.arm[i], rig.fore[i]]);

        // Sleeve: short, over the deltoid.
        const sleeve = loft(
            [
                [J.shoulder + 0.045, 0.045, 0.05, 0],
                [J.shoulder + 0.01, 0.062, 0.058, 0],
                [J.shoulder - 0.08, 0.058, 0.055, 0.003],
                [J.shoulder - 0.16, 0.057, 0.054, 0.004],
            ],
            { seg: 32 }
        );
        on(rig.arm[i], mesh(sleeve, shirt, [s * SHOULDER_X, 0, -0.012]));

        on(rig.hand[i], hand(s, skin, i === 1 && Boolean(spec.laptop)));
        on(rig.foot[i], sneaker(s, shoe, sole, accent));
    }
}

export function laptop(color: string): THREE.Group {
    const group = new THREE.Group();
    const metal = new THREE.MeshPhysicalMaterial({ color, metalness: 0.85, roughness: 0.32 });
    const dark = new THREE.MeshStandardMaterial({ color: '#2b2c2f', roughness: 0.6 });
    // Closed, carried by its edge: lid and base as two slabs with a dark hinge between.
    group.add(rbox(0.008, 0.215, 0.305, 0.004, metal, [-0.0045, 0, 0]));
    group.add(rbox(0.008, 0.215, 0.305, 0.004, metal, [0.0045, 0, 0]));
    group.add(rbox(0.012, 0.012, 0.27, 0.005, dark, [0, -0.104, 0]));
    return group;
}

/* ================================================================== poses */

/** Everything a pose needs this frame: time, step phase and the blend weights. */
type Blend = {
    t: number;
    phase: number;
    moving: number;
    /** Walking and running weights (they sum to `moving`). */
    mw: number;
    mr: number;
    climb: number;
    talk: number;
    wave: number;
    carry: number;
    /** Gait swing scale: shorter legs swing less and step faster. */
    swing: number;
    idle: number;
};
type ArmPose = { ax: number; az: number; fx: number; fz: number };

/** Pelvis bob, sway and twist with the step; a slow weight shift when standing. */
function poseTorso(rig: Rig, b: Blend): void {
    const s = Math.sin(b.phase);
    const c = Math.cos(b.phase);
    const still = 1 - b.moving;
    rig.hips.position.y =
        rig.pelvisY - (0.022 * b.mw + 0.045 * b.mr) * s * s - 0.03 * Math.abs(b.climb) - 0.012 * b.mr;
    rig.hips.position.x = 0.012 * Math.sin(b.t * 0.45) * still + 0.02 * b.mw * c;
    rig.hips.rotation.set(
        0,
        (0.08 * b.mw + 0.12 * b.mr) * s,
        0.03 * Math.sin(b.t * 0.45) * still - 0.03 * b.mw * c
    );
    rig.spine.rotation.set(0.012 * Math.sin(b.t * 1.4) + 0.14 * b.mr, -0.06 * b.mw * s, 0);
    rig.chest.rotation.set(0.01 * Math.sin(b.t * 1.4 + 0.6), -(0.07 * b.mw + 0.1 * b.mr) * s, 0);
}

/** Legs: forward is a negative x rotation; knees fold most mid-swing; toes push off behind. */
function poseLegs(rig: Rig, b: Blend): void {
    for (const i of [0, 1]) {
        const ph = i === 1 ? b.phase : b.phase + Math.PI;
        const ls = Math.sin(ph);
        const swing = Math.max(0, Math.cos(ph));
        const thigh = -(0.42 * b.mw + 0.8 * b.mr) * b.swing * ls - 0.35 * Math.max(0, b.climb) - 0.05 * b.mr;
        const knee =
            (0.08 + 0.7 * swing ** 1.4) * b.mw * b.swing +
            (0.25 + 1.5 * swing ** 1.2) * b.mr * b.swing +
            0.55 * Math.abs(b.climb) +
            0.03 * b.idle;
        rig.thigh[i].rotation.set(thigh, 0, i === 0 ? 0.03 : -0.03);
        rig.shin[i].rotation.set(knee, 0, 0);
        const toeOff = Math.max(0, -ls - 0.4) * 0.6 * b.moving;
        rig.foot[i].rotation.set(-(thigh + knee) * 0.9 + toeOff, 0, 0);
    }
}

/** The right hand talks with small gestures, and waves. */
function speakingHand(a: ArmPose, b: Blend, k: number): ArmPose {
    const gesture = b.talk * (1 - b.wave) * (1 - b.moving);
    const ax = lerp(a.ax, (-0.22 - 0.1 * Math.sin(b.t * 2.6)) * k, gesture);
    const az = lerp(a.az, -0.12 * k, gesture);
    const fx = lerp(a.fx, -0.85 - 0.2 * Math.sin(b.t * 3.1 + 1), gesture);
    const flap = Math.sin(b.t * 9);
    return {
        // An elbow-up wave: upper arm out to the side, forearm up, hand swinging. With fused upper
        // arms (k < 1) the forearm rises in front and waves from the elbow instead.
        ax: lerp(ax, lerp(-0.2, -0.35, k), b.wave),
        az: lerp(az, -1.25 * k, b.wave),
        fx: lerp(fx, lerp(-2.1, -0.15, k), b.wave),
        fz: lerp(a.fz, lerp(0.35 * flap, -1.55 + 0.4 * flap, k), b.wave),
    };
}

/** Arms counter-swing the legs; the left hand carries the laptop and swings less. */
function poseArms(rig: Rig, b: Blend): void {
    for (const i of [0, 1]) {
        const holding = i === 1 ? b.carry : 0;
        const ph = i === 0 ? b.phase : b.phase + Math.PI;
        const out = i === 0 ? -1 : 1;
        const k = rig.shoulders;
        const rest: ArmPose = {
            ax: -(0.38 * b.mw + 0.9 * b.mr) * b.swing * Math.sin(ph) * (1 - 0.8 * holding) * k,
            az: out * (0.1 + 0.04 * Math.sin(b.t * 1.4) * b.idle + 0.1 * holding) * k,
            fx: -(0.14 + 0.15 * b.mw + 1.25 * b.mr * (1 - 0.7 * holding)) - 0.05 * holding,
            fz: 0,
        };
        const a = i === 0 ? speakingHand(rest, b, k) : rest;
        rig.arm[i].rotation.set(a.ax, 0, a.az);
        rig.fore[i].rotation.set(a.fx, 0, a.fz);
    }
}

/* ================================================================== the rig */

/** What a face does each frame: gaze (radians), blink (0..1) and the mouth shape. */
export type FaceDriver = (gazeX: number, gazeY: number, blink: number, mouth: Mouth | null) => void;

/**
 * The motion system shared by the hand-built figure and a generated model: gait blends, walk/run
 * cycles, climbing, idle, talking gestures, waving, look-at and blinking, all on one Rig.
 */
export function animate(
    root: THREE.Group,
    rig: Rig,
    opts: { carry: boolean; music: boolean; face: FaceDriver }
): Figure {
    const hit = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.28, 1.2, 4, 12),
        new THREE.MeshBasicMaterial({ visible: false })
    );
    hit.position.y = 0.9;
    root.add(hit);

    let t = 0;
    let phase = 0;
    let moving = 0;
    let run = 0;
    let talk = 0;
    let climb = 0;
    let wave = 0;
    let react = 0;
    let blinkAt = 1.4;
    let lastFoot = 0;
    const gaze = new THREE.Vector2();
    const look = new THREE.Vector2();
    const carry = opts.carry ? 1 : 0;
    const music = opts.music ? 1 : 0;

    const figure: Figure = {
        root,
        hit,
        onStep: () => undefined,
        react() {
            react = 1.8;
        },
        update(dt, input) {
            const step = Math.min(dt, 1 / 30);
            t += step;
            react = Math.max(0, react - step);

            // Gait blends: standing → walking → running, with a stride that lengthens with speed.
            moving = damp(moving, smooth(0.05, 0.45, input.speed), 8, step);
            run = damp(run, smooth(2.0, 3.4, input.speed), 5, step);
            climb = damp(climb, input.climb, 12, step);
            const stride = lerp(1.35, 2.5, run) * rig.legs * Math.max(1, input.speed / 3.6) ** 0.6;
            phase += (2 * Math.PI * input.speed * step) / stride;
            const foot = Math.floor(phase / Math.PI);
            if (foot !== lastFoot && moving > 0.4) figure.onStep(lerp(0.5, 1, run));
            lastFoot = foot;

            talk = damp(talk, input.mouth ? 1 : 0, 3, step);
            wave = damp(wave, Math.max(input.wave, react > 0 ? 1 : 0), 6, step);
            const b: Blend = {
                t,
                phase,
                moving,
                mw: moving * (1 - run),
                mr: moving * run,
                climb,
                talk,
                wave,
                carry,
                swing: Math.min(1, 0.45 + 0.55 * rig.legs),
                idle: (1 - moving) * (1 - talk) * (1 - wave),
            };
            poseTorso(rig, b);
            poseLegs(rig, b);
            poseArms(rig, b);

            // Head: look at the pointer (shared with the neck), nod when talking, nod to the music when idle.
            look.x = damp(look.x, react > 0 ? 0 : input.look.x, 6, step);
            look.y = damp(look.y, react > 0 ? 0.1 : input.look.y, 6, step);
            const beat = Math.max(0, Math.sin(t * Math.PI * 2 * 1.6)) ** 2;
            const nod = 0.05 * (input.mouth?.open ?? 0) + 0.035 * beat * b.idle * music;
            rig.neck.rotation.set(-look.y * 0.12 - 0.02 * b.mr, look.x * 0.25, 0);
            rig.head.rotation.set(
                -look.y * 0.18 + nod + 0.08 * b.mr,
                look.x * 0.35,
                0.02 * Math.sin(t * 0.7) * b.idle
            );

            gaze.x = damp(gaze.x, look.x * 0.4, 14, step);
            gaze.y = damp(gaze.y, look.y * 0.25, 14, step);
            if (t > blinkAt + 0.15) blinkAt = t + 2.2 + Math.random() * 3.4;
            const blink = t > blinkAt ? Math.sin(((t - blinkAt) / 0.15) * Math.PI) : 0;
            opts.face(gaze.x, gaze.y, blink, input.mouth);
        },
    };
    return figure;
}

export function buildFigure(spec: FigureSpec): Figure {
    const root = new THREE.Group();
    const rig = skeleton(root);
    buildBody(root, rig, spec);

    const head = buildHead(spec);
    head.group.position.set(0, 0.118, 0.016);
    rig.head.add(head.group);

    if (spec.laptop) {
        const lap = laptop(spec.laptop);
        lap.position.set(-0.03, -0.2, 0.02);
        rig.hand[1].add(lap);
    }

    return animate(root, rig, {
        carry: Boolean(spec.laptop),
        music: Boolean(spec.headphones),
        face(gx, gy, blink, mouth) {
            for (const ball of head.balls) ball.rotation.set(-gy, gx, 0);
            for (const lid of head.lids) lid.rotation.x = -0.5 + blink * 1.75;
            head.setMouth(mouth ?? { open: 0, wide: 0, round: 0 });
        },
    });
}
