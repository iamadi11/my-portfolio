/**
 * The 3D world behind /v2: one renderer, one scene, a camera that follows the page scroll, and the
 * figure walking between stations. Plain three.js; React only mounts it (Stage.tsx).
 */
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

import { CARD_FOV, COVER, drawCover, FIGURE_SCALE } from '@/components/v2/art';
import { createBook, PAGE, type SpreadArt } from '@/components/v2/book';
import { createDesk, WALL } from '@/components/v2/desk';
import { type Figure, type FigureSpec, type Mouth, smooth } from '@/components/v2/figure';
import { createLook } from '@/components/v2/look';
import type { Model, Stop } from '@/components/v2/model';
import { FONT } from '@/components/v2/print';
import { confetti, type Frame, type Hit, HUES, toyBox } from '@/components/v2/stations';

export type Sound = 'pop' | 'click' | 'tick' | 'step';

export type WorldOptions = {
    canvas: HTMLCanvasElement;
    figure: FigureSpec;
    /** The guide, already built: the hand-made figure or a rigged generated model. */
    character: Figure;
    /** The character as a flat print for the box, or null to draw it. */
    cutout: HTMLImageElement | null;
    model: Model;
    /** Portrait phones: text sits under the 3D instead of beside it. */
    narrow: boolean;
    reduce: boolean;
    /** Scroll position in stops (0 = top, 1 = next stop…). Read every frame. */
    input: { t: number };
    mouth: () => Mouth | null;
    sfx: (name: Sound, amount?: number) => void;
    onHello: () => void;
    /** Called once the first frame has been drawn. */
    onReady: () => void;
};

export type World = {
    resize(): void;
    /** Put the camera where the box front exactly covers this on-screen rect (the 2D poster). */
    matchPoster(rect: DOMRect): void;
    /** 2D → 3D: the camera dolly-zooms out of the poster, the cut-out inflates and walks out. */
    open(): void;
    dispose(): void;
};

type Shot = { focus: THREE.Vector3; w: number; h: number; yaw: number; pitch: number };
type Pose = { pos: THREE.Vector3; target: THREE.Vector3; fov: number };

const V = THREE.Vector3;
const FOV = 30;
const S = FIGURE_SCALE;
const clamp = THREE.MathUtils.clamp;
const damp = THREE.MathUtils.damp;
const easeInOut = (x: number): number => (x < 0.5 ? 4 * x * x * x : 1 - (-2 * x + 2) ** 3 / 2);
const tanHalf = (fov: number): number => Math.tan((fov * Math.PI) / 360);
/** Damp an angle toward a target the short way round. */
const dampAngle = (from: number, to: number, k: number, dt: number): number => {
    const d = Math.atan2(Math.sin(to - from), Math.cos(to - from));
    return from + d * (1 - Math.exp(-k * dt));
};

export function createWorld(o: WorldOptions): World {
    const { canvas, model, narrow, reduce, sfx } = o;
    const renderer = new THREE.WebGLRenderer({
        canvas,
        antialias: true,
        powerPreference: 'high-performance',
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, narrow ? 1.75 : 2));
    renderer.toneMapping = THREE.NeutralToneMapping;
    renderer.toneMappingExposure = 0.92;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.VSMShadowMap;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(WALL);
    const fog = new THREE.Fog(WALL, 20, 60);
    scene.fog = fog;
    const pmrem = new THREE.PMREMGenerator(renderer);
    const room = new RoomEnvironment();
    scene.environment = pmrem.fromScene(room, 0.04).texture;
    scene.environmentIntensity = 0.35;
    room.dispose();

    /* ---------------- light: a soft key that travels with the camera, a warm rim, sky fill */
    // Animated-film lighting: a warm sun, a cool sky fill, and a cool rim to cut silhouettes out.
    const key = new THREE.DirectionalLight('#ffe2c4', 2.3);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    Object.assign(key.shadow.camera, { left: -7, right: 7, top: 7, bottom: -7, near: 0.5, far: 40 });
    key.shadow.bias = -0.0006;
    key.shadow.normalBias = 0.03;
    key.shadow.radius = 9;
    key.shadow.blurSamples = 16;
    const rim = new THREE.DirectionalLight('#dfe9ff', 1.5);
    const fill = new THREE.HemisphereLight('#d6e4ff', '#c9a98a', 0.55);
    scene.add(key, key.target, rim, rim.target, fill);

    /* ---------------- the book: one spread per section, every career stop on one spread */
    const stops = model.stops;
    const pale = (hex: string, k: number): string =>
        new THREE.Color(hex).lerp(new THREE.Color('#ece2d0'), k * 0.8).getStyle();
    const arts: SpreadArt[] = [];
    const spreadOfStop: number[] = [];
    function spreadArt(stop: Stop): SpreadArt {
        const P = model.projects.length;
        if (stop.kind === 'top') return { mark: '', title: '', tint: pale('#ff5a1f', 0.7) };
        if (stop.kind === 'work')
            return { mark: String(P), title: `${P} things I built`, tint: pale('#c9a227', 0.75) };
        if (stop.kind === 'project') {
            const p = model.projects[stop.index];
            return {
                mark: String(stop.index + 1).padStart(2, '0'),
                title: p.title,
                tint: pale(HUES[p.hue], 0.7),
            };
        }
        if (stop.kind === 'step') return { mark: '', title: 'Experience', tint: pale('#c9a227', 0.7) };
        if (stop.kind === 'skills')
            return { mark: '', title: 'Tools I use daily', tint: pale('#2f9a6f', 0.72) };
        return { mark: '', title: 'Say hello', tint: pale('#ff5a1f', 0.72) };
    }
    for (const stop of stops) {
        const section = stop.kind === 'step' ? 'step' : stop.id;
        const last = spreadOfStop.length ? stops[spreadOfStop.length - 1] : null;
        const lastKey = last ? (last.kind === 'step' ? 'step' : last.id) : '';
        if (section !== lastKey) arts.push(spreadArt(stop));
        spreadOfStop.push(arts.length - 1);
    }
    const book = createBook(arts, (g, u) => drawCover(g, u, model.box, FONT, o.figure, o.cutout));
    scene.add(book.group);
    /** The open spread for a scroll position: pages turn in the middle of the scroll between stops. */
    const spreadAt = (t: number): number => {
        const i = clamp(Math.floor(t), 0, stops.length - 1);
        const j = Math.min(i + 1, stops.length - 1);
        return THREE.MathUtils.lerp(spreadOfStop[i], spreadOfStop[j], smooth(0.2, 0.8, t - i));
    };
    // Page one: the toy box stands on it (built at the open page's height, then carried by the board).
    const pageTop = PAGE.cover + book.count * PAGE.t;
    const hero = toyBox(model.box, o.figure, new V(2.1, pageTop, 0.15), o.cutout);
    book.page(0).add(hero.group);
    hero.group.position.y = 0;
    const bits = confetti();
    /** The figure presents from the desk beside the book's fore-edge, level with the mechanisms. */
    const SIDE = PAGE.w + PAGE.over + 0.85;
    createDesk(scene, { hero: new V(SIDE, 0, 1.0), book: PAGE });

    const figure = o.character;
    figure.root.scale.setScalar(S);
    figure.root.visible = false;
    scene.add(figure.root);

    /* ---------------- where the camera and the figure go for each stop */
    const index = (id: string): number => stops.findIndex((st) => st.id === id);
    type Place = { shot: Shot; spot: THREE.Vector3 };
    /** Wide value or phone value. */
    const by = (wide: number, phone: number): number => (narrow ? phone : wide);
    const shot = (focus: THREE.Vector3, w: number, h: number, yaw: number, pitch: number): Shot => ({
        focus,
        w,
        h,
        yaw,
        pitch,
    });
    const desk = (z: number): THREE.Vector3 => new V(SIDE, 0, z);
    const onPage = (): Shot => shot(new V(3.0, 1.0, 0.5), by(7.2, 5.4), by(4.8, 5.6), 0.32, 0.4);
    const PLACES: { [K in Stop['kind']]: (stop: Extract<Stop, { kind: K }>) => Place } = {
        // The box on page one, the figure stepping down beside the book.
        top: () => ({
            shot: shot(
                new V(by(1.7, 2.1), by(1.9, 2.0), by(0.7, 1.0)),
                by(5.6, 3.4),
                by(4.6, 5.3),
                by(0.3, 0.18),
                0.16
            ),
            spot: desk(1.2),
        }),
        // From above: the whole spread.
        work: () => ({
            shot: shot(new V(0, 0.4, 0.4), by(9.8, 6.4), by(6.6, 7.6), 0, by(0.8, 0.95)),
            spot: desk(2.0),
        }),
        project: () => ({ shot: onPage(), spot: desk(0.9) }),
        step: (stop) => ({ shot: onPage(), spot: desk(-1.6 + stop.index * 0.7) }),
        skills: () => ({
            shot: shot(new V(0, 0.4, 0.3), by(9.6, 6.2), by(6.4, 7.6), 0, by(0.85, 0.95)),
            spot: desk(2.0),
        }),
        contact: () => ({ shot: onPage(), spot: desk(0.9) }),
    };
    const place = (stop: Stop): Place => (PLACES[stop.kind] as (s: Stop) => Place)(stop);
    const places = stops.map(place);

    /* ---------------- camera */
    const camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 400);
    const film = createLook(renderer, scene, camera, narrow);
    const UP = new V(0, 1, 0);
    const pose = (): Pose => ({ pos: new V(), target: new V(), fov: FOV });
    const solve = (s: Shot, out: Pose): Pose => {
        const aspect = camera.aspect;
        const wide = aspect >= 1.05;
        const size = wide ? Math.max(s.h, s.w / (0.6 * aspect)) : Math.max(s.h / 0.56, s.w / aspect);
        const dir = new V(
            Math.sin(s.yaw) * Math.cos(s.pitch),
            Math.sin(s.pitch),
            Math.cos(s.yaw) * Math.cos(s.pitch)
        );
        const forward = dir.clone().negate();
        const right = forward.clone().cross(UP).normalize();
        const camUp = right.clone().cross(forward).normalize();
        // Leave room for the text: subject to the right on wide screens, above it on phones.
        const shift = wide ? right.multiplyScalar(-0.2 * size * aspect) : camUp.multiplyScalar(-0.21 * size);
        out.target.copy(s.focus).add(shift);
        out.pos.copy(out.target).addScaledVector(dir, size / 2 / tanHalf(FOV));
        out.fov = FOV;
        return out;
    };
    let poses: Pose[] = [];
    const want = pose();
    const scrolled = (t: number): Pose => {
        const i = clamp(Math.floor(t), 0, poses.length - 1);
        const j = Math.min(i + 1, poses.length - 1);
        const e = smooth(0.15, 0.85, t - i);
        want.pos.lerpVectors(poses[i].pos, poses[j].pos, e);
        want.target.lerpVectors(poses[i].target, poses[j].target, e);
        // Long moves lift off a little, like a crane.
        const travel = poses[i].target.distanceTo(poses[j].target);
        want.pos.y += Math.sin(Math.PI * e) * Math.min(2.5, travel * 0.12);
        return want;
    };
    const cam = pose();
    let card: Pose | null = null;
    /** 0: looking straight down at the cover (screen-up = the book's head); 1: upright. */
    let upright = 1;
    /** -1: not opened; 0..1: the opening move; 1: following the scroll. */
    let intro = -1;

    /* ---------------- figure travel: walk (or run) to each stop over whatever is underfoot */
    const WALK = 1.45 * S;
    const RUN = 3.6 * S;
    let route: THREE.Vector3[] = [];
    let dest: THREE.Vector3 | null = null;
    let speed = 0;
    let climb = 0;
    let inflate = -1;
    let facing = 0;
    let wave = 0;
    figure.onStep = (k) => sfx('step', 0.35 + 0.4 * k);

    scene.add(bits.mesh);

    /** Top of whatever is underfoot: the tray in the box, the book, or the desk. */
    const ground = (x: number, z: number): number =>
        Math.max(0, book.top(x, z) ?? 0, hero.ground?.(x, z) ?? 0);
    const inBox = (p: THREE.Vector3): boolean => hero.ground?.(p.x, p.z) != null;

    // Everything is on the desk in front of the book, so routes are straight; out of the box, first
    // step through its window.
    const plan = (to: THREE.Vector3): void => {
        dest = to.clone();
        const from = figure.root.position;
        route = inBox(from) && !inBox(to) ? [new V(hero.front.x, 0, hero.front.z + 0.45), dest] : [dest];
    };
    const teleport = (to: THREE.Vector3): void => {
        figure.root.position.set(to.x, ground(to.x, to.z), to.z);
        dest = to.clone();
        route = [];
        speed = 0;
    };

    /* ---------------- pointer: wave at the figure, press things */
    const pointer = new THREE.Vector2(0, 0);
    let hasPointer = false;
    const ray = new THREE.Raycaster();
    const hits: Hit[] = hero.hits;
    const targets = hits.map((h) => h.object);
    const hitAt = (): { hit?: Hit; figure?: boolean } => {
        ray.setFromCamera(pointer, camera);
        if (figure.root.visible && ray.intersectObject(figure.hit, false).length) return { figure: true };
        const nearest = ray.intersectObjects(targets, true)[0];
        let obj: THREE.Object3D | null = nearest?.object ?? null;
        while (obj && !targets.includes(obj)) obj = obj.parent;
        return { hit: hits.find((h) => h.object === obj) };
    };
    const toNdc = (e: PointerEvent): void => {
        pointer.set((e.clientX / window.innerWidth) * 2 - 1, -(e.clientY / window.innerHeight) * 2 + 1);
    };
    const onMove = (e: PointerEvent): void => {
        toNdc(e);
        hasPointer = e.pointerType === 'mouse' || e.buttons > 0;
        if (e.target === canvas && e.pointerType === 'mouse') {
            const at = hitAt();
            canvas.style.cursor = at.hit || at.figure ? 'pointer' : '';
        }
    };
    const onDown = (e: PointerEvent): void => {
        if (e.target !== canvas) return;
        toNdc(e);
        const at = hitAt();
        if (at.figure) {
            figure.react();
            sfx('pop', 0.4);
        } else at.hit?.press();
    };
    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('pointerdown', onDown);

    /* ---------------- frame loop */
    const timer = new THREE.Timer();
    timer.connect(document);
    let time = 0;
    let ready = false;
    let slow = 0;
    let frames = 0;
    const headPos = new V();
    const look = { x: 0, y: 0 };
    const frame: Frame = { dt: 0, time: 0, near: 0, ray: null, reduce };
    const near = (id: string): number => {
        const i = index(id);
        return i < 0 ? 0 : clamp(1 - Math.abs(o.input.t - i), 0, 1);
    };

    const params = new URLSearchParams(window.location.search);
    const inspect = process.env.NODE_ENV === 'production' ? null : params.get('inspect');
    /** Where the camera wants to be: on the poster, in the opening move, or following the scroll. */
    const steerCamera = (dt: number, goal: Pose): void => {
        if (card && intro < 0) {
            cam.pos.copy(card.pos);
            cam.target.copy(card.target);
            cam.fov = card.fov;
            upright = 0;
            return;
        }
        if (card && intro < 1) {
            intro = Math.min(1, intro + dt / 3);
            const a = easeInOut(smooth(0, 0.34, intro));
            const b = easeInOut(smooth(0.1, 0.8, intro));
            // Dolly zoom: widen the lens while closing in, so the cover keeps its size and gains depth.
            const fov = THREE.MathUtils.lerp(CARD_FOV, FOV, a);
            const keep = (card.pos.distanceTo(card.target) * tanHalf(CARD_FOV)) / tanHalf(fov);
            const zoomPos = card.target
                .clone()
                .addScaledVector(card.pos.clone().sub(card.target).normalize(), keep);
            cam.pos.lerpVectors(zoomPos, goal.pos, b);
            cam.target.lerpVectors(card.target, goal.target, b);
            cam.pos.y += Math.sin(Math.PI * b) * 0.6;
            cam.fov = fov;
            upright = b;
            return;
        }
        upright = 1;
        const k = reduce ? 30 : 3.4;
        for (const axis of ['x', 'y', 'z'] as const) {
            cam.pos[axis] = damp(cam.pos[axis], goal.pos[axis], k, dt);
            cam.target[axis] = damp(cam.target[axis], goal.target[axis], k, dt);
        }
        cam.fov = FOV;
    };

    /** Dev only: ?inspect=face|body&yaw=0.4 locks the camera on the figure for tuning its look. */
    const inspectCamera = (): void => {
        if (!inspect || !figure.root.visible) return;
        const f = figure.root.position;
        const close = inspect === 'face';
        const yaw = Number(params.get('yaw') ?? 0.25);
        const h = (close ? 1.62 : 0.95) * S;
        const d = close ? 1.1 : 5.6;
        cam.target.set(f.x, f.y + h, f.z);
        cam.pos.set(f.x + Math.sin(yaw) * d, f.y + h + (close ? 0.02 : 0.4), f.z + Math.cos(yaw) * d);
    };

    /** Apply the camera, a breath of pointer parallax, and keep fog and lights with it. */
    const placeCamera = (): void => {
        const sway = reduce || !hasPointer || intro < 1 ? 0 : 0.12;
        camera.position.copy(cam.pos).add(new V(pointer.x * sway, pointer.y * sway * 0.6, 0));
        // Straight down over the cover, screen-up is the book's head (-z); it rights itself as we pull back.
        camera.up.set(0, upright, upright - 1).normalize();
        camera.lookAt(cam.target);
        if (camera.fov !== cam.fov) {
            camera.fov = cam.fov;
            camera.updateProjectionMatrix();
        }
        const dist = camera.position.distanceTo(cam.target);
        fog.near = dist + 6;
        fog.far = dist + 42;
        key.target.position.copy(cam.target);
        key.position.copy(cam.target).add(new V(-5.5, 8, 4.5));
        rim.target.position.copy(cam.target);
        rim.position.copy(cam.target).add(new V(5, 4, -5));
    };

    /** Flat print → figure: spin once while the depth puffs up past full, then settle and set off. */
    const puffUp = (dt: number, stopNow: number): void => {
        inflate = Math.min(1, inflate + dt / 1.15);
        const e = inflate;
        const puff = e < 0.75 ? smooth(0, 0.75, e) * 1.12 : 1.12 - 0.12 * smooth(0.75, 1, e);
        figure.root.scale.set(S, S, S * Math.max(0.03, puff));
        figure.root.rotation.y = easeInOut(smooth(0.05, 0.85, e)) * Math.PI * 2;
        if (inflate < 1) return;
        facing = 0;
        figure.react();
        plan(places[stopNow].spot);
    };

    /** Along the route: turn first, then go; sprint when far, slow down to arrive. */
    const walk = (dt: number): void => {
        const pos = figure.root.position;
        const next = route[0];
        const dx = next.x - pos.x;
        const dz = next.z - pos.z;
        const dist = Math.hypot(dx, dz);
        if (dist < 0.05) {
            route.shift();
            return;
        }
        let left = dist;
        for (let i = 1; i < route.length; i++) left += route[i - 1].distanceTo(route[i]);
        const heading = Math.atan2(dx, dz);
        facing = dampAngle(facing, heading, 9, dt);
        const aligned = smooth(0.3, 0.9, Math.cos(heading - facing));
        // Long trips become a sprint, so the guide is never far behind the camera.
        const pace = left > 3.2 ? clamp(left * 0.55, RUN, 8.5) : WALK;
        speed = damp(speed, pace * clamp(left / 0.6, 0.3, 1) * aligned, 5, dt);
        const stride = Math.min(dist, speed * dt);
        pos.x += (dx / dist) * stride;
        pos.z += (dz / dist) * stride;
    };

    /** Small changes (the ramp) directly; a step as a quick step up or down. */
    const followGround = (dt: number): void => {
        const pos = figure.root.position;
        const dy = ground(pos.x, pos.z) - pos.y;
        const big = Math.abs(dy) > 0.06;
        climb = big ? Math.sign(dy) : 0;
        pos.y += big ? Math.sign(dy) * Math.min(Math.abs(dy), (dy > 0 ? 2.8 : 3.4) * dt) : dy;
    };

    const moveFigure = (dt: number, stopNow: number): void => {
        if (inflate < 0) return;
        if (inflate < 1) {
            puffUp(dt, stopNow);
            return;
        }
        const spot = places[stopNow].spot;
        if (!dest || spot.distanceToSquared(dest) > 0.01) {
            if (reduce) teleport(spot);
            else plan(spot);
        }
        if (route.length) walk(dt);
        else {
            const pos = figure.root.position;
            speed = damp(speed, 0, 10, dt);
            facing = dampAngle(
                facing,
                Math.atan2(camera.position.x - pos.x, camera.position.z - pos.z) * 0.8,
                4,
                dt
            );
        }
        followGround(dt);
        figure.root.rotation.y = facing;
    };

    /** The figure's eyes and head follow the pointer, relative to where the head is on screen. */
    const animateFigure = (dt: number, stopNow: number): void => {
        headPos.set(0, 1.65, 0);
        figure.root.localToWorld(headPos).project(camera);
        look.x = hasPointer ? clamp((pointer.x - headPos.x) * 1.3, -1, 1) : Math.sin(time * 0.4) * 0.3;
        look.y = hasPointer ? clamp((pointer.y - headPos.y) * 1.3, -1, 1) : 0;
        wave = damp(wave, stops[stopNow]?.kind === 'contact' && !route.length ? 1 : 0, 4, dt);
        const forced = inspect ? Number(params.get('mouth') ?? NaN) : NaN;
        const mouth = Number.isNaN(forced) ? o.mouth() : { open: forced, wide: 0, round: 0 };
        figure.update(dt, { look, mouth, wave, speed: speed / S, climb });
    };

    /** The book follows the scroll; the box on page one folds away as its page turns. */
    const runStations = (dt: number, t: number): void => {
        ray.setFromCamera(pointer, camera);
        frame.dt = dt;
        frame.time = time;
        frame.ray = hasPointer ? ray.ray : null;
        // Closed on the poster frame; the cover swings open during the opening move; then the scroll.
        const opening = card && intro < 1 ? (intro < 0 ? -1 : -1 + smooth(0.04, 0.5, intro)) : spreadAt(t);
        book.turn(opening);
        // The box on page one is pressed flat by the closed book and springs up as it opens.
        const r = book.rise(0);
        const spring = r + Math.sin(Math.PI * r) * 0.08;
        hero.group.scale.set(1, 0.02 + 0.98 * spring, 0.3 + 0.7 * r);
        hero.group.rotation.x = -(1 - r) * 0.35;
        hero.group.visible = r > 0.02;
        frame.near = near('top');
        hero.update(frame);
        bits.update(dt);
    };

    /** If the first two seconds run slow, trade resolution for smoothness once. */
    const adapt = (dt: number): void => {
        if (frames >= 120) return;
        frames++;
        slow += dt > 1 / 40 ? 1 : 0;
        if (frames === 120 && slow > 50) renderer.setPixelRatio(1);
    };

    const tick = (now: number): void => {
        timer.update(now);
        const dt = Math.min(timer.getDelta(), 1 / 20);
        time += dt;
        const t = clamp(o.input.t, 0, stops.length - 1);
        const stopNow = clamp(Math.round(t), 0, stops.length - 1);
        steerCamera(dt, scrolled(t));
        inspectCamera();
        placeCamera();
        moveFigure(dt, stopNow);
        animateFigure(dt, stopNow);
        runStations(dt, t);
        // The film grade fades in as the camera leaves the poster, so the 2D → 3D swap still lines up.
        const grade = card ? smooth(0.15, 0.7, Math.max(0, intro)) : 1;
        film.frame(camera.position.distanceTo(cam.target), grade, time);
        film.render();
        if (!ready) {
            ready = true;
            o.onReady();
        }
        adapt(dt);
    };

    const resize = (): void => {
        renderer.setSize(window.innerWidth, window.innerHeight, false);
        film.setSize(window.innerWidth, window.innerHeight);
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        poses = places.map((p) => solve(p.shot, pose()));
    };
    resize();
    const initial = scrolled(clamp(o.input.t, 0, stops.length - 1));
    cam.pos.copy(initial.pos);
    cam.target.copy(initial.target);

    /**
     * Upload every texture and draw every caster into the shadow map once, so the first trip to
     * each station does not hitch on a texture upload or a shadow-pass shader.
     */
    const warmUp = (): void => {
        scene.traverse((obj) => {
            if (!(obj instanceof THREE.Mesh)) return;
            for (const m of Array.isArray(obj.material) ? obj.material : [obj.material]) {
                const map = (m as THREE.MeshStandardMaterial).map;
                if (map) renderer.initTexture(map);
            }
        });
        const box = key.shadow.camera;
        const size = { left: box.left, right: box.right, top: box.top, bottom: box.bottom };
        Object.assign(box, { left: -150, right: 150, top: 150, bottom: -150 });
        box.updateProjectionMatrix();
        key.target.position.set(0, 0, 0);
        key.position.set(-5.5, 8, 4.5);
        renderer.render(scene, camera);
        Object.assign(box, size);
        box.updateProjectionMatrix();
    };
    // Compile shaders before the first visible frame so the opening does not stutter.
    void renderer.compileAsync(scene, camera).then(() => {
        warmUp();
        renderer.setAnimationLoop(tick);
    });

    return {
        resize,
        matchPoster(rect) {
            // Straight down over the closed cover, at the distance where it fills the poster's rect.
            const vw = window.innerWidth;
            const vh = window.innerHeight;
            const visible = (COVER.h * vh) / rect.height;
            const d = visible / 2 / tanHalf(CARD_FOV);
            const nx = ((rect.left + rect.width / 2) / vw) * 2 - 1;
            const ny = -(((rect.top + rect.height / 2) / vh) * 2 - 1);
            const shift = new V((-nx * visible * (vw / vh)) / 2, 0, (ny * visible) / 2);
            const target = book.coverCenter.clone().add(shift);
            card = { pos: target.clone().add(new V(0, d, 0)), target, fov: CARD_FOV };
        },
        open() {
            if (intro >= 0) return;
            if (reduce || !card) {
                intro = 1;
                card = null;
                hero.cutout.visible = false;
                figure.root.visible = true;
                inflate = 1;
                teleport(places[clamp(Math.round(o.input.t), 0, stops.length - 1)].spot);
                // No fly-in: start on the shot the page is at.
                const now = scrolled(clamp(o.input.t, 0, stops.length - 1));
                cam.pos.copy(now.pos);
                cam.target.copy(now.target);
                return;
            }
            intro = 0;
            // The cut-out becomes the figure once the cover is open and the box has popped up.
            window.setTimeout(() => {
                hero.cutout.visible = false;
                figure.root.visible = true;
                figure.root.position.copy(hero.inside);
                inflate = 0;
                sfx('pop', 1);
                bits.burst(hero.inside.clone().add(new V(0, 1.2, 0.3)), 0.8);
            }, 1500);
        },
        dispose() {
            renderer.setAnimationLoop(null);
            timer.dispose();
            window.removeEventListener('pointermove', onMove);
            window.removeEventListener('pointerdown', onDown);
            scene.traverse((obj) => {
                if (obj instanceof THREE.Mesh) {
                    obj.geometry.dispose();
                    (Array.isArray(obj.material) ? obj.material : [obj.material]).forEach((m) => {
                        (m as THREE.MeshStandardMaterial).map?.dispose();
                        m.dispose();
                    });
                }
            });
            film.dispose();
            pmrem.dispose();
            renderer.dispose();
        },
    };
}
