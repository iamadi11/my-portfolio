/**
 * The portfolio as a pop-up board book lying open on the desk. Thick boards turn rigidly about
 * the spine as the page scrolls; each spread's paper mechanisms ride on its right-hand page and
 * stand up as that spread opens, folding flat again as its page turns away.
 */
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';

import { COVER, INK, SIGNAL } from '@/components/v2/art';
import { FONT, print } from '@/components/v2/print';

/** Page width (spine to fore-edge), depth (head to tail), board thickness, cover thickness. */
export const PAGE = { w: 4.2, d: 5.6, t: 0.065, cover: 0.07, over: 0.14 };

export type SpreadArt = {
    /** Large numeral or mark on the left page ('' for none). */
    mark: string;
    /** Section title on the left page ('' for none). */
    title: string;
    /** Tint of the right page, where the mechanism stands. */
    tint: string;
};

export type Book = {
    group: THREE.Group;
    count: number;
    /**
     * Open the book to spread `s` (fractional while a page is turning: 2.4 is 40% of the way to 3).
     * -1 is closed, cover up; -1 → 0 opens the cover onto spread 0.
     */
    turn(s: number): void;
    /** How far spread k stands up: 0 folded flat, 1 fully open. */
    rise(k: number): number;
    /** Spread k's right-hand page: top face at y = 0, spine at x = 0, fore-edge at x = PAGE.w. */
    page(k: number): THREE.Object3D;
    /** Height of the book's top surface under (x, z), or null off the book. */
    top(x: number, z: number): number | null;
    /** Centre of the front cover while the book is closed (the poster's 3D twin). */
    coverCenter: THREE.Vector3;
};

const ease = (x: number): number => (x < 0.5 ? 4 * x * x * x : 1 - (-2 * x + 2) ** 3 / 2);
const smooth = (a: number, b: number, x: number): number => {
    const t = THREE.MathUtils.clamp((x - a) / (b - a), 0, 1);
    return t * t * (3 - 2 * t);
};

/** Paper with a faint fibre, so print reads as printed rather than as a screen. */
function fibre(g: CanvasRenderingContext2D, w: number, h: number, seed: number): void {
    let s = seed;
    const rnd = (): number => (s = (s * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < (w * h) / 900; i++) {
        g.fillStyle = `rgba(${rnd() < 0.5 ? '255,255,255' : '120,100,80'},0.05)`;
        g.fillRect(rnd() * w, rnd() * h, 1 + rnd() * 3, 1);
    }
}

/** The left-hand page of a spread: its numeral and title, set like a book. */
function leftPrint(art: SpreadArt, seed: number): THREE.CanvasTexture {
    return print(
        PAGE.w,
        PAGE.d,
        (g, u) => {
            fibre(g, PAGE.w * u, PAGE.d * u, seed);
            g.fillStyle = INK;
            g.textBaseline = 'alphabetic';
            if (art.mark) {
                g.globalAlpha = 0.16;
                g.font = `800 ${2.3 * u}px ${FONT.display}`;
                g.fillText(art.mark, 0.32 * u, 2.6 * u);
                g.globalAlpha = 1;
            }
            if (art.title) {
                g.font = `800 ${0.42 * u}px ${FONT.display}`;
                let size = 0.42;
                while (g.measureText(art.title.toUpperCase()).width > 3.5 * u && size > 0.2) {
                    size *= 0.94;
                    g.font = `800 ${size * u}px ${FONT.display}`;
                }
                g.fillText(art.title.toUpperCase(), 0.34 * u, 3.3 * u);
                g.fillStyle = SIGNAL;
                g.fillRect(0.34 * u, 3.48 * u, 0.6 * u, 0.05 * u);
            }
        },
        { density: 110, background: '#ece2d0' }
    );
}

/** The right-hand page: a soft tinted field with fold guides, where the mechanism stands. */
function rightPrint(art: SpreadArt, seed: number): THREE.CanvasTexture {
    return print(
        PAGE.w,
        PAGE.d,
        (g, u) => {
            const W = PAGE.w * u;
            const H = PAGE.d * u;
            const field = g.createRadialGradient(W * 0.45, H * 0.45, 0, W * 0.45, H * 0.45, H * 0.75);
            field.addColorStop(0, art.tint);
            field.addColorStop(
                1,
                new THREE.Color(art.tint).lerp(new THREE.Color('#ece2d0'), 0.45).getStyle()
            );
            g.fillStyle = field;
            g.fillRect(0.18 * u, 0.18 * u, W - 0.36 * u, H - 0.36 * u);
            fibre(g, W, H, seed);
            g.strokeStyle = 'rgba(21,21,21,0.18)';
            g.setLineDash([0.06 * u, 0.05 * u]);
            g.lineWidth = Math.max(1, 0.012 * u);
            g.strokeRect(0.32 * u, 0.32 * u, W - 0.64 * u, H - 0.64 * u);
        },
        { density: 110, background: '#ece2d0' }
    );
}

/** Endpapers: a repeating mark in the house orange. */
function endpaper(): THREE.CanvasTexture {
    return print(
        PAGE.w,
        PAGE.d,
        (g, u) => {
            g.fillStyle = SIGNAL;
            for (let y = 0.3; y < PAGE.d; y += 0.42)
                for (let x = 0.3 + ((y * 10) % 2 ? 0.21 : 0); x < PAGE.w; x += 0.42) {
                    g.beginPath();
                    g.arc(x * u, y * u, 0.035 * u, 0, Math.PI * 2);
                    g.fill();
                }
        },
        { density: 110, background: '#f3e8d6' }
    );
}

const board = new THREE.MeshStandardMaterial({ color: '#e7ddca', roughness: 0.85 });

/**
 * A face printed on one side of a board w × d, t thick: `up` faces +y, otherwise -y (and reads
 * the right way round once the board has turned to the left).
 */
function face(tex: THREE.Texture, up: boolean, w = PAGE.w, d = PAGE.d, t = PAGE.t): THREE.Mesh {
    const geo = new THREE.PlaneGeometry(w - 0.04, d - 0.04);
    if (up) geo.rotateX(-Math.PI / 2);
    else geo.rotateX(Math.PI / 2).rotateY(Math.PI);
    geo.translate(w / 2, up ? 0.002 : -t - 0.002, 0);
    const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ map: tex, roughness: 0.82 }));
    m.receiveShadow = true;
    return m;
}

/** One board: a pivot on the spine holding the board, its recto (top) and verso (underside). */
function leaf(recto: THREE.Texture, verso: THREE.Texture): THREE.Group {
    const pivot = new THREE.Group();
    const geo = new RoundedBoxGeometry(PAGE.w, PAGE.t, PAGE.d, 2, 0.018);
    geo.translate(PAGE.w / 2, -PAGE.t / 2, 0);
    const slab = new THREE.Mesh(geo, board);
    slab.castShadow = slab.receiveShadow = true;
    pivot.add(slab, face(recto, true), face(verso, false));
    return pivot;
}

export function createBook(
    spreads: SpreadArt[],
    coverArt: (g: CanvasRenderingContext2D, u: number) => void,
    cloth = '#2f4a6d'
): Book {
    const group = new THREE.Group();
    const L = spreads.length;
    const C = PAGE.cover;
    const T = PAGE.t;

    // The back cover under the right stack, the spine, and the front cover: a board of its own,
    // hinged at the spine like the pages, art outside and endpapers inside.
    const clothMat = new THREE.MeshStandardMaterial({ color: cloth, roughness: 0.72 });
    const back = new THREE.Mesh(new RoundedBoxGeometry(COVER.w, C, COVER.h, 2, 0.03), clothMat);
    back.position.set(COVER.w / 2, C / 2, 0);
    back.castShadow = back.receiveShadow = true;
    const spine = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, COVER.h, 24), clothMat);
    spine.rotation.x = Math.PI / 2;
    spine.position.y = 0.06;
    group.add(back, spine);
    const front = new THREE.Group();
    const frontGeo = new RoundedBoxGeometry(COVER.w, C, COVER.h, 2, 0.03);
    frontGeo.translate(COVER.w / 2, -C / 2, 0);
    const frontBoard = new THREE.Mesh(frontGeo, clothMat);
    frontBoard.castShadow = frontBoard.receiveShadow = true;
    front.add(
        frontBoard,
        face(
            print(COVER.w, COVER.h, coverArt, { density: 150, background: null }),
            true,
            COVER.w,
            COVER.h,
            C
        ),
        face(endpaper(), false, COVER.w, COVER.h, C)
    );
    group.add(front);
    let coverAngle = 0;

    // Board j carries spread j's right page on its recto and spread j+1's left page on its verso.
    const leaves = spreads.map((art, j) => {
        const next = spreads[j + 1];
        const pivot = leaf(rightPrint(art, j * 2 + 1), next ? leftPrint(next, j * 2 + 2) : endpaper());
        group.add(pivot);
        return pivot;
    });
    const angles = new Float32Array(L);
    let open = 0;

    const book: Book = {
        group,
        count: L,
        turn(s) {
            open = THREE.MathUtils.clamp(s, -1, L - 1);
            const c = ease(THREE.MathUtils.clamp(open + 1, 0, 1));
            coverAngle = Math.PI * c;
            front.rotation.z = coverAngle;
            front.position.y = THREE.MathUtils.lerp(2 * C + L * T, 0, c) + Math.sin(Math.PI * c) * 0.05;
            leaves.forEach((pivot, j) => {
                const k = ease(THREE.MathUtils.clamp(open - j, 0, 1));
                angles[j] = Math.PI * k;
                // Right stack: board j sits under the boards before it; left stack: on the boards after it.
                const right = C + (L - j) * T;
                const left = C + j * T;
                pivot.position.y = THREE.MathUtils.lerp(right, left, k) + Math.sin(Math.PI * k) * 0.05;
                pivot.rotation.z = angles[j];
            });
        },
        rise(k) {
            const leftPage = k === 0 ? coverAngle : angles[k - 1];
            const opening = (leftPage - angles[k]) / Math.PI;
            return smooth(0.3, 0.95, opening);
        },
        page: (k) => leaves[k],
        top(x, z) {
            if (Math.abs(z) > PAGE.d / 2 || Math.abs(x) > PAGE.w) return null;
            if (open < -0.5) return x < 0 ? null : 2 * C + L * T;
            const turned = Math.floor(open + 0.5);
            return x < 0 ? C + turned * T : C + (L - turned) * T;
        },
        coverCenter: new THREE.Vector3(COVER.w / 2, 2 * C + L * T, 0),
    };
    book.turn(-1);
    return book;
}
