/**
 * The film look: MSAA, ground-truth ambient occlusion, a tilt-shift depth of field, a little bloom,
 * then tone mapping and a warm grade with vignette and grain. Phones get a lighter chain.
 */
import * as THREE from 'three';
import { BokehPass } from 'three/examples/jsm/postprocessing/BokehPass.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { GTAOPass } from 'three/examples/jsm/postprocessing/GTAOPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';

export type Look = {
    render(): void;
    setSize(w: number, h: number): void;
    /** Distance to keep sharp, and how strong the film grade is (0 on the poster frame). */
    frame(focus: number, grade: number, time: number): void;
    dispose(): void;
};

const Grade = {
    uniforms: {
        tDiffuse: { value: null },
        amount: { value: 0 },
        time: { value: 0 },
        aspect: { value: 1 },
    },
    vertexShader: /* glsl */ `
        varying vec2 vUv;
        void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: /* glsl */ `
        uniform sampler2D tDiffuse;
        uniform float amount;
        uniform float time;
        uniform float aspect;
        varying vec2 vUv;
        void main() {
            vec4 c = texture2D(tDiffuse, vUv);
            vec2 d = (vUv - 0.5) * vec2(aspect, 1.0);
            float v = smoothstep(1.15, 0.35, length(d));
            c.rgb *= mix(1.0, mix(0.84, 1.0, v), amount);
            c.rgb = mix(c.rgb, c.rgb * vec3(1.025, 1.0, 0.965), amount);
            // A gentle S-curve: the film look's contrast, without crushing the warm haze.
            c.rgb = mix(c.rgb, c.rgb * c.rgb * (3.0 - 2.0 * c.rgb), 0.3 * amount);
            float g = fract(sin(dot(vUv * 1000.0 + time, vec2(12.9898, 78.233))) * 43758.5453);
            c.rgb += (g - 0.5) * 0.016 * amount;
            gl_FragColor = c;
        }`,
};

export function createLook(
    renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
    camera: THREE.PerspectiveCamera,
    narrow: boolean
): Look {
    const size = new THREE.Vector2();
    renderer.getSize(size);
    const target = new THREE.WebGLRenderTarget(size.x, size.y, {
        type: THREE.HalfFloatType,
        samples: narrow ? 2 : 4,
    });
    const composer = new EffectComposer(renderer, target);
    composer.addPass(new RenderPass(scene, camera));

    // Ambient occlusion: the soft contact darkening that makes things sit in the world.
    // Half resolution: the denoise blurs it anyway, and it is the most expensive pass.
    const ao = new GTAOPass(scene, camera, size.x / 2, size.y / 2);
    ao.blendIntensity = 0.75;
    ao.updateGtaoMaterial({
        radius: 0.55,
        distanceExponent: 1.4,
        thickness: 1.5,
        scale: 1.1,
        samples: narrow ? 8 : 16,
    });
    ao.updatePdMaterial({
        lumaPhi: 10,
        depthPhi: 2,
        normalPhi: 3,
        radius: 6,
        rings: 2,
        samples: narrow ? 8 : 16,
    });
    composer.addPass(ao);

    // Tilt-shift depth of field on wide screens: the miniature-set feel.
    const bokeh = narrow
        ? null
        : new BokehPass(scene, camera, { focus: 10, aperture: 0.0006, maxblur: 0.005 });
    if (bokeh) composer.addPass(bokeh);

    // Only real light sources (the lamp bulb) bloom; white plastic and print stay crisp.
    const bloom = new UnrealBloomPass(size.clone(), 0.12, 0.35, 1.3);
    composer.addPass(bloom);
    composer.addPass(new OutputPass());
    const grade = new ShaderPass(Grade);
    composer.addPass(grade);

    return {
        render: () => composer.render(),
        setSize(w, h) {
            composer.setSize(w, h);
            ao.setSize(w / 2, h / 2);
            grade.uniforms.aspect.value = w / h;
        },
        frame(focus, amount, time) {
            if (bokeh) {
                (bokeh.uniforms as Record<string, THREE.IUniform>).focus.value = focus;
                (bokeh.uniforms as Record<string, THREE.IUniform>).aperture.value = 0.00022 * amount;
            }
            grade.uniforms.amount.value = amount;
            grade.uniforms.time.value = time % 100;
        },
        dispose() {
            composer.dispose();
            target.dispose();
            ao.dispose();
            bloom.dispose();
            bokeh?.dispose();
        },
    };
}

/**
 * Skin that lets light wrap round the terminator, warmer in red: a cheap stand-in for subsurface
 * scattering, the soft glow animated-film skin has.
 */
export function subsurface<T extends THREE.MeshStandardMaterial>(material: T, amount = 1): T {
    material.onBeforeCompile = (shader) => {
        shader.fragmentShader = shader.fragmentShader.replace(
            '#include <lights_physical_pars_fragment>',
            THREE.ShaderChunk.lights_physical_pars_fragment.replace(
                'reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );',
                `float ndlRaw = dot( geometryNormal, directLight.direction );
	vec3 wrapped = mix( vec3( saturate( ndlRaw ) ), vec3( saturate( ( ndlRaw + 0.5 ) / 1.5 ), saturate( ( ndlRaw + 0.22 ) / 1.22 ), saturate( ( ndlRaw + 0.14 ) / 1.14 ) ), ${amount.toFixed(2)} );
	reflectedLight.directDiffuse += wrapped * directLight.color * BRDF_Lambert( material.diffuseContribution );`
            )
        );
    };
    material.customProgramCacheKey = () => `subsurface${amount}`;
    return material;
}
