/**
 * The world the figure lives in: the owner's desk, seen at toy scale. A wooden top against a
 * plaster wall with window light, a desk lamp lighting the box, a cutting mat under the projects,
 * and a few everyday things (pencils, a mug, a sticky-note pad) that tell you how small he is.
 */
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';

import { SIGNAL } from '@/components/v2/art';

export type DeskLayout = {
    /** Where the figure greets you: the lamp is aimed at it. */
    hero: THREE.Vector3;
    /** The open book at the origin: page width and depth. */
    book: { w: number; d: number };
};

/** The wall colour, also the fog and the sky so everything fades into the room. */
export const WALL = '#eadfce';
const V = THREE.Vector3;

/** Small seeded random, so the desk looks the same on every visit. */
function seeded(seed: number): () => number {
    let s = seed;
    return () => {
        s = (s + 0x6d2b79f5) | 0;
        let t = Math.imul(s ^ (s >>> 15), 1 | s);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

function painted(
    size: number,
    draw: (g: CanvasRenderingContext2D, n: number) => void,
    height = size
): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = height;
    draw(canvas.getContext('2d') as CanvasRenderingContext2D, size);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.anisotropy = 8;
    return tex;
}

/** Light oak planks running along the walk, with soft grain and the odd end joint. */
function oak(): THREE.CanvasTexture {
    const random = seeded(7);
    const tones = ['#dcbd92', '#d5b386', '#e0c49d', '#d2af82'];
    return painted(1024, (g, n) => {
        const plank = n / 4;
        for (let p = 0; p < 4; p++) {
            g.fillStyle = tones[p];
            g.fillRect(0, p * plank, n, plank);
            for (let k = 0; k < 70; k++) {
                const y0 = p * plank + random() * plank;
                g.strokeStyle = `rgba(${random() < 0.5 ? '150,108,64' : '236,212,170'},${0.05 + random() * 0.12})`;
                g.lineWidth = 0.6 + random() * 2.2;
                g.beginPath();
                for (let x = 0; x <= n; x += 16)
                    g.lineTo(x, y0 + Math.sin(x * 0.006 + k) * (2 + random() * 3));
                g.stroke();
            }
            g.fillStyle = 'rgba(120,84,48,0.45)';
            g.fillRect(0, p * plank, n, 2);
            g.fillRect(Math.floor(random() * n), p * plank, 2, plank);
        }
    });
}

/** Warm plaster, lighter up high, with a window's light thrown across it and a shadow at the desk. */
function plaster(): THREE.CanvasTexture {
    const random = seeded(11);
    return painted(1024, (g, n) => {
        const sky = g.createLinearGradient(0, 0, 0, n);
        sky.addColorStop(0, '#f3ebdf');
        sky.addColorStop(0.75, WALL);
        sky.addColorStop(0.97, '#d9cab4');
        sky.addColorStop(1, '#c9b79c');
        g.fillStyle = sky;
        g.fillRect(0, 0, n, n);
        for (let k = 0; k < 9000; k++) {
            g.fillStyle = `rgba(${random() < 0.5 ? '255,255,255' : '160,130,100'},0.05)`;
            g.fillRect(random() * n, random() * n, 2, 2);
        }
        // Window light: soft panes drawn as the shadow of shapes kept off-canvas.
        g.shadowColor = 'rgba(255,240,214,0.75)';
        g.shadowBlur = 48;
        g.shadowOffsetX = n * 2;
        g.fillStyle = '#000';
        for (const [x, y] of [
            [0.18, 0.18],
            [0.32, 0.18],
            [0.18, 0.42],
            [0.32, 0.42],
        ]) {
            g.beginPath();
            g.moveTo((x - 2) * n, y * n);
            g.lineTo((x - 2 + 0.12) * n, (y + 0.03) * n);
            g.lineTo((x - 2 + 0.12) * n, (y + 0.24) * n);
            g.lineTo((x - 2) * n, (y + 0.21) * n);
            g.closePath();
            g.fill();
        }
    });
}

const enamel = (color: string): THREE.MeshPhysicalMaterial =>
    new THREE.MeshPhysicalMaterial({ color, roughness: 0.32, clearcoat: 0.7, clearcoatRoughness: 0.2 });
const chrome = new THREE.MeshStandardMaterial({ color: '#d9d6cf', metalness: 1, roughness: 0.28 });

function shaded<T extends THREE.Object3D>(obj: T): T {
    obj.traverse((o) => {
        if (o instanceof THREE.Mesh) o.castShadow = o.receiveShadow = true;
    });
    return obj;
}

/** A rod from a to b. */
function rod(a: THREE.Vector3, b: THREE.Vector3, r: number, mat: THREE.Material): THREE.Mesh {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, a.distanceTo(b), 14), mat);
    m.position.copy(a).lerp(b, 0.5);
    m.quaternion.setFromUnitVectors(new V(0, 1, 0), b.clone().sub(a).normalize());
    return m;
}

/** A coil spring from a to b, beside an arm. */
function spring(a: THREE.Vector3, b: THREE.Vector3): THREE.Mesh {
    const axis = b.clone().sub(a);
    const len = axis.length();
    const turns = Math.round(len * 9);
    const path = new THREE.CatmullRomCurve3(
        Array.from({ length: turns * 8 + 1 }, (_, i) => {
            const t = i / (turns * 8);
            const a2 = t * turns * Math.PI * 2;
            return new V(Math.cos(a2) * 0.07, t * len, Math.sin(a2) * 0.07);
        })
    );
    const m = new THREE.Mesh(new THREE.TubeGeometry(path, turns * 8, 0.014, 6), chrome);
    m.position.copy(a);
    m.quaternion.setFromUnitVectors(new V(0, 1, 0), axis.normalize());
    return m;
}

/**
 * An articulated desk lamp standing on the desk at `base`, its shade leaning over `aim`. The
 * spot it carries is the box's key light: a warm pool on the hero.
 */
function lamp(
    base: THREE.Vector3,
    aim: THREE.Vector3,
    elbowY: number,
    headY: number
): { group: THREE.Group; light: THREE.SpotLight } {
    const group = new THREE.Group();
    const body = enamel('#f1ebe1');
    const flat = new V(aim.x - base.x, 0, aim.z - base.z);
    const reach = flat.length();
    const h = flat.normalize();
    const at = (s: number, y: number, side = 0): THREE.Vector3 =>
        base
            .clone()
            .addScaledVector(h, s)
            .add(new V(0, y, 0))
            .add(new V(-h.z, 0, h.x).multiplyScalar(side));
    const foot = new THREE.LatheGeometry(
        [
            [0, 0],
            [0.95, 0],
            [1.0, 0.06],
            [0.97, 0.17],
            [0.62, 0.25],
            [0.24, 0.31],
            [0.2, 0.44],
            [0, 0.44],
        ].map(([x, y]) => new THREE.Vector2(x, y)),
        40
    );
    const plinth = new THREE.Mesh(foot, body);
    plinth.position.copy(base);
    const hip = at(0, 0.44);
    const elbow = at(reach * 0.28, elbowY);
    const head = at(reach - 0.75, headY);
    for (const side of [-0.11, 0.11]) {
        group.add(rod(at(0, 0.44, side), at(reach * 0.28, elbowY, side), 0.045, body));
        group.add(rod(at(reach * 0.28, elbowY, side), at(reach - 0.75, headY, side), 0.045, body));
    }
    group.add(spring(at(0.25, 0.9, 0.2), at(reach * 0.27, elbowY - 0.5, 0.2)));
    group.add(spring(at(reach * 0.33, elbowY + 0.05, 0.2), at(reach - 1.1, headY - 0.1, 0.2)));
    for (const joint of [hip, elbow, head]) {
        const knuckle = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.34, 20), body);
        knuckle.position.copy(joint);
        knuckle.quaternion.setFromUnitVectors(new V(0, 1, 0), new V(-h.z, 0, h.x));
        group.add(knuckle);
    }
    // The shade: a bell, open at the bottom, pointing at the aim.
    const bell = new THREE.LatheGeometry(
        [
            [0.2, 0.32],
            [0.3, 0.28],
            [0.42, 0.1],
            [0.62, -0.25],
            [0.86, -0.62],
            [0.95, -0.72],
            [0.93, -0.75],
        ].map(([x, y]) => new THREE.Vector2(x, y)),
        40
    );
    const shade = new THREE.Group();
    const outer = new THREE.Mesh(bell, body);
    const inner = new THREE.Mesh(
        bell,
        new THREE.MeshStandardMaterial({
            color: '#fff3df',
            roughness: 0.5,
            side: THREE.BackSide,
            emissive: '#ffd9a0',
            emissiveIntensity: 0.6,
        })
    );
    const bulb = new THREE.Mesh(
        new THREE.SphereGeometry(0.3, 24, 16),
        new THREE.MeshBasicMaterial({ color: new THREE.Color(4, 3.4, 2.4) })
    );
    bulb.position.y = -0.2;
    shade.add(outer, inner, bulb);
    shade.position.copy(head);
    shade.quaternion.setFromUnitVectors(new V(0, -1, 0), aim.clone().sub(head).normalize());
    group.add(plinth, shade);
    shaded(group);
    bulb.castShadow = inner.castShadow = false;

    const light = new THREE.SpotLight('#ffd6a0', 16, 0, 0.62, 0.9, 2);
    light.position.copy(head).addScaledVector(aim.clone().sub(head).normalize(), 0.5);
    light.target.position.copy(aim);
    group.add(light, light.target);
    return { group, light };
}

/** A hex pencil lying on the desk. */
function pencil(at: THREE.Vector3, yaw: number, paint: string): THREE.Group {
    const L = 2.6;
    const r = 0.11;
    const g = new THREE.Group();
    const hex = new THREE.Mesh(new THREE.CylinderGeometry(r, r, L, 6), enamel(paint));
    const wood = new THREE.Mesh(
        new THREE.CylinderGeometry(0.035, r, 0.42, 6),
        new THREE.MeshStandardMaterial({ color: '#e7c497', roughness: 0.8 })
    );
    wood.position.y = L / 2 + 0.21;
    const lead = new THREE.Mesh(
        new THREE.ConeGeometry(0.035, 0.1, 12),
        new THREE.MeshStandardMaterial({ color: '#3a3836', roughness: 0.4, metalness: 0.3 })
    );
    lead.position.y = L / 2 + 0.47;
    const band = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.06, r * 1.06, 0.24, 24), chrome);
    band.position.y = -L / 2 - 0.12;
    const rubber = new THREE.Mesh(
        new THREE.CapsuleGeometry(r * 0.98, 0.12, 6, 16),
        new THREE.MeshStandardMaterial({ color: '#e6928a', roughness: 0.85 })
    );
    rubber.position.y = -L / 2 - 0.3;
    g.add(hex, wood, lead, band, rubber);
    // Spin a flat face down, then lay it along x.
    g.rotation.y = Math.PI / 6;
    const lay = new THREE.Group();
    lay.add(g);
    lay.rotation.z = Math.PI / 2;
    const holder = new THREE.Group();
    holder.add(lay);
    holder.position.set(at.x, r * 0.87, at.z);
    holder.rotation.y = yaw;
    return shaded(holder);
}

/** A glazed mug of coffee. */
function mug(at: THREE.Vector3): THREE.Group {
    const g = new THREE.Group();
    const glaze = new THREE.MeshPhysicalMaterial({
        color: SIGNAL,
        roughness: 0.18,
        clearcoat: 1,
        clearcoatRoughness: 0.08,
    });
    const wall = new THREE.LatheGeometry(
        [
            [0, 0.02],
            [0.4, 0.0],
            [0.5, 0.06],
            [0.52, 0.3],
            [0.53, 1.2],
            [0.55, 1.24],
            [0.5, 1.26],
            [0.47, 1.2],
            [0.46, 0.14],
            [0, 0.12],
        ].map(([x, y]) => new THREE.Vector2(x, y)),
        48
    );
    const cup = new THREE.Mesh(wall, glaze);
    const coffee = new THREE.Mesh(
        new THREE.CircleGeometry(0.465, 40),
        new THREE.MeshPhysicalMaterial({ color: '#3a2318', roughness: 0.15, clearcoat: 1 })
    );
    coffee.rotation.x = -Math.PI / 2;
    coffee.position.y = 1.02;
    const handle = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.075, 14, 28, Math.PI * 1.15), glaze);
    handle.position.set(0.5, 0.66, 0);
    handle.rotation.z = -Math.PI * 0.575;
    g.add(cup, coffee, handle);
    g.position.copy(at);
    g.rotation.y = -0.5; // handle toward the camera
    return shaded(g);
}

/** A pad of sticky notes, a little squared off. */
function notes(at: THREE.Vector3, yaw: number): THREE.Mesh {
    const pad = new THREE.Mesh(
        new RoundedBoxGeometry(1.15, 0.34, 1.15, 2, 0.03),
        new THREE.MeshStandardMaterial({ color: '#f2d35e', roughness: 0.9 })
    );
    pad.position.set(at.x, 0.17, at.z);
    pad.rotation.y = yaw;
    return shaded(pad);
}

/** Builds the desk around the open book (at the origin) and adds it to the scene. */
export function createDesk(scene: THREE.Scene, layout: DeskLayout): void {
    const { w, d } = layout.book;
    const wood = oak();
    wood.repeat.set(160 / 9.6, 64 / 9.6);
    const top = new THREE.Mesh(
        new THREE.PlaneGeometry(160, 64),
        new THREE.MeshStandardMaterial({ map: wood, roughness: 0.62 })
    );
    top.rotation.x = -Math.PI / 2;
    top.position.set(0, 0, 16);
    top.receiveShadow = true;

    const wallTex = plaster();
    wallTex.repeat.set(160 / 30, 1);
    const wall = new THREE.Mesh(
        new THREE.PlaneGeometry(160, 30),
        new THREE.MeshStandardMaterial({ map: wallTex, roughness: 0.95 })
    );
    wall.position.set(0, 15, -16);
    wall.receiveShadow = true;

    const hero = layout.hero;
    // Behind the book on the right, leaning in so the shade hangs over the page and the greeting spot.
    const { group: desklamp } = lamp(
        new V(w + 2.6, 0, -d / 2 - 1.2),
        new V(hero.x - 1.4, 0, hero.z - 0.4),
        5.2,
        5.4
    );
    scene.add(
        top,
        wall,
        desklamp,
        mug(new V(-w - 2.4, 0, -d / 2 + 0.4)),
        pencil(new V(-w - 1.4, 0, d / 2 + 1.6), 0.32, '#f2c230'),
        pencil(new V(-w - 0.6, 0, d / 2 + 2.3), -0.12, '#3b6fd8'),
        notes(new V(w + 2.2, 0, d / 2 + 0.6), 0.25)
    );
}
