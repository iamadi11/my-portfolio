'use client';

import React, { useEffect, useImperativeHandle, useRef } from 'react';

import { type BoxText, COVER, drawCover, loadImage } from '@/components/v2/art';
import type { FigureSpec } from '@/components/v2/figure';

export type Fonts = { display: string; body: string; mono: string };

/**
 * The 2D state: the closed book's cover, drawn by the same function as the 3D cover texture. On
 * Start the 3D camera begins straight above that cover, so the swap is invisible; then it opens.
 */
export default function Poster({
    text,
    figure,
    fonts,
    onClick,
    ref,
}: {
    text: BoxText;
    figure: FigureSpec;
    fonts: () => Fonts;
    onClick: () => void;
    ref?: React.Ref<HTMLCanvasElement>;
}): React.JSX.Element {
    const canvas = useRef<HTMLCanvasElement>(null);
    useImperativeHandle(ref, () => canvas.current as HTMLCanvasElement);

    useEffect(() => {
        const el = canvas.current;
        if (!el) return undefined;
        let frame = 0;
        let art: HTMLImageElement | null = null;
        const draw = (): void => {
            if (!el.clientWidth) return;
            const dpr = Math.min(window.devicePixelRatio, 2);
            el.width = Math.round(el.clientWidth * dpr);
            el.height = Math.round(el.clientHeight * dpr);
            const g = el.getContext('2d');
            if (!g) return;
            g.clearRect(0, 0, el.width, el.height);
            drawCover(g, el.width / COVER.w, text, fonts(), figure, art);
        };
        const redraw = (): void => {
            cancelAnimationFrame(frame);
            frame = requestAnimationFrame(draw);
        };
        const f = fonts();
        void Promise.all([
            loadImage(figure.cutout).then((img) => (art = img)),
            document.fonts.load(`800 40px ${f.display}`).catch(() => undefined),
            document.fonts.load(`600 20px ${f.mono}`).catch(() => undefined),
        ]).then(redraw);
        window.addEventListener('resize', redraw);
        return () => {
            cancelAnimationFrame(frame);
            window.removeEventListener('resize', redraw);
        };
    }, [text, figure, fonts]);

    return (
        <canvas
            ref={canvas}
            className="v2-poster"
            role="img"
            aria-label={`${text.name}, on the cover of a pop-up book`}
            onClick={onClick}
        />
    );
}
