'use client';

import React, { lazy, Suspense, useCallback, useEffect, useRef, useState } from 'react';

import clsx from 'clsx';
import Link from 'next/link';

import { createVoice, type Voice } from '@/components/host/audio';
import { mouth as visemes } from '@/components/host/face';
import { type Line, match, type Script } from '@/components/host/script';
import { useListen, usePauseOnReading } from '@/components/host/useGuideInput';
import type { SiteContent } from '@/components/instrumented/content';
import type { FigureSpec, Mouth } from '@/components/v2/figure';
import Guide from '@/components/v2/Guide';
import { type Model, type Stop, stopFor } from '@/components/v2/model';
import Poster, { type Fonts } from '@/components/v2/Poster';
import type { Sound, World } from '@/components/v2/world';

import '@/components/v2/v2.css';

const loadStage = (): Promise<typeof import('@/components/v2/Stage')> => import('@/components/v2/Stage');
const Stage = lazy(loadStage);

type Phase = 'poster' | 'loading' | 'live' | 'flat';
type Caption = { who: 'host' | 'you'; text: string };

/** How long the 2D → 3D opening runs before the guide speaks. */
const OPENING_MS = 2700;
const clamp01 = (x: number): number => Math.min(1, Math.max(0, x));
const nn = (i: number): string => String(i + 1).padStart(2, '0');
const webgl = (): boolean => {
    const c = document.createElement('canvas');
    return Boolean(c.getContext('webgl2') ?? c.getContext('webgl'));
};

function fontsFrom(root: HTMLElement | null): Fonts {
    const css = (el: Element, name: string): string => getComputedStyle(el).getPropertyValue(name).trim();
    return {
        display: (root && css(root, '--font-v2-display')) || 'sans-serif',
        body: css(document.body, '--font-geist-sans') || 'sans-serif',
        mono: css(document.body, '--font-geist-mono') || 'monospace',
    };
}

/* ------------------------------------------------------------------ section text */

function Plate({
    stop,
    site,
    model,
}: {
    stop: Stop;
    site: SiteContent;
    model: Model;
}): React.JSX.Element | null {
    const { profile } = site;
    if (stop.kind === 'work')
        return (
            <div className="v2-plate">
                <p className="v2-kicker">Work</p>
                <h2>{`${model.projects.length} things I built`}</h2>
                <p className="v2-line">Each one plays. Click a set.</p>
            </div>
        );
    if (stop.kind === 'project') {
        const p = model.projects[stop.index];
        return (
            <div className="v2-plate">
                <p className="v2-kicker">Project {nn(stop.index)}</p>
                <h2>{p.title}</h2>
                <p className="v2-line">{p.summary}</p>
                <ul className="v2-chips" aria-label="Built with">
                    {p.stack.map((s) => (
                        <li key={s}>{s}</li>
                    ))}
                </ul>
                <p className="v2-links">
                    {p.links.map((l) => (
                        <a key={l.href} href={l.href} target="_blank" rel="noreferrer">
                            {l.label}
                        </a>
                    ))}
                </p>
            </div>
        );
    }
    if (stop.kind === 'step') {
        const r = model.rungs[stop.index];
        const school = model.school && stop.index === 0;
        return (
            <div className="v2-plate">
                <p className="v2-kicker">{school ? `Education · ${r.period}` : r.period}</p>
                <h2>{r.org}</h2>
                <p className="v2-line">{r.role}</p>
            </div>
        );
    }
    if (stop.kind === 'skills')
        return (
            <div className="v2-plate">
                <p className="v2-kicker">Skills</p>
                <h2>Tools I use daily</h2>
                <p className="v2-line">Press a key.</p>
                <dl className="v2-sr">
                    {model.skills.map((g) => (
                        <React.Fragment key={g.group}>
                            <dt>{g.group}</dt>
                            <dd>{g.items.join(', ')}</dd>
                        </React.Fragment>
                    ))}
                </dl>
            </div>
        );
    if (stop.kind === 'contact')
        return (
            <div className="v2-plate">
                <p className="v2-kicker">{profile.availability}</p>
                <h2>Say hello</h2>
                <p className="v2-links v2-links-big">
                    <a href={`mailto:${profile.email}`}>{profile.email}</a>
                    {profile.phone && <a href={profile.phone.href}>{profile.phone.label}</a>}
                    {profile.links.map((l) => (
                        <a key={l.href} href={l.href} target="_blank" rel="noreferrer">
                            {l.label}
                        </a>
                    ))}
                </p>
            </div>
        );
    return null;
}

/* ------------------------------------------------------------------ the page */

export default function V2({
    site,
    model,
    script,
    figure,
}: {
    site: SiteContent;
    model: Model;
    script: Script;
    figure: FigureSpec;
}): React.JSX.Element {
    const { profile } = site;
    const first = profile.name.split(/\s+/)[0];
    const [phase, setPhase] = useState<Phase>('poster');
    const [mounted, setMounted] = useState(false);
    const [narrow, setNarrow] = useState(false);
    const [reduce, setReduce] = useState(false);
    const [stop, setStop] = useState(0);
    const [touring, setTouring] = useState(false);
    const [caption, setCaption] = useState<Caption | null>(null);
    const [muted, setMuted] = useState(false);
    const [question, setQuestion] = useState('');

    const root = useRef<HTMLElement>(null);
    const poster = useRef<HTMLCanvasElement>(null);
    const voice = useRef<Voice | null>(null);
    const world = useRef<World | null>(null);
    const input = useRef({ t: 0 });
    const tops = useRef<number[]>([]);
    const tour = useRef({ playing: false, index: -1 });
    const intro = useRef(false);
    const lineId = useRef(0);

    const fonts = useCallback((): Fonts => fontsFrom(root.current), []);

    /** Fetch the 3D code and, once the visitor reaches for Start, the character model. Model skipped on Save-Data. */
    const warm = useCallback((): void => {
        void loadStage();
        const saveData = (navigator as Navigator & { connection?: { saveData?: boolean } }).connection
            ?.saveData;
        if (figure.model && !saveData) void fetch(figure.model).catch(() => undefined);
    }, [figure.model]);

    /* -------- scroll → stop position, read by the 3D world every frame */
    useEffect(() => {
        const reduceQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
        setReduce(reduceQuery.matches);
        const onScroll = (): void => {
            const y = window.scrollY;
            const T = tops.current;
            let i = 0;
            while (i < T.length - 2 && y >= T[i + 1]) i++;
            const t = i + clamp01((y - T[i]) / Math.max(1, T[i + 1] - T[i]));
            input.current.t = t;
            setStop(Math.round(t));
            // Scrolling past the poster brings the world in, silently.
            if (y > window.innerHeight * 0.3) setMounted(true);
        };
        const measure = (): void => {
            setNarrow(window.innerWidth / window.innerHeight < 1.05);
            tops.current = model.stops.map((s) => {
                const el = document.querySelector(`[data-stop="${s.id}"]`);
                return el ? el.getBoundingClientRect().top + window.scrollY : 0;
            });
            onScroll();
        };
        measure();
        window.addEventListener('scroll', onScroll, { passive: true });
        window.addEventListener('resize', measure);
        // Fetch the 3D code once the page is idle, so Start is quick; the model waits for intent.
        const code = (): void => void loadStage();
        const idle = window.requestIdleCallback?.(code) ?? window.setTimeout(code, 2500);
        return () => {
            window.removeEventListener('scroll', onScroll);
            window.removeEventListener('resize', measure);
            window.cancelIdleCallback?.(idle);
        };
    }, [model.stops]);

    /* -------- talking */
    /** A caption stays a beat after its line, then the dock goes back to its short prompt. */
    const fade = useCallback((): void => {
        const id = lineId.current;
        window.setTimeout(() => {
            if (lineId.current === id) setCaption(null);
        }, 2500);
    }, []);

    const say = useCallback(
        (line: Line, then?: () => void): void => {
            const id = ++lineId.current;
            setCaption({ who: 'host', text: line.text });
            void voice.current?.play(line, () => {
                if (lineId.current === id) fade();
                then?.();
            });
        },
        [fade]
    );

    const show = useCallback(
        (target: string | undefined): void => {
            const id = stopFor(target, model);
            const i = model.stops.findIndex((s) => s.id === id);
            if (i < 0) return;
            window.scrollTo({ top: tops.current[i], behavior: reduce ? 'auto' : 'smooth' });
        },
        [model, reduce]
    );

    const play = useCallback(
        (index: number): void => {
            const step = script.tour[index];
            tour.current = { playing: Boolean(step), index };
            setTouring(Boolean(step));
            if (!step) return;
            show(step.target);
            voice.current?.prefetch(script.tour.slice(index + 1, index + 3).map((s) => s.line));
            say(step.line, () => {
                if (tour.current.playing && tour.current.index === index)
                    window.setTimeout(() => play(index + 1), 700);
            });
        },
        [script.tour, say, show]
    );

    const pause = useCallback((): void => {
        tour.current.playing = false;
        setTouring(false);
        voice.current?.stop();
        fade();
    }, [fade]);

    const ask = useCallback(
        (text: string): void => {
            const q = text.trim();
            if (!q) return;
            pause();
            setQuestion('');
            lineId.current++;
            setCaption({ who: 'you', text: q });
            const intent = match(q, script.intents);
            window.setTimeout(() => {
                show(intent?.target);
                say(intent?.line ?? script.fallback);
            }, 350);
        },
        [script.intents, script.fallback, pause, say, show]
    );

    const listen = useListen({
        onStart: pause,
        onHeard: setQuestion,
        onFinal: ask,
        onEnd: () => undefined,
    });
    usePauseOnReading(touring, pause);

    useEffect(() => voice.current?.setMuted(muted), [muted]);
    useEffect(() => () => voice.current?.close(), []);

    /* -------- Start: the box opens, the print becomes a toy */
    const start = useCallback((): void => {
        voice.current ??= createVoice();
        voice.current.prefetch(script.tour.slice(0, 2).map((s) => s.line));
        if (phase === 'live' || phase === 'flat') {
            play(Math.max(0, tour.current.index));
            return;
        }
        if (!webgl()) {
            setPhase('flat');
            voice.current.swell(0.6);
            play(0);
            return;
        }
        window.scrollTo({ top: 0, behavior: 'auto' });
        intro.current = true;
        voice.current.swell(1.2);
        setPhase('loading');
        setMounted(true);
    }, [phase, play, script.tour]);

    const onWorld = useCallback((w: World | null): void => {
        world.current = w;
        if (w && intro.current && poster.current && window.scrollY < 4)
            w.matchPoster(poster.current.getBoundingClientRect());
    }, []);

    const onReady = useCallback((): void => {
        setPhase('live');
        world.current?.open();
        if (intro.current) {
            intro.current = false;
            window.setTimeout(() => play(0), reduce ? 300 : OPENING_MS);
        }
    }, [play, reduce]);

    const mouth = useCallback((): Mouth | null => {
        const now = voice.current?.now();
        if (!now) return null;
        const f = visemes(now.visemes, now.ms);
        return {
            open: clamp01((f.jawOpen ?? 0) * 1.7),
            wide: clamp01((((f.mouthStretchLeft ?? 0) + (f.mouthStretchRight ?? 0)) / 2) * 1.6),
            round: clamp01(Math.max(f.mouthFunnel ?? 0, f.mouthPucker ?? 0)),
        };
    }, []);
    const sfx = useCallback((name: Sound, amount?: number): void => voice.current?.fx(name, amount), []);
    const hello = useCallback((): void => {
        window.location.href = `mailto:${profile.email}`;
    }, [profile.email]);

    const started = phase !== 'poster';
    const label =
        phase === 'loading'
            ? 'Opening the box…'
            : started
              ? touring
                  ? 'Guide is talking'
                  : 'Play the tour'
              : 'Start';

    return (
        <main ref={root} id="main-content" className={clsx('v2', `is-${phase}`, narrow && 'is-narrow')}>
            {mounted && phase !== 'flat' && (
                <Suspense fallback={null}>
                    <Stage
                        key={narrow ? 'narrow' : 'wide'}
                        figure={figure}
                        model={model}
                        narrow={narrow}
                        reduce={reduce}
                        fonts={fonts}
                        input={input.current}
                        mouth={mouth}
                        sfx={sfx}
                        onHello={hello}
                        onWorld={onWorld}
                        onReady={onReady}
                    />
                </Suspense>
            )}

            <header className="v2-bar">
                <a href="#top" className="v2-mark">
                    {profile.name}
                </a>
                <Link href="/" className="v2-text">
                    Text version
                </Link>
            </header>

            {model.stops.map((s, i) => (
                <section
                    key={s.id}
                    id={s.id}
                    data-stop={s.id}
                    className={clsx('v2-stop', `v2-${s.kind}`)}
                    aria-label={s.kind === 'top' ? undefined : s.id}
                >
                    {s.kind === 'top' ? (
                        <>
                            <div className="v2-plate v2-hero">
                                <p className="v2-kicker">
                                    {profile.location} · {profile.availability}
                                </p>
                                <h1>{profile.name}</h1>
                                <p className="v2-role">{profile.role}</p>
                                <div className="v2-actions">
                                    <button
                                        type="button"
                                        className={clsx('v2-start', !started && 'is-calling')}
                                        onClick={start}
                                        onPointerEnter={warm}
                                        onFocus={warm}
                                        disabled={phase === 'loading' || (touring && started)}
                                    >
                                        <span className="v2-start-dot" aria-hidden="true" />
                                        {label}
                                    </button>
                                    <a className="v2-skip" href="#work">
                                        Skip to work
                                    </a>
                                </div>
                                {!started && (
                                    <p className="v2-note">
                                        Sound on. A synthetic voice; answers come from this page.
                                    </p>
                                )}
                            </div>
                            <div className="v2-poster-wrap">
                                <Poster
                                    ref={poster}
                                    text={model.box}
                                    figure={figure}
                                    fonts={fonts}
                                    onClick={started ? () => undefined : start}
                                />
                            </div>
                        </>
                    ) : (
                        <Plate stop={s} site={site} model={model} />
                    )}
                    {i === model.stops.length - 1 && <span className="v2-end" aria-hidden="true" />}
                </section>
            ))}

            <nav className="v2-rail" aria-label="Sections">
                {model.stops.map((s, i) => (
                    <a
                        key={s.id}
                        href={`#${s.id}`}
                        className={clsx(i === stop && 'is-here')}
                        aria-label={s.id}
                        aria-current={i === stop ? 'location' : undefined}
                    />
                ))}
            </nav>

            {started && (
                <Guide
                    firstName={first}
                    caption={caption}
                    touring={touring}
                    muted={muted}
                    question={question}
                    prompts={script.prompts}
                    listen={listen}
                    onToggleTour={touring ? pause : () => play(Math.max(0, tour.current.index))}
                    onNext={() => play(tour.current.index + 1)}
                    onMute={() => setMuted((m) => !m)}
                    onQuestion={setQuestion}
                    onAsk={ask}
                />
            )}
        </main>
    );
}
