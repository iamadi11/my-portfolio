/**
 * 2D artwork shared by the poster (first paint, no three.js) and the 3D world's printed textures,
 * so the 2D → 3D handoff matches. Canvas only; no three.js imports here.
 * Units are world units (the figure stands 2 tall); `u` is pixels per unit.
 */
import type { FigureSpec } from '@/components/v2/figure';

export const INK = '#151515';
export const PAPER = '#f7f3ec';
export const SIGNAL = '#ff5a1f';
const EMBER = '#ff7a45';

/** The toy box, front view. Window measured from the top-left of the front panel. */
export const BOX = {
    w: 2.4,
    h: 3.5,
    d: 1.2,
    wall: 0.04,
    top: 0.42,
    window: { x: 0.2, y: 0.56, w: 2, h: 2.3 },
};
/** The book's front cover, in world units (board plus overhang); the 2D poster is this cover. */
export const COVER = { w: 4.34, h: 5.88 };
/** The figure stands this far behind the box's centre plane while it is still a print. */
export const CUTOUT_Z = -0.12;
/** Lens of the opening shot: long, so the 2D poster and the 3D box line up almost flat. */
export const CARD_FOV = 9;
/** World scale of the figure (figure units → world units). */
export const FIGURE_SCALE = 1.14;
/** The cut-out's canvas, in figure units: x -1.75..1.75, y 0..5. */
export const CUTOUT = { w: 0.9, h: 1.86 };

/** Lighter (k > 1) or darker (k < 1) version of a hex colour. */
function shade(hex: string, k: number): string {
    const n = parseInt(hex.slice(1), 16);
    const c = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) =>
        Math.round(k > 1 ? v + (255 - v) * (k - 1) : v * k)
    );
    return `rgb(${c.join(',')})`;
}

export type BoxText = { name: string; role: string; location: string };

function roundRect(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number): void {
    g.beginPath();
    g.roundRect(x, y, w, h, r);
}

function fitText(
    g: CanvasRenderingContext2D,
    text: string,
    x: number,
    y: number,
    max: number,
    size: number,
    font: string
): void {
    let s = size;
    g.font = font.replace('{s}', `${s}px`);
    while (s > 4 && g.measureText(text).width > max) {
        s *= 0.95;
        g.font = font.replace('{s}', `${s}px`);
    }
    g.fillText(text, x, y);
}

/** Front panel: orange card, ink header, a die-cut window, the name on the foot. */
export function drawBoxFront(
    g: CanvasRenderingContext2D,
    u: number,
    text: BoxText,
    fonts: { display: string; mono: string }
): void {
    const { w, h, top, window: win } = BOX;
    g.save();
    g.beginPath();
    g.rect(0, 0, w * u, h * u);
    g.roundRect(win.x * u, win.y * u, win.w * u, win.h * u, 0.12 * u);
    g.fillStyle = SIGNAL;
    g.fill('evenodd');

    // Header band with the city and a barcode, like a shelf label.
    g.fillStyle = INK;
    g.fillRect(0, 0, w * u, top * u);
    g.fillStyle = PAPER;
    g.textBaseline = 'middle';
    g.textAlign = 'left';
    fitText(
        g,
        text.location.toUpperCase(),
        0.16 * u,
        (top / 2) * u,
        1.4 * u,
        0.1 * u,
        `600 {s} ${fonts.mono}`
    );
    for (let i = 0, x = w - 0.62; i < 18; i++) {
        const bw = (i * 7) % 3 === 0 ? 0.03 : 0.012;
        g.fillRect(x * u, 0.1 * u, bw * u, 0.22 * u);
        x += bw + 0.012;
    }

    // Window lip: a thin paper edge.
    g.strokeStyle = PAPER;
    g.lineWidth = 0.035 * u;
    roundRect(g, win.x * u, win.y * u, win.w * u, win.h * u, 0.12 * u);
    g.stroke();

    // Foot: the name, big, and the role under it.
    const foot = win.y + win.h;
    g.fillStyle = INK;
    g.textAlign = 'center';
    g.textBaseline = 'alphabetic';
    fitText(
        g,
        text.name.toUpperCase(),
        (w / 2) * u,
        (foot + 0.4) * u,
        (w - 0.3) * u,
        0.36 * u,
        `800 {s} ${fonts.display}`
    );
    fitText(
        g,
        text.role.toUpperCase(),
        (w / 2) * u,
        (foot + 0.54) * u,
        (w - 0.4) * u,
        0.07 * u,
        `600 {s} ${fonts.mono}`
    );
    g.restore();
}

/** Inside of the box: a sunburst behind the figure. Drawn into a w × h panel. */
export function drawBoxBack(g: CanvasRenderingContext2D, u: number, w: number, h: number): void {
    const cx = (w / 2) * u;
    const cy = h * 0.42 * u;
    g.fillStyle = SIGNAL;
    g.fillRect(0, 0, w * u, h * u);
    g.fillStyle = EMBER;
    const rays = 28;
    const r = Math.hypot(w, h) * u;
    for (let i = 0; i < rays; i += 2) {
        const a0 = (i / rays) * Math.PI * 2;
        const a1 = ((i + 1) / rays) * Math.PI * 2;
        g.beginPath();
        g.moveTo(cx, cy);
        g.lineTo(cx + Math.cos(a0) * r, cy + Math.sin(a0) * r);
        g.lineTo(cx + Math.cos(a1) * r, cy + Math.sin(a1) * r);
        g.fill();
    }
    const glow = g.createRadialGradient(cx, cy, 0, cx, cy, 1.1 * u);
    glow.addColorStop(0, 'rgba(255, 240, 225, 0.85)');
    glow.addColorStop(1, 'rgba(255, 240, 225, 0)');
    g.fillStyle = glow;
    g.fillRect(0, 0, w * u, h * u);
}

/** Loads an image for printing; resolves null if it is missing. */
export function loadImage(url: string | undefined): Promise<HTMLImageElement | null> {
    if (!url) return Promise.resolve(null);
    return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = () => resolve(null);
        img.src = url;
    });
}

/** The character artwork as a die-cut print: the image on a paper border, 1.78 m tall, standing on the base line. */
function drawPrint(g: CanvasRenderingContext2D, u: number, image: HTMLImageElement): void {
    const h = 1.78 * u;
    const w = (h * image.width) / image.height;
    const x = (CUTOUT.w * u - w) / 2;
    const y = CUTOUT.h * u - h;
    const edge = document.createElement('canvas');
    edge.width = image.width;
    edge.height = image.height;
    const e = edge.getContext('2d') as CanvasRenderingContext2D;
    e.drawImage(image, 0, 0);
    e.globalCompositeOperation = 'source-in';
    e.fillStyle = PAPER;
    e.fillRect(0, 0, edge.width, edge.height);
    const r = 0.022 * u;
    for (let k = 0; k < 16; k++) {
        const a = (k / 16) * Math.PI * 2;
        g.drawImage(edge, x + Math.cos(a) * r, y + Math.sin(a) * r, w, h);
    }
    g.drawImage(image, x, y, w, h);
}

/** Front-view half width of the head (head units) by height, matching figure.ts. */
const HEAD_W: [number, number][] = [
    [-1, 0],
    [-0.97, 0.14],
    [-0.9, 0.27],
    [-0.8, 0.39],
    [-0.68, 0.5],
    [-0.55, 0.56],
    [-0.35, 0.61],
    [-0.1, 0.655],
    [0.2, 0.675],
    [0.45, 0.655],
    [0.65, 0.6],
    [0.8, 0.5],
    [0.92, 0.33],
    [0.98, 0.17],
    [1, 0],
];

/**
 * The figure as a flat, die-cut print: same proportions as the 3D figure seen from the front.
 * Drawn in metres with y up; the canvas is CUTOUT.w × CUTOUT.h metres at `u` px per metre.
 */
export function drawCutout(
    g: CanvasRenderingContext2D,
    u: number,
    s: FigureSpec,
    image?: HTMLImageElement | null
): void {
    if (image) {
        drawPrint(g, u, image);
        return;
    }
    g.save();
    g.translate((CUTOUT.w / 2) * u, CUTOUT.h * u);
    g.scale(u, -u);
    g.lineJoin = 'round';
    g.lineCap = 'round';
    const H = 0.148;
    const HY = 1.673;
    /** Head units → metres. */
    const hx = (x: number): number => x * H;
    const hy = (y: number): number => HY + y * H;

    const poly = (pts: [number, number][], fill: string): void => {
        g.beginPath();
        pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y)));
        g.closePath();
        g.fillStyle = fill;
        g.fill();
    };
    const rrect = (x: number, y: number, w: number, h: number, r: number, fill: string, rot = 0): void => {
        g.save();
        g.translate(x, y);
        g.rotate(rot);
        g.beginPath();
        g.roundRect(-w / 2, -h / 2, w, h, r);
        g.fillStyle = fill;
        g.fill();
        g.restore();
    };
    const ellipse = (x: number, y: number, rx: number, ry: number, fill: string): void => {
        g.beginPath();
        g.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
        g.fillStyle = fill;
        g.fill();
    };
    const headPath = (): void => {
        g.beginPath();
        HEAD_W.forEach(([y, w], i) => (i ? g.lineTo(hx(w), hy(y)) : g.moveTo(hx(w), hy(y))));
        [...HEAD_W].reverse().forEach(([y, w]) => g.lineTo(hx(-w), hy(y)));
        g.closePath();
    };
    const torso: [number, number][] = [
        [0.168, 0.86],
        [0.152, 1.04],
        [0.17, 1.22],
        [0.192, 1.34],
        [0.2, 1.42],
        [0.176, 1.46],
        [0.12, 1.49],
        [0.068, 1.505],
    ];

    // Die-cut border: the silhouette again, fatter, in paper.
    g.save();
    g.strokeStyle = PAPER;
    g.fillStyle = PAPER;
    g.lineWidth = 0.05;
    poly(
        [
            [-0.22, 0.0],
            [0.22, 0.0],
            [0.24, 0.95],
            [0.3, 1.45],
            [0.13, 1.82],
            [-0.13, 1.82],
            [-0.3, 1.45],
            [-0.24, 0.95],
        ],
        PAPER
    );
    g.restore();

    // Sneakers, jeans, arms behind the shirt, the shirt, sleeves, hands.
    for (const side of [-1, 1]) {
        rrect(side * 0.095, 0.03, 0.114, 0.05, 0.02, shade(s.shoes, 0.9));
        rrect(side * 0.095, 0.085, 0.1, 0.075, 0.035, s.shoes);
        poly(
            [
                [side * 0.018, 0.84],
                [side * 0.195, 0.97],
                [side * 0.175, 0.12],
                [side * 0.015, 0.12],
            ],
            s.pants
        );
        g.save();
        g.translate(side * 0.215, 1.43);
        g.rotate(side * 0.1);
        rrect(0, -0.28, 0.08, 0.36, 0.04, s.skin);
        rrect(0, -0.48, 0.06, 0.24, 0.03, s.skin);
        ellipse(0, -0.62, 0.034, 0.055, s.skin);
        g.restore();
    }
    rrect(0, 0.93, 0.34, 0.13, 0.03, s.pants);
    poly(
        [
            ...torso.map(([x, y]): [number, number] => [x, y]),
            ...[...torso].reverse().map(([x, y]): [number, number] => [-x, y]),
        ],
        s.shirt
    );
    for (const side of [-1, 1]) rrect(side * 0.215, 1.365, 0.13, 0.2, 0.05, s.shirt, side * 0.1);
    if (s.laptop) rrect(0.272, 0.73, 0.022, 0.215, 0.006, s.laptop, 0.1);

    // Neck and head.
    rrect(0, 1.5, 0.105, 0.12, 0.03, shade(s.skin, 0.9));
    headPath();
    g.fillStyle = s.skin;
    g.fill();

    // Beard below the cheek line, moustache, clipped to the face.
    if (s.beard) {
        g.save();
        headPath();
        g.clip();
        g.beginPath();
        g.moveTo(hx(-0.7), hy(0.0));
        g.bezierCurveTo(hx(-0.6), hy(-0.35), hx(-0.4), hy(-0.55), hx(-0.22), hy(-0.6));
        g.lineTo(hx(-0.2), hy(-0.66));
        g.lineTo(hx(0.2), hy(-0.66));
        g.lineTo(hx(0.22), hy(-0.6));
        g.bezierCurveTo(hx(0.4), hy(-0.55), hx(0.6), hy(-0.35), hx(0.7), hy(0.0));
        g.lineTo(hx(0.8), hy(-1.1));
        g.lineTo(hx(-0.8), hy(-1.1));
        g.closePath();
        g.fillStyle = s.beard;
        g.fill();
        rrect(0, hy(-0.405), hx(0.46), hx(0.075), hx(0.035), s.beard);
        g.restore();
    }
    // Mouth, nose.
    rrect(0, hy(-0.53), hx(0.34), hx(0.035), hx(0.017), shade(s.skin, 0.62));
    ellipse(0, hy(-0.31), hx(0.1), hx(0.07), shade(s.skin, 0.86));

    // Hair: faded sides, textured top, with a few strands.
    g.beginPath();
    g.moveTo(hx(-0.68), hy(0.25));
    g.bezierCurveTo(hx(-0.74), hy(0.7), hx(-0.6), hy(1.15), hx(-0.15), hy(1.22));
    g.bezierCurveTo(hx(0.25), hy(1.3), hx(0.68), hy(1.12), hx(0.72), hy(0.62));
    g.lineTo(hx(0.68), hy(0.25));
    g.lineTo(hx(0.6), hy(0.36));
    g.bezierCurveTo(hx(0.5), hy(0.55), hx(0.3), hy(0.63), hx(0), hy(0.64));
    g.bezierCurveTo(hx(-0.3), hy(0.63), hx(-0.5), hy(0.55), hx(-0.6), hy(0.36));
    g.closePath();
    g.fillStyle = s.hair;
    g.fill();
    g.strokeStyle = shade(s.hair, 1.6);
    g.lineWidth = hx(0.03);
    for (const x of [-0.4, -0.15, 0.1, 0.35]) {
        g.beginPath();
        g.moveTo(hx(x), hy(0.72));
        g.quadraticCurveTo(hx(x + 0.05), hy(1.0), hx(x + 0.25), hy(1.12 - Math.abs(x) * 0.2));
        g.stroke();
    }

    // Eyes, brows, glasses.
    for (const side of [-1, 1]) {
        const x = hx(side * 0.27);
        const y = hy(0);
        ellipse(x, y, hx(0.16), hx(0.11), '#f1ebe2');
        ellipse(x, y, hx(0.1), hx(0.1), s.eyes);
        ellipse(x, y, hx(0.05), hx(0.05), '#050403');
        ellipse(x + hx(0.04), y + hx(0.04), hx(0.022), hx(0.022), '#ffffff');
        rrect(hx(side * 0.29), hy(0.3), hx(0.4), hx(0.075), hx(0.035), s.hair, side * -0.08);
    }
    if (s.glasses) {
        g.strokeStyle = s.glasses;
        g.lineWidth = hx(0.04);
        for (const side of [-1, 1]) {
            g.beginPath();
            g.roundRect(hx(side * 0.285 - 0.26), hy(0.02 - 0.2), hx(0.52), hx(0.4), hx(0.08));
            g.stroke();
        }
        g.beginPath();
        g.moveTo(hx(-0.035), hy(0.09));
        g.lineTo(hx(0.035), hy(0.09));
        g.stroke();
    }

    // Headphones: cups over the ears and the band over the hair.
    if (s.headphones) {
        for (const side of [-1, 1])
            rrect(hx(side * 0.88), hy(-0.06), hx(0.24), hx(0.8), hx(0.12), s.headphones);
        g.strokeStyle = s.headphones;
        g.lineWidth = hx(0.1);
        g.beginPath();
        g.moveTo(hx(-0.88), hy(0.3));
        g.bezierCurveTo(hx(-0.9), hy(1.45), hx(0.9), hy(1.45), hx(0.88), hy(0.3));
        g.stroke();
    }
    g.restore();
}

/**
 * The book's front cover: the guide printed on a sunburst, a shelf label with the city, and the
 * name on a paper plate. The 2D poster draws exactly this, so Start can lift the real cover.
 */
export function drawCover(
    g: CanvasRenderingContext2D,
    u: number,
    text: BoxText,
    fonts: { display: string; mono: string },
    figure: FigureSpec,
    image?: HTMLImageElement | null
): void {
    const { w, h } = COVER;
    drawBoxBack(g, u, w, h);
    // A cloth border, as if the board were wrapped.
    g.strokeStyle = 'rgba(21,21,21,0.18)';
    g.lineWidth = 0.05 * u;
    roundRect(g, 0.16 * u, 0.16 * u, (w - 0.32) * u, (h - 0.32) * u, 0.1 * u);
    g.stroke();

    // The guide, standing on the plate.
    const k = 1.62;
    const plateY = h - 1.46;
    g.save();
    g.translate(((w - CUTOUT.w * k) / 2) * u, (plateY + 0.06 - CUTOUT.h * k) * u);
    drawCutout(g, u * k, figure, image);
    g.restore();

    // Shelf label with the city.
    g.fillStyle = INK;
    roundRect(g, 0.42 * u, 0.42 * u, 1.9 * u, 0.36 * u, 0.06 * u);
    g.fill();
    g.fillStyle = PAPER;
    g.textAlign = 'left';
    g.textBaseline = 'middle';
    fitText(g, text.location.toUpperCase(), 0.56 * u, 0.6 * u, 1.62 * u, 0.12 * u, `600 {s} ${fonts.mono}`);

    // Name plate.
    g.fillStyle = PAPER;
    roundRect(g, 0.38 * u, plateY * u, (w - 0.76) * u, 1.04 * u, 0.12 * u);
    g.fill();
    g.fillStyle = INK;
    g.textAlign = 'center';
    g.textBaseline = 'alphabetic';
    fitText(
        g,
        text.name.toUpperCase(),
        (w / 2) * u,
        (plateY + 0.6) * u,
        (w - 1.0) * u,
        0.5 * u,
        `800 {s} ${fonts.display}`
    );
    fitText(
        g,
        text.role.toUpperCase(),
        (w / 2) * u,
        (plateY + 0.86) * u,
        (w - 1.1) * u,
        0.11 * u,
        `600 {s} ${fonts.mono}`
    );
}
