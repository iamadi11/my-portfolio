/**
 * What /v2 shows, derived from the same SiteContent as /. No three.js here: the page shell,
 * the HTML sections and the 3D world all read this one model.
 */
import type { Hue, Link, Mark, SiteContent } from '@/components/instrumented/content';

export type Rung = { org: string; role: string; period: string };

/** One scroll stop: a screen-height of page and one camera shot. */
export type Stop =
    | { id: 'top'; kind: 'top' }
    | { id: 'work'; kind: 'work' }
    | { id: string; kind: 'project'; index: number }
    | { id: string; kind: 'step'; index: number }
    | { id: 'skills'; kind: 'skills' }
    | { id: 'contact'; kind: 'contact' };

export type Model = {
    box: { name: string; role: string; location: string };
    projects: {
        id: string;
        title: string;
        summary: string;
        stack: string[];
        links: Link[];
        mark: Mark;
        hue: Hue;
    }[];
    /** Education first, then roles oldest to newest: the stairs climb toward now. */
    rungs: Rung[];
    /** Whether rungs[0] is education. */
    school: boolean;
    skills: { group: string; items: string[] }[];
    stops: Stop[];
};

const plain = (text: string): string => text.replace(/\s*\([^)]*\)/g, '').trim();

export function model(site: SiteContent): Model {
    const { profile, projects, practice } = site;
    const rungs = [...(practice.education ?? []).slice(0, 1), ...[...practice.experience].reverse()];
    const skills = (practice.skills ?? []).map((g) => ({
        group: g.group,
        items: g.items.split(',').map((item) => plain(item.trim())),
    }));
    return {
        box: { name: profile.name, role: profile.role, location: profile.location },
        projects: projects.map(({ id, title, summary, stack, links, mark, hue }) => ({
            id,
            title,
            summary,
            stack,
            links,
            mark,
            hue,
        })),
        rungs,
        school: Boolean(practice.education?.length),
        skills,
        stops: [
            { id: 'top', kind: 'top' },
            { id: 'work', kind: 'work' },
            ...projects.map((p, index) => ({ id: p.id, kind: 'project' as const, index })),
            ...rungs.map((_, index) => ({ id: `step-${index}`, kind: 'step' as const, index })),
            ...(skills.length ? [{ id: 'skills' as const, kind: 'skills' as const }] : []),
            { id: 'contact', kind: 'contact' },
        ],
    };
}

/** The stop a script target points at ('experience' means the most recent role). */
export function stopFor(target: string | undefined, m: Model): string | undefined {
    if (!target) return undefined;
    if (target === 'experience') return `step-${m.rungs.length - 1}`;
    if (target === 'education') return m.school ? 'step-0' : undefined;
    return m.stops.some((s) => s.id === target) ? target : undefined;
}
